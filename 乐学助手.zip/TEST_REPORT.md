# 项目测试报告

**测试时间：** 2026-05-19  
**测试环境：** Windows 10 · Node.js · Next.js 16.2.6 · `npm run dev` @ http://localhost:3000  
**测试类型：** 静态检查（lint/build）+ 主链路 HTTP Smoke Test（无自动化单元测试套件）

---

## 1. 测试摘要

| 类别 | 结果 |
|------|------|
| `npm run lint` | 通过 |
| `npm run build` | 通过 |
| 页面路由（`/`、`/planner`、`/records`、`/lesson/[id]`） | 通过 |
| `GET /api/model` | 通过（DeepSeek 已配置） |
| `GET /api/lesson` | 通过（可读取历史课件） |
| `GET /api/chat` | 通过（可恢复答疑历史） |
| `POST /api/chat`（纯文本） | 通过（偶发 502 为模型侧瞬时错误，重试成功） |
| `POST /api/plan` | 通过（完整表单字段） |
| 学习记录聚合 `/records` | 通过 |

**结论：** 项目主链路可正常运行；本次发现并修复 2 类代码问题，清理 1 类技术债。

---

## 2. 测试范围与用例

### 2.1 静态检查

| 用例 | 命令 | 预期 | 实际 |
|------|------|------|------|
| ESLint | `npm run lint` | 无错误 | 通过 |
| 生产构建 | `npm run build` | 编译成功 | 通过 |

### 2.2 页面 Smoke Test

| 用例 | URL | 预期 | 实际 |
|------|-----|------|------|
| 首页 | `GET /` | 200 | 200 |
| 规划页 | `GET /planner` | 200 | 200 |
| 学习记录 | `GET /records` | 200 | 200 |
| 课程页（含 query） | `GET /lesson/{encodedKey}?subject=...&focus=...&day=2` | 200 | 200 |
| 课程页（仅 path） | `GET /lesson/{encodedKey}` | 200，且能从 path 解析学科/主题 | 200 |

### 2.3 API Smoke Test

| 用例 | 方法 | 预期 | 实际 |
|------|------|------|------|
| 模型自检 | `GET /api/model` | 返回 provider/model | `configured=true`, `provider=DeepSeek` |
| 读取课程历史 | `GET /api/lesson?subject=初二物理&focus=受力分析入门&dayNumber=2` | 返回 `lesson` + `history` | 6 页幻灯片，1 个历史版本 |
| 读取答疑历史 | `GET /api/chat?lessonId=初二物理__受力分析入门__day-2` | 返回消息列表 | `messageCount≥2` |
| 纯文本答疑 | `POST /api/chat` | 200 + `answer` | 通过（首次偶发 502，重试 200） |
| 生成周计划 | `POST /api/plan`（含 `challenge` 等完整字段） | 200 + 7 天计划 | 通过 |
| 参数校验 | `POST /api/plan`（缺少 `challenge`） | 400 | 400 `INVALID_REQUEST_BODY` |
| 参数校验 | `POST /api/chat`（`question` 过短） | 400 | 400 |

---

## 3. 发现的问题与修复

### 问题 1：调试埋点残留在生产代码中（已修复）

**现象：** `src/app/api/chat/route.ts`、`src/app/api/lesson/route.ts`、`src/features/learning-records/repository.ts` 中残留上次 smoke test 的调试代码，每次请求同步 `readFileSync(".dbg/...")` 并向 `127.0.0.1:7777` 发送日志。

**影响：** 不必要的磁盘 I/O；调试服务不存在时虽被 `catch` 吞掉，但增加请求开销与代码噪音。

**修复：** 移除全部 `#region debug-point` 埋点及相关 `readFileSync` 导入。

---

### 问题 2：课程页忽略 URL 中的 `lessonId`（已修复）

**现象：** [`src/app/lesson/[lessonId]/page.tsx`](src/app/lesson/[lessonId]/page.tsx) 原先 `await params` 后未使用 `lessonId`，仅依赖 query 参数；当用户访问 `/lesson/{encodedKey}` 且缺少 `?subject=&focus=&day=` 时，会错误回退到默认「初二物理 / 力和运动的关系 / day-1」。

**影响：** 从学习记录页复制仅 path 的链接、或 query 丢失时，加载错误课程上下文。

**修复：**
- 在 [`storage.ts`](src/features/lesson-generation/storage.ts) 新增 `parseLessonRouteId()`，解析 `{subject}__{focus}__day-{n}` 格式。
- 课程页在 query 缺失时，从路由 `lessonId` 解析 `subject` / `focus` / `dayNumber`。

---

### 问题 3：纯文本答疑 503（历史问题，此前已修复，本次复测通过）

**现象：** 未上传截图时，若仅配置 DeepSeek 文本模型、未配置 `DEEPSEEK_MULTIMODAL_MODEL`，曾返回 `503 MISSING_MULTIMODAL_MODEL`。

**当前状态：** [`tutoring/service.ts`](src/features/tutoring/service.ts) 已在无图片时走文本模型；本次 `POST /api/chat` 纯文本请求通过。

---

### 非代码缺陷（记录备查）

| 项 | 说明 |
|----|------|
| `POST /api/chat` 偶发 502 | 模型返回不可解析内容时抛出 `INVALID_TUTORING_OUTPUT`，属上游 LLM 瞬时问题，重试可成功。 |
| 无 `npm test` | 项目尚未引入 Vitest/Playwright，仅手工 smoke test。 |
| README 阶段描述滞后 | 文档仍写 Phase 3/4 边界，与当前 Phase 4.5 能力不一致（建议后续文档同步，非阻塞）。 |

---

## 4. 修复后验证

| 检查项 | 结果 |
|--------|------|
| `npm run lint` | 通过 |
| `npm run build` | 通过 |
| 移除调试埋点后 API 正常 | 通过 |
| 课程页无 query 仅 path 可访问 | 通过（200） |
| 纯文本答疑 | 通过 |

---

## 5. 建议后续测试改进

1. 在 `package.json` 增加 `test` 脚本，用 Vitest 覆盖 `parseLessonRouteId`、学习记录聚合、schema 校验。
2. 用 Playwright 固化主链路：规划 → 课程 → 答疑 → 学习记录。
3. 对 `/api/chat`、`/api/plan` 增加超时与重试提示，区分「模型瞬时失败」与「配置缺失」。

---

## 6. 变更文件清单（本次修复）

- `src/app/api/chat/route.ts` — 移除调试埋点
- `src/app/api/lesson/route.ts` — 移除调试埋点
- `src/features/learning-records/repository.ts` — 移除调试埋点
- `src/features/lesson-generation/storage.ts` — 新增 `parseLessonRouteId`
- `src/app/lesson/[lessonId]/page.tsx` — 从路由 id 回退解析课程上下文
