import Link from "next/link";
import { Home, ArrowLeft } from "lucide-react";
import { LearnerProfileForm } from "@/components/forms/learner-profile-form";

const examples = [
  "初二物理，力学基础薄弱，每天 60 分钟",
  "小学五年级数学，分数应用题不熟，每天 40 分钟",
  "初一英语，时态混淆，想在 1 周内打基础",
];

export default function PlannerPage() {
  return (
    <main className="mx-auto min-h-screen w-full max-w-6xl px-6 py-10 lg:px-8 bg-[#FFF9F5]">
      <div className="mb-8 flex justify-between items-center">
        <Link
          href="/"
          className="btn-secondary inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-semibold"
        >
          <Home className="h-4 w-4" />
          返回首页
        </Link>
        <Link
          href="/records"
          className="btn-secondary inline-flex items-center rounded-full px-5 py-3 text-sm font-semibold"
        >
          查看学习记录
        </Link>
      </div>
      <div className="grid gap-8 lg:grid-cols-[1fr_1fr]">
        <section>
          <p className="text-sm font-medium text-[#4ECDC4]">Phase 1 / 学习规划</p>
          <h1 className="mt-3 text-3xl font-bold text-[#2D3436] leading-tight">
            先描述孩子的学习情况，再生成 7 天学习计划。
          </h1>
          <p className="mt-4 text-base leading-8 text-[#64748B]">
            当前版本会优先调用 DeepSeek 生成结构化周计划；如果未配置 DeepSeek，也可按配置自动回退到 OpenAI。
          </p>

          <div className="mt-8 space-y-3">
            {examples.map((example, index) => (
              <div key={example} className="surface rounded-2xl px-5 py-4 text-sm text-[#2D3436] flex items-center gap-3">
                <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[#4ECDC4]/15 text-[#4ECDC4] text-xs font-bold">
                  {index + 1}
                </span>
                {example}
              </div>
            ))}
          </div>
        </section>

        <section className="surface rounded-[2rem] p-6 sm:p-8">
          <LearnerProfileForm />
        </section>
      </div>
    </main>
  );
}
