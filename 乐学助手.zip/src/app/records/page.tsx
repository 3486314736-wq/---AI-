import Link from "next/link";
import { BookOpen, CalendarDays, Clock3, MessagesSquare, Sparkles } from "lucide-react";
import { listLearningRecords } from "@/features/learning-records/repository";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function formatDateTime(value: string | null) {
  if (!value) {
    return "暂无记录";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "刚刚";
  }

  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function summarizeQuestion(value: string | null) {
  if (!value) {
    return "还没有围绕这节课发起过答疑，可以从课程页继续提问。";
  }

  return value.length > 56 ? `${value.slice(0, 56)}...` : value;
}

export default async function RecordsPage() {
  const { records, totalLessonCount, totalTutorQuestionCount, latestActivityAt } =
    await listLearningRecords();

  return (
    <main className="mx-auto min-h-screen w-full max-w-7xl px-6 py-10 lg:px-10 bg-[#FFF9F5]">
      <section className="surface rounded-[2rem] p-6 sm:p-8">
        <div className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <p className="text-sm font-medium text-[#4ECDC4]">Phase 4.5 / 学习记录 ✨</p>
            <h1 className="mt-3 text-4xl font-bold text-[#2D3436]">把规划、课程和答疑串成连续学习轨迹</h1>
            <p className="mt-4 max-w-3xl text-base leading-8 text-[#64748B]">
              这里汇总最近生成过的课程、答疑次数和最近学习时间，方便学生继续学习，也方便家长快速了解近期进度。
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <Link
              href="/planner"
              className="btn-primary inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-semibold"
            >
              继续生成新计划
            </Link>
            <Link
              href="/"
              className="btn-secondary inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-semibold"
            >
              返回首页
            </Link>
          </div>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          <article className="rounded-3xl border border-[#FFE8D6] bg-white p-5">
            <div className="inline-flex rounded-2xl bg-[#4ECDC4]/15 p-3 text-[#4ECDC4]">
              <BookOpen className="h-5 w-5" />
            </div>
            <p className="mt-4 text-sm text-[#64748B]">已生成课程</p>
            <p className="mt-2 text-3xl font-bold text-[#2D3436]">{totalLessonCount}</p>
          </article>

          <article className="rounded-3xl border border-[#FFE8D6] bg-white p-5">
            <div className="inline-flex rounded-2xl bg-[#A55EEA]/15 p-3 text-[#A55EEA]">
              <MessagesSquare className="h-5 w-5" />
            </div>
            <p className="mt-4 text-sm text-[#64748B]">累计提问次数</p>
            <p className="mt-2 text-3xl font-bold text-[#2D3436]">{totalTutorQuestionCount}</p>
          </article>

          <article className="rounded-3xl border border-[#FFE8D6] bg-white p-5">
            <div className="inline-flex rounded-2xl bg-[#FFD93D]/15 p-3 text-[#FFD93D]">
              <Clock3 className="h-5 w-5" />
            </div>
            <p className="mt-4 text-sm text-[#64748B]">最近学习时间</p>
            <p className="mt-2 text-xl font-bold text-[#2D3436]">{formatDateTime(latestActivityAt)}</p>
          </article>
        </div>
      </section>

      <section className="mt-8">
        <div className="mb-4 flex items-center gap-2 text-sm font-medium text-[#4ECDC4]">
          <Sparkles className="h-4 w-4" />
          最近学习记录
        </div>

        {records.length > 0 ? (
          <div className="grid gap-4">
            {records.map((record) => (
              <article
                key={record.requestKey}
                className="surface rounded-[2rem] p-5 sm:p-6"
              >
                <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
                  <div className="min-w-0">
                    <p className="text-sm font-medium text-[#4ECDC4]">
                      {record.subject} · 第 {record.dayNumber} 天
                    </p>
                    <h2 className="mt-2 text-2xl font-bold text-[#2D3436]">{record.lessonTitle}</h2>
                    <p className="mt-3 text-sm leading-7 text-[#64748B]">{record.lessonDescription}</p>
                  </div>

                  <div className="flex flex-wrap gap-3">
                    <Link
                      href={record.href}
                      className="btn-primary inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-semibold"
                    >
                      继续学习
                    </Link>
                    <Link
                      href="/planner"
                      className="btn-secondary inline-flex items-center justify-center rounded-2xl px-4 py-2 text-sm font-semibold"
                    >
                      重新规划
                    </Link>
                  </div>
                </div>

                <div className="mt-5 grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
                  <div className="rounded-[1.5rem] border border-[#FFE8D6] bg-white p-4">
                    <div className="flex items-center gap-2 text-sm font-medium text-[#2D3436]">
                      <CalendarDays className="h-4 w-4 text-[#4ECDC4]" />
                      课程状态
                    </div>
                    <div className="mt-3 grid gap-2 text-sm leading-7 text-[#64748B]">
                      <p>当前主题：{record.focus}</p>
                      <p>最近生成：{formatDateTime(record.latestGeneratedAt)}</p>
                      <p>课程版本：{record.lessonVersionCount} 个</p>
                      <p>课件页数：{record.slideCount} 页</p>
                      <p>已浏览：{record.viewedSlideCount} 页</p>
                      <p>
                        打卡状态：
                        {record.checkInStatus === "completed"
                          ? `已打卡${record.checkInLevel ? `（${record.checkInLevel === "full" ? "完整" : record.checkInLevel === "standard" ? "标准" : "轻量"}）` : ""}`
                          : record.checkInStatus === "in_progress"
                            ? "进行中"
                            : "未打卡"}
                      </p>
                    </div>
                  </div>

                  <div className="rounded-[1.5rem] border border-[#FFE8D6] bg-white p-4">
                    <div className="flex items-center gap-2 text-sm font-medium text-[#2D3436]">
                      <MessagesSquare className="h-4 w-4 text-[#A55EEA]" />
                      答疑与小测
                    </div>
                    <div className="mt-3 grid gap-2 text-sm leading-7 text-[#64748B]">
                      <p>最近答疑：{formatDateTime(record.latestTutorUpdatedAt)}</p>
                      <p>已保存消息：{record.tutorMessageCount} 条</p>
                      <p>学生提问：{record.tutorQuestionCount} 次</p>
                      <p>小测正确：{record.quizCorrectCount} 题</p>
                      <p>最近问题：{summarizeQuestion(record.latestQuestion)}</p>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>
        ) : (
          <section className="surface rounded-[2rem] p-6">
            <p className="text-sm font-medium text-[#4ECDC4]">还没有学习记录</p>
            <h2 className="mt-2 text-2xl font-bold text-[#2D3436]">先生成一份计划或课程，这里就会开始累计学习轨迹。</h2>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-[#64748B]">
              当前学习记录页会自动读取服务端 `.data/lessons` 和 `.data/chats`，生成课程后即可在这里继续查看。
            </p>
            <Link
              href="/planner"
              className="mt-6 btn-primary inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-semibold"
            >
              立即开始规划
            </Link>
          </section>
        )}
      </section>
    </main>
  );
}
