import Link from "next/link";
import { ArrowRight, BookOpen, CalendarCheck2, MessagesSquare, NotebookTabs, Sparkles } from "lucide-react";

const highlights = [
  {
    title: "7 天学习规划",
    description: "根据学科、薄弱点和时间约束，输出可执行的一周学习安排。",
    icon: CalendarCheck2,
    color: "bg-[#FF6B6B]/10 text-[#FF6B6B]",
  },
  {
    title: "今日课程生成",
    description: "围绕每日目标生成 Web 幻灯片结构，为后续接入搜索和 PPT 导出做准备。",
    icon: BookOpen,
    color: "bg-[#4ECDC4]/10 text-[#4ECDC4]",
  },
  {
    title: "实时互动答疑",
    description: "支持围绕当前课程页提问、上传截图，并恢复同一节课的答疑历史。",
    icon: MessagesSquare,
    color: "bg-[#A55EEA]/10 text-[#A55EEA]",
  },
  {
    title: "学习记录总览",
    description: "把课程生成与答疑记录串起来，形成可继续学习的连续轨迹。",
    icon: NotebookTabs,
    color: "bg-[#FFD93D]/10 text-[#FFD93D]",
  },
] as const;

export default function Home() {
  return (
    <main className="min-h-screen bg-[#FFF9F5]">
      <div className="mx-auto flex min-h-screen w-full max-w-6xl flex-col px-6 py-8 lg:px-8">
        {/* Header */}
        <header className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl gradient-bg">
              <Sparkles className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-[#2D3436]">乐学小助手</h1>
              <p className="text-sm text-[#9CA3AF]">中小学生个性化学习</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Link
              href="/records"
              className="btn-secondary inline-flex items-center gap-2 rounded-full px-5 py-3 text-sm font-semibold"
            >
              最近学习
            </Link>
            <Link
              href="/planner"
              className="btn-primary inline-flex items-center gap-2 rounded-full px-6 py-3 text-sm font-semibold"
            >
              开始规划
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </header>

        {/* Hero Section */}
        <section className="flex flex-1 flex-col justify-center py-16 lg:flex-row lg:items-center lg:gap-16">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 rounded-full border border-[#4ECDC4]/30 bg-[#4ECDC4]/10 px-4 py-2">
              <span className="text-sm text-[#4ECDC4] font-medium">🎯 新体验</span>
            </div>
            <h2 className="mt-6 text-4xl font-bold text-[#2D3436] sm:text-5xl lg:text-6xl leading-tight">
              让学习变有趣，
              <span className="gradient-text">从今天开始</span>
            </h2>
            <p className="mt-6 text-lg leading-8 text-[#64748B]">
              从学习画像到每日课程，再到课中答疑，一条链路先跑通。支持 7 天计划、每日课程、小测作答、学习进度、打卡记录与课中答疑，形成完整的一周学习闭环。
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link
                href="/planner"
                className="btn-primary inline-flex items-center justify-center rounded-2xl px-8 py-4 text-lg font-semibold"
              >
                进入规划表单
              </Link>
              <Link
                href="/lesson/%E5%88%9D%E4%BA%8C%E7%89%A9%E7%90%86__%E5%8A%9B%E5%92%8C%E8%BF%90%E5%8A%A8%E7%9A%84%E5%85%B3%E7%B3%BB__day-1?subject=%E5%88%9D%E4%BA%8C%E7%89%A9%E7%90%86&focus=%E5%8A%9B%E5%92%8C%E8%BF%90%E5%8A%A8%E7%9A%84%E5%85%B3%E7%B3%BB&day=1"
                className="btn-secondary inline-flex items-center justify-center rounded-2xl px-8 py-4 text-lg font-semibold"
              >
                查看课程预览
              </Link>
            </div>
          </div>

          {/* Feature Cards */}
          <div className="mt-12 grid gap-5 lg:mt-0 lg:w-[30rem]">
            {highlights.map(({ title, description, icon: Icon, color }) => (
              <article key={title} className="surface card-hover rounded-3xl p-6">
                <div className={`mb-4 inline-flex rounded-2xl ${color} p-3`}>
                  <Icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-bold text-[#2D3436]">{title}</h3>
                <p className="mt-2 text-sm leading-7 text-[#64748B]">{description}</p>
              </article>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
