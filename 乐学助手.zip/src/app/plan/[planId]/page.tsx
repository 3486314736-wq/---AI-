import { PlanResultClient } from "@/components/planner/plan-result-client";
import { coerceLearnerProfile } from "@/features/planning/mock";

export default async function PlanDetailPage({
  params,
  searchParams,
}: {
  params: Promise<{ planId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { planId } = await params;
  const profile = coerceLearnerProfile(await searchParams);

  return (
    <main className="mx-auto min-h-screen w-full max-w-7xl px-6 py-10 lg:px-10 bg-[#FFF9F5]">
      <PlanResultClient planId={planId} profile={profile} />
    </main>
  );
}
