export default function PlanLoading() {
  return (
    <main className="mx-auto min-h-screen w-full max-w-7xl px-6 py-10 lg:px-10">
      <section className="surface rounded-[2rem] p-6">
        <p className="text-sm font-medium text-sky-300">Phase 2 / 跳转中</p>
        <h1 className="mt-2 text-3xl font-semibold text-white">正在准备 AI 学习计划页面</h1>
        <p className="mt-3 text-sm leading-7 text-slate-300">
          页面正在载入计划结果组件，稍后会展示本周学习安排。
        </p>
      </section>
    </main>
  );
}
