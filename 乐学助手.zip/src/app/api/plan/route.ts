import { NextResponse } from "next/server";
import { PlanGenerationError, generateWeeklyPlan } from "@/features/planning/service";
import { planRequestSchema } from "@/lib/validations/planner";

export const runtime = "nodejs";

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      {
        code: "INVALID_JSON_BODY",
        message: "请求体不是合法 JSON，请检查提交内容。",
      },
      { status: 400 },
    );
  }

  const parsed = planRequestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: "INVALID_REQUEST_BODY",
        message: "请求参数不完整",
        issues: parsed.error.flatten(),
      },
      { status: 400 },
    );
  }

  try {
    const plan = await generateWeeklyPlan(parsed.data);

    return NextResponse.json({ plan });
  } catch (error) {
    if (error instanceof PlanGenerationError) {
      return NextResponse.json(
        {
          code: error.code,
          message: error.message,
        },
        { status: error.statusCode },
      );
    }

    return NextResponse.json(
      {
        code: "UNKNOWN_ERROR",
        message: "计划生成接口执行失败，请稍后重试。",
      },
      { status: 500 },
    );
  }
}
