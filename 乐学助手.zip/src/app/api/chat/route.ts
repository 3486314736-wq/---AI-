import { NextResponse } from "next/server";
import {
  appendTutorConversationMessages,
  clearPersistedTutorConversation,
  readPersistedTutorConversation,
} from "@/features/tutoring/repository";
import { TutoringError, answerTutorQuestion } from "@/features/tutoring/service";
import { tutoringHistoryQuerySchema, tutoringRequestSchema } from "@/lib/validations/chat";
import type { TutorMessage } from "@/types/chat";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const parsed = tutoringHistoryQuerySchema.safeParse({
    lessonId: searchParams.get("lessonId"),
  });

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: "INVALID_QUERY_PARAMS",
        message: "读取答疑历史时缺少 lessonId。",
        issues: parsed.error.flatten(),
      },
      { status: 400 },
    );
  }

  try {
    const conversation = await readPersistedTutorConversation(parsed.data.lessonId);

    return NextResponse.json({
      lessonId: parsed.data.lessonId,
      messages: conversation?.messages ?? [],
      updatedAt: conversation?.updatedAt ?? null,
      messageCount: conversation?.messages.length ?? 0,
      subject: conversation?.subject ?? null,
      focus: conversation?.focus ?? null,
      lessonTitle: conversation?.lessonTitle ?? null,
    });
  } catch {
    return NextResponse.json(
      {
        code: "LOAD_TUTOR_HISTORY_FAILED",
        message: "读取答疑历史失败，请稍后重试。",
      },
      { status: 500 },
    );
  }
}

export async function DELETE(request: Request) {
  const { searchParams } = new URL(request.url);
  const parsed = tutoringHistoryQuerySchema.safeParse({
    lessonId: searchParams.get("lessonId"),
  });

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: "INVALID_QUERY_PARAMS",
        message: "清空答疑历史时缺少 lessonId。",
        issues: parsed.error.flatten(),
      },
      { status: 400 },
    );
  }

  try {
    await clearPersistedTutorConversation(parsed.data.lessonId);

    return NextResponse.json({
      lessonId: parsed.data.lessonId,
      cleared: true,
    });
  } catch {
    return NextResponse.json(
      {
        code: "CLEAR_TUTOR_HISTORY_FAILED",
        message: "清空答疑历史失败，请稍后重试。",
      },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      {
        code: "INVALID_JSON_BODY",
        message: "请求体不是合法 JSON，请检查提交内容。",
      },
      { status: 400 },
    );
  }

  const parsed = tutoringRequestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: "INVALID_REQUEST_BODY",
        message: "答疑请求参数不完整",
        issues: parsed.error.flatten(),
      },
      { status: 400 },
    );
  }

  try {
    const result = await answerTutorQuestion(parsed.data);
    const createdAt = new Date().toISOString();
    const userMessage: TutorMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: parsed.data.question,
      attachmentName: parsed.data.imageName ?? null,
      createdAt,
      slideId: parsed.data.currentSlide.id,
      slideTitle: parsed.data.currentSlide.title,
    };
    const assistantMessage: TutorMessage = {
      id: crypto.randomUUID(),
      role: "assistant",
      content: result.answer,
      createdAt,
      slideId: parsed.data.currentSlide.id,
      slideTitle: parsed.data.currentSlide.title,
      providerName: result.providerName,
      modelName: result.modelName,
    };
    const conversation = await appendTutorConversationMessages({
      lessonId: parsed.data.lessonId,
      subject: parsed.data.subject,
      focus: parsed.data.focus,
      lessonTitle: parsed.data.lessonTitle,
      messages: [userMessage, assistantMessage],
    });

    return NextResponse.json({
      answer: result.answer,
      providerName: result.providerName,
      modelName: result.modelName,
      messages: [userMessage, assistantMessage],
      updatedAt: conversation.updatedAt,
    });
  } catch (error) {
    if (error instanceof TutoringError) {
      return NextResponse.json(
        {
          code: error.code,
          message: error.message,
        },
        { status: error.statusCode },
      );
    }

    return NextResponse.json(
      {
        code: "UNKNOWN_ERROR",
        message: "多模态答疑接口执行失败，请稍后重试。",
      },
      { status: 500 },
    );
  }
}
