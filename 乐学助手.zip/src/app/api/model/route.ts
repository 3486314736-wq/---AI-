import { NextResponse } from "next/server";
import { getModelProviderStatus } from "@/lib/ai/provider";

export const runtime = "nodejs";

export async function GET() {
  const status = getModelProviderStatus();

  return NextResponse.json({
    configured: Boolean(status.effectiveProvider),
    provider: status.effectiveProvider,
    configuredProvider: status.configuredProvider,
    model: status.modelName,
    preference: status.preference,
    usingFallback: status.usingFallback,
    hasDeepSeekKey: status.hasDeepSeekKey,
    hasOpenAIKey: status.hasOpenAIKey,
    baseURL: status.baseURL,
    message: status.effectiveProvider
      ? `当前将使用 ${status.effectiveProvider} 的 ${status.modelName}。`
      : "当前未检测到可用模型配置，请先设置环境变量。",
  });
}
