import { NextResponse } from "next/server";
import {
  completeLessonCheckIn,
  initializePlanProgress,
  readLessonProgress,
  readPlanProgress,
  upsertLessonProgress,
} from "@/features/progress/repository";
import { readPersistedLessonHistory } from "@/features/lesson-generation/repository";
import { progressPostSchema, progressQuerySchema } from "@/lib/validations/progress";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const parsed = progressQuerySchema.safeParse({
    planId: url.searchParams.get("planId") ?? undefined,
    requestKey: url.searchParams.get("requestKey") ?? undefined,
  });

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: "INVALID_QUERY_PARAMS",
        message: "请提供 planId 或 requestKey。",
        issues: parsed.error.flatten(),
      },
      { status: 400 },
    );
  }

  try {
    if (parsed.data.requestKey) {
      const lessonProgress = await readLessonProgress(parsed.data.requestKey);
      return NextResponse.json({ lessonProgress });
    }

    if (parsed.data.planId) {
      const planProgress = await readPlanProgress(parsed.data.planId);
      return NextResponse.json({ planProgress });
    }

    return NextResponse.json(
      {
        code: "INVALID_QUERY_PARAMS",
        message: "请提供 planId 或 requestKey。",
      },
      { status: 400 },
    );
  } catch {
    return NextResponse.json(
      {
        code: "PROGRESS_READ_FAILED",
        message: "学习进度读取失败，请稍后重试。",
      },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      {
        code: "INVALID_JSON_BODY",
        message: "请求体不是合法 JSON。",
      },
      { status: 400 },
    );
  }

  const parsed = progressPostSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: "INVALID_REQUEST_BODY",
        message: "进度请求参数不完整。",
        issues: parsed.error.flatten(),
      },
      { status: 400 },
    );
  }

  try {
    if (parsed.data.type === "lesson_patch") {
      const persisted = await readPersistedLessonHistory({
        subject: parsed.data.subject,
        focus: parsed.data.focus,
        dayNumber: parsed.data.dayNumber,
      });
      const deck = persisted?.history[0]?.deck ?? null;
      const lessonProgress = await upsertLessonProgress(
        {
          requestKey: parsed.data.requestKey,
          planId: parsed.data.planId ?? null,
          subject: parsed.data.subject,
          focus: parsed.data.focus,
          dayNumber: parsed.data.dayNumber,
          viewedSlideIds: parsed.data.viewedSlideIds,
          quizAnswers: parsed.data.quizAnswers,
          tutorQuestionCount: parsed.data.tutorQuestionCount,
        },
        deck,
      );

      return NextResponse.json({ lessonProgress });
    }

    const persisted = await readPersistedLessonHistory({
      subject: parsed.data.subject,
      focus: parsed.data.focus,
      dayNumber: parsed.data.dayNumber,
    });
    const deck = persisted?.history[0]?.deck;

    if (!deck) {
      return NextResponse.json(
        {
          code: "LESSON_NOT_FOUND",
          message: "请先完成课程生成，再进行打卡。",
        },
        { status: 404 },
      );
    }

    const lessonProgress = await completeLessonCheckIn(
      {
        requestKey: parsed.data.requestKey,
        planId: parsed.data.planId ?? null,
        subject: parsed.data.subject,
        focus: parsed.data.focus,
        dayNumber: parsed.data.dayNumber,
        level: parsed.data.level,
      },
      deck,
    );

    const planProgress = parsed.data.planId
      ? await readPlanProgress(parsed.data.planId)
      : null;

    return NextResponse.json({ lessonProgress, planProgress });
  } catch (error) {
    if (error instanceof Error && error.message === "CHECK_IN_NOT_READY") {
      return NextResponse.json(
        {
          code: "CHECK_IN_NOT_READY",
          message: "还未达到打卡条件，请先完成学习或小测。",
        },
        { status: 400 },
      );
    }

    return NextResponse.json(
      {
        code: "PROGRESS_WRITE_FAILED",
        message: "学习进度保存失败，请稍后重试。",
      },
      { status: 500 },
    );
  }
}

export async function PUT(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      {
        code: "INVALID_JSON_BODY",
        message: "请求体不是合法 JSON。",
      },
      { status: 400 },
    );
  }

  if (
    typeof body !== "object" ||
    body === null ||
    !("planId" in body) ||
    typeof body.planId !== "string" ||
    !("subject" in body) ||
    typeof body.subject !== "string" ||
    !("days" in body) ||
    !Array.isArray(body.days)
  ) {
    return NextResponse.json(
      {
        code: "INVALID_REQUEST_BODY",
        message: "计划进度初始化参数不完整。",
      },
      { status: 400 },
    );
  }

  try {
    const planProgress = await initializePlanProgress(
      body.planId,
      body.subject,
      body.days as Array<{ day: number; topic: string }>,
    );

    return NextResponse.json({ planProgress });
  } catch {
    return NextResponse.json(
      {
        code: "PROGRESS_INIT_FAILED",
        message: "计划进度初始化失败，请稍后重试。",
      },
      { status: 500 },
    );
  }
}
