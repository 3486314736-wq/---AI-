import { NextRequest, NextResponse } from "next/server";
import path from "path";
import fs from "fs/promises";
import { execFile } from "child_process";
import { promisify } from "util";

const execFileAsync = promisify(execFile);

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { deck, lessonId } = body;

    if (!deck) {
      return NextResponse.json({ error: "缺少课程数据" }, { status: 400 });
    }

    console.log("[PPT API] 开始生成PPT...");
    console.log("[PPT API] 课程标题:", deck.title);
    console.log("[PPT API] 幻灯片数量:", deck.slides?.length || 0);

    // 创建临时目录
    const tempDir = path.join(process.cwd(), "public", "temp");
    await fs.mkdir(tempDir, { recursive: true });
    console.log("[PPT API] 临时目录:", tempDir);

    // 生成唯一文件名
    const timestamp = Date.now();
    const safeLessonId = (lessonId || "lesson").replace(/[^a-zA-Z0-9-_]/g, "_");
    const jsonPath = path.join(tempDir, `${safeLessonId}_${timestamp}.json`);
    const pptPath = path.join(tempDir, `${safeLessonId}_${timestamp}.pptx`);
    console.log("[PPT API] JSON路径:", jsonPath);
    console.log("[PPT API] PPT路径:", pptPath);

    // 保存JSON数据
    await fs.writeFile(jsonPath, JSON.stringify(deck, null, 2), "utf-8");
    console.log("[PPT API] JSON数据已保存");

    // 调用Python脚本生成PPT - 使用增强版
    const scriptPath = path.join(process.cwd(), "scripts", "ppt_generator_enhanced.py");
    console.log("[PPT API] 脚本路径:", scriptPath);
    console.log("[PPT API] 正在调用Python脚本...");

    try {
      const { stdout, stderr } = await execFileAsync("python", [scriptPath, jsonPath, pptPath]);
      
      if (stdout) {
        console.log("[PPT API] Python输出:", stdout);
      }
      if (stderr) {
        console.error("[PPT API] Python错误:", stderr);
      }
      
    } catch (error: any) {
      console.error("[PPT API] Python脚本执行失败:", error);
      console.error("[PPT API] 错误详情:", error.message);
      console.error("[PPT API] stdout:", error.stdout);
      console.error("[PPT API] stderr:", error.stderr);
      
      return NextResponse.json(
        { 
          error: "PPT生成失败: " + (error.message || "请检查控制台日志"),
          details: error.stderr || error.stdout 
        },
        { status: 500 }
      );
    }

    // 检查PPT文件是否生成
    try {
      await fs.access(pptPath);
      console.log("[PPT API] PPT文件已成功生成！");
    } catch (e) {
      console.error("[PPT API] PPT文件不存在:", e);
      return NextResponse.json({ error: "PPT文件生成失败" }, { status: 500 });
    }

    // 返回PPT文件的URL
    const pptUrl = `/temp/${safeLessonId}_${timestamp}.pptx`;

    console.log("[PPT API] 成功！返回URL:", pptUrl);
    return NextResponse.json({
      success: true,
      pptUrl: pptUrl,
      fileName: `${safeLessonId}_${timestamp}.pptx`
    });

  } catch (error: any) {
    console.error("[PPT API] API错误:", error);
    return NextResponse.json({ error: error.message || "服务器错误" }, { status: 500 });
  }
}

