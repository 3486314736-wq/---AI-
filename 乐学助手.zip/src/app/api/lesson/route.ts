import { NextResponse } from "next/server";
import {
  readPersistedLessonHistory,
  savePersistedLesson,
} from "@/features/lesson-generation/repository";
import { LessonGenerationError, generateLessonDeck } from "@/features/lesson-generation/service";
import { lessonRequestSchema } from "@/lib/validations/lesson";

export const runtime = "nodejs";

export async function GET(request: Request) {
  const url = new URL(request.url);
  const parsed = lessonRequestSchema.safeParse({
    lessonId: url.searchParams.get("lessonId") ?? undefined,
    subject: url.searchParams.get("subject") ?? undefined,
    focus: url.searchParams.get("focus") ?? undefined,
    dayNumber: url.searchParams.get("dayNumber") ?? undefined,
  });

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: "INVALID_REQUEST_QUERY",
        message: "查询参数不完整",
        issues: parsed.error.flatten(),
      },
      { status: 400 },
    );
  }

  try {
    const persisted = await readPersistedLessonHistory({
      subject: parsed.data.subject,
      focus: parsed.data.focus,
      dayNumber: parsed.data.dayNumber,
    });

    return NextResponse.json({
      lesson: persisted?.history[0]?.deck ?? null,
      history: persisted?.history ?? [],
    });
  } catch {
    return NextResponse.json(
      {
        code: "LESSON_HISTORY_READ_FAILED",
        message: "课程历史读取失败，请稍后重试。",
      },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  let body: unknown;

  try {
    body = await request.json();
  } catch (e) {
    return NextResponse.json(
      {
        code: "INVALID_JSON_BODY",
        message: "请求体不是合法 JSON，请检查提交内容。",
      },
      { status: 400 },
    );
  }

  const parsed = lessonRequestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: "INVALID_REQUEST_BODY",
        message: "请求参数不完整",
        issues: parsed.error.flatten(),
      },
      { status: 400 },
    );
  }

  try {
    const lesson = await generateLessonDeck(parsed.data);
    const persisted = await savePersistedLesson(
      {
        subject: parsed.data.subject,
        focus: parsed.data.focus,
        dayNumber: parsed.data.dayNumber,
      },
      lesson,
    );

    return NextResponse.json({ lesson, history: persisted.history });
  } catch (error) {
    console.error('[API] 课程生成出错:', error);
    if (error instanceof LessonGenerationError) {
      return NextResponse.json(
        {
          code: error.code,
          message: error.message,
        },
        { status: error.statusCode },
      );
    }

    return NextResponse.json(
      {
        code: "UNKNOWN_ERROR",
        message: "课程生成接口执行失败，请稍后重试。",
      },
      { status: 500 },
    );
  }
}
