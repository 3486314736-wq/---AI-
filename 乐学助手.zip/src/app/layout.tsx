import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "乐学小助手 - 中小学生个性化学习",
  description: "从学习画像到每日课程，再到课中答疑，一条链路先跑通。",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" className="h-full antialiased">
      <body className="min-h-full bg-[#FFF9F5] text-[#2D3436]">{children}</body>
    </html>
  );
}
