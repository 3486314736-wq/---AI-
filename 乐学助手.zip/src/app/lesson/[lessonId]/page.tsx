import { LessonClient } from "@/components/slides/lesson-client";
import { parseLessonRouteId } from "@/features/lesson-generation/storage";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export default async function LessonPage({
  params,
  searchParams,
}: {
  params: Promise<{ lessonId: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const { lessonId } = await params;
  const query = await searchParams;
  const parsedRoute = parseLessonRouteId(lessonId);
  const subject =
    typeof query.subject === "string"
      ? query.subject
      : (parsedRoute?.subject ?? "初二物理");
  const focus =
    typeof query.focus === "string" ? query.focus : (parsedRoute?.focus ?? "力和运动的关系");
  const day =
    typeof query.day === "string"
      ? Number(query.day) || 1
      : (parsedRoute?.dayNumber ?? 1);
  const planId = typeof query.planId === "string" ? query.planId : null;

  return <LessonClient subject={subject} focus={focus} dayNumber={day} planId={planId} />;
}
