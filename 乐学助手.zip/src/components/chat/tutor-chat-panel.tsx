"use client";

import type { ChangeEvent, FormEvent } from "react";
import { useEffect, useMemo, useState } from "react";
import { ImagePlus, LoaderCircle, MessageCircleMore, SendHorizontal, Trash2, WandSparkles, X } from "lucide-react";
import type { TutorMessage } from "@/types/chat";
import type { LessonSlide } from "@/types/slide";

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;
const ACCEPTED_IMAGE_TYPES = ["image/png", "image/jpeg", "image/jpg", "image/webp"];

interface TutorChatPanelProps {
  lessonId: string;
  subject: string;
  focus: string;
  lessonTitle: string;
  currentSlide: LessonSlide;
  currentSlideIndex: number;
  totalSlides: number;
  slides: LessonSlide[];
  onJumpToSlide: (index: number) => void;
  onQuestionAnswered?: () => void;
}

interface TutorChatResponse {
  answer: string;
  providerName: string;
  modelName: string;
  messages?: TutorMessage[];
}

interface TutorChatHistoryResponse {
  messages?: TutorMessage[];
  updatedAt?: string | null;
  messageCount?: number;
}

function buildIntroMessage(currentSlide: LessonSlide, currentSlideIndex: number): TutorMessage {
  return {
    id: `assistant-intro-${currentSlide.id}`,
    role: "assistant" as const,
    content: `你好，我会围绕当前第 ${currentSlideIndex + 1} 页“${currentSlide.title}”回答问题。你可以直接提问，也可以上传截图，我会结合这一页的知识点一步一步讲解。`,
    attachmentName: null,
    createdAt: new Date().toISOString(),
    slideId: currentSlide.id,
    slideTitle: currentSlide.title,
  };
}

function parseErrorMessage(payload: unknown) {
  if (
    typeof payload === "object" &&
    payload !== null &&
    "message" in payload &&
    typeof payload.message === "string"
  ) {
    return payload.message;
  }

  return "答疑请求失败，请稍后重试。";
}

function formatUpdatedAt(value: string | null) {
  if (!value) {
    return "本节课还没有历史答疑";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "刚刚更新";
  }

  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function readFileAsDataUrl(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === "string") {
        resolve(reader.result);
        return;
      }

      reject(new Error("截图读取失败，请重新选择图片。"));
    };
    reader.onerror = () => reject(new Error("截图读取失败，请重新选择图片。"));
    reader.readAsDataURL(file);
  });
}

export function TutorChatPanel({
  lessonId,
  subject,
  focus,
  lessonTitle,
  currentSlide,
  currentSlideIndex,
  totalSlides,
  slides,
  onJumpToSlide,
  onQuestionAnswered,
}: TutorChatPanelProps) {
  const [messages, setMessages] = useState<TutorMessage[]>([]);
  const [question, setQuestion] = useState("");
  const [imageDataUrl, setImageDataUrl] = useState<string | undefined>(undefined);
  const [imageName, setImageName] = useState<string | undefined>(undefined);
  const [imageMimeType, setImageMimeType] = useState<
    "image/png" | "image/jpeg" | "image/jpg" | "image/webp" | undefined
  >(undefined);
  const [error, setError] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [isLoadingHistory, setIsLoadingHistory] = useState(true);
  const [updatedAt, setUpdatedAt] = useState<string | null>(null);
  const [messageCount, setMessageCount] = useState(0);
  const [isClearing, setIsClearing] = useState(false);
  const introMessage = useMemo(
    () => buildIntroMessage(currentSlide, currentSlideIndex),
    [currentSlide, currentSlideIndex],
  );
  const displayMessages = messages.length > 0 ? messages : isLoadingHistory ? [] : [introMessage];

  const hintText = useMemo(() => {
    if (currentSlide.kind === "quiz") {
      return "当前是练习页，答疑会优先给思路提示，再补关键步骤。";
    }

    return "当前是讲解页，答疑会优先结合本页要点和截图线索解释。";
  }, [currentSlide.kind]);

  useEffect(() => {
    let cancelled = false;

    void (async () => {
      setIsLoadingHistory(true);

      try {
        const query = new URLSearchParams({ lessonId });
        const response = await fetch(`/api/chat?${query.toString()}`, { method: "GET" });
        const payload = (await response.json()) as TutorChatHistoryResponse | { message?: string };

        if (!response.ok) {
          throw new Error(parseErrorMessage(payload));
        }

        if (!cancelled) {
          const historyPayload = payload as TutorChatHistoryResponse;
          setMessages(Array.isArray(historyPayload.messages) ? historyPayload.messages : []);
          setUpdatedAt(historyPayload.updatedAt ?? null);
          setMessageCount(typeof historyPayload.messageCount === "number" ? historyPayload.messageCount : 0);
          setError(null);
        }
      } catch (historyError) {
        if (!cancelled) {
          setError(historyError instanceof Error ? historyError.message : "读取答疑历史失败，请稍后重试。");
        }
      } finally {
        if (!cancelled) {
          setIsLoadingHistory(false);
        }
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [lessonId]);

  const clearSelectedImage = () => {
    setImageDataUrl(undefined);
    setImageName(undefined);
    setImageMimeType(undefined);
  };

  const handleImageChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = "";

    if (!file) {
      return;
    }

    if (!ACCEPTED_IMAGE_TYPES.includes(file.type)) {
      setError("仅支持 PNG、JPG、JPEG 或 WEBP 格式的截图。");
      return;
    }

    if (file.size > MAX_IMAGE_BYTES) {
      setError("截图过大，请压缩到 3MB 以内后重试。");
      return;
    }

    try {
      const nextDataUrl = await readFileAsDataUrl(file);
      setImageDataUrl(nextDataUrl);
      setImageName(file.name);
      setImageMimeType(file.type as "image/png" | "image/jpeg" | "image/jpg" | "image/webp");
      setError(null);
    } catch (imageError) {
      setError(imageError instanceof Error ? imageError.message : "截图读取失败，请重新选择图片。");
    }
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const trimmedQuestion = question.trim();

    if (!trimmedQuestion) {
      setError("请输入你想问的问题。");
      return;
    }

    const nextUserMessage: TutorMessage = {
      id: crypto.randomUUID(),
      role: "user",
      content: trimmedQuestion,
      attachmentName: imageName ?? null,
      createdAt: new Date().toISOString(),
      slideId: currentSlide.id,
      slideTitle: currentSlide.title,
    };
    const recentMessages = [...messages, nextUserMessage].slice(-6);

    setMessages((currentMessages) => [...currentMessages, nextUserMessage]);
    setQuestion("");
    setError(null);
    setIsSending(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          lessonId,
          subject,
          focus,
          lessonTitle,
          question: trimmedQuestion,
          imageDataUrl,
          imageMimeType,
          imageName,
          currentSlide,
          recentMessages,
        }),
      });

      const payload = (await response.json()) as TutorChatResponse | { message?: string };

      if (!response.ok || !("answer" in payload) || typeof payload.answer !== "string") {
        throw new Error(parseErrorMessage(payload));
      }

      const persistedMessages =
        Array.isArray(payload.messages) && payload.messages.length > 0
          ? payload.messages
          : [
              {
                id: crypto.randomUUID(),
                role: "assistant" as const,
                content: payload.answer,
                createdAt: new Date().toISOString(),
                slideId: currentSlide.id,
                slideTitle: currentSlide.title,
                providerName: payload.providerName,
                modelName: payload.modelName,
              },
            ];
      setMessages((currentMessages) => [...currentMessages, ...persistedMessages.filter((message) => message.role === "assistant")]);
      if ("updatedAt" in payload && typeof payload.updatedAt === "string") {
        setUpdatedAt(payload.updatedAt);
      }
      setMessageCount((currentCount) => currentCount + 2);
      onQuestionAnswered?.();
      clearSelectedImage();
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : "答疑请求失败，请稍后重试。");
    } finally {
      setIsSending(false);
    }
  };

  const handleClearHistory = async () => {
    setIsClearing(true);
    setError(null);

    try {
      const query = new URLSearchParams({ lessonId });
      const response = await fetch(`/api/chat?${query.toString()}`, {
        method: "DELETE",
      });
      const payload = (await response.json()) as { message?: string };

      if (!response.ok) {
        throw new Error(parseErrorMessage(payload));
      }

      setMessages([]);
      setUpdatedAt(null);
      setMessageCount(0);
      clearSelectedImage();
    } catch (clearError) {
      setError(clearError instanceof Error ? clearError.message : "清空答疑历史失败，请稍后重试。");
    } finally {
      setIsClearing(false);
    }
  };

  return (
    <aside className="surface rounded-[2rem] p-4 sm:p-5">
      <div className="flex items-start justify-between gap-3 border-b border-[#FFE8D6] pb-3">
        <div>
          <p className="text-sm font-medium text-[#4ECDC4]">多模态答疑区</p>
          <h2 className="mt-1 text-xl font-bold text-[#2D3436]">围绕“{focus}”提问</h2>
          <p className="mt-2 text-sm leading-7 text-[#64748B]">
            当前上下文：第 {currentSlideIndex + 1} / {totalSlides} 页 · {currentSlide.title}
          </p>
        </div>
        <div className="rounded-xl bg-[#A55EEA]/15 p-2.5 text-[#A55EEA]">
          <WandSparkles className="h-5 w-5" />
        </div>
      </div>

      <div className="mt-4 rounded-[1.25rem] border border-[#4ECDC4]/30 bg-[#4ECDC4]/10 p-3 text-sm leading-7 text-[#2D3436]">
        <p className="font-medium text-[#4ECDC4]">本页提示</p>
        <p className="mt-1.5">{hintText}</p>
        <p className="mt-1.5 text-[#64748B]">新提问会自动绑定当前页面，同时保留这节课已有的问答历史。</p>
      </div>

      <div className="mt-4 rounded-[1.25rem] border border-[#FFE8D6] bg-white p-3">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-sm font-medium text-[#2D3436]">最近会话</p>
            <p className="mt-1.5 text-sm leading-7 text-[#64748B]">最近更新时间：{formatUpdatedAt(updatedAt)}</p>
            <p className="text-sm leading-7 text-[#64748B]">已保存消息数：{messageCount}</p>
          </div>
          <button
            className="btn-secondary inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm disabled:opacity-50"
            disabled={isClearing || messageCount === 0}
            onClick={() => void handleClearHistory()}
            type="button"
          >
            {isClearing ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            {isClearing ? "正在清空..." : "清空历史"}
          </button>
        </div>
      </div>

      <div className="mt-4 space-y-2.5">
        {isLoadingHistory ? (
          <div className="rounded-xl bg-[#FFF9F5] p-3 text-sm leading-7 text-[#64748B]">
            正在恢复这节课的答疑历史...
          </div>
        ) : null}

        {displayMessages.map((message) => (
          <div
            key={message.id}
            className={
              message.role === "assistant"
                ? "rounded-xl bg-[#4ECDC4]/10 p-3 text-sm leading-7 text-[#2D3436]"
                : "rounded-xl bg-[#FFF9F5] p-3 text-sm leading-7 text-[#2D3436]"
            }
          >
            <div className="mb-1.5 flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-[#64748B]">
              <MessageCircleMore className="h-3.5 w-3.5" />
              {message.role === "assistant" ? "Tutor" : "Student"}
            </div>
            <p className="text-sm leading-7">{message.content}</p>
            {message.attachmentName ? (
              <p className="mt-2 text-xs text-[#64748B]">已附截图：{message.attachmentName}</p>
            ) : null}
            {message.slideId ? (
              <button
                className="mt-1.5 text-xs text-[#4ECDC4] transition hover:text-[#FF6B6B]"
                onClick={() => {
                  const slideIndex = slides.findIndex((slide) => slide.id === message.slideId);
                  if (slideIndex >= 0) {
                    onJumpToSlide(slideIndex);
                  }
                }}
                type="button"
              >
                关联页面：{message.slideTitle ?? `第 ${slides.findIndex((slide) => slide.id === message.slideId) + 1} 页`}
                （点击跳转）
              </button>
            ) : null}
          </div>
        ))}
      </div>

      {error ? (
        <div className="mt-4 rounded-[1.25rem] border border-[#FFD93D]/30 bg-[#FFD93D]/10 p-3 text-sm leading-7 text-[#2D3436]">
          {error}
        </div>
      ) : null}

      <form className="mt-4 space-y-3" onSubmit={(event) => void handleSubmit(event)}>
        <label className="block rounded-[1.25rem] border border-dashed border-[#FFE8D6] bg-[#FFF9F5] p-3 text-sm text-[#64748B] transition hover:border-[#4ECDC4]/30 hover:bg-[#4ECDC4]/5 card-hover">
          <span className="flex items-center gap-2 text-[#2D3436]">
            <ImagePlus className="h-4 w-4 text-[#4ECDC4]" />
            上传当前问题截图
          </span>
          <span className="mt-1.5 block leading-7 text-[#64748B]">
            支持 PNG、JPG、JPEG、WEBP，大小不超过 3MB。
          </span>
          <input
            accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp"
            className="sr-only"
            onChange={(event) => void handleImageChange(event)}
            type="file"
          />
        </label>

        {imageName ? (
          <div className="rounded-[1.25rem] border border-[#FFE8D6] bg-white p-3 text-sm text-[#2D3436]">
            <div className="flex items-center justify-between gap-3">
              <div>
                <p className="font-medium text-[#2D3436]">已选择截图</p>
                <p className="mt-1.5 text-[#64748B]">{imageName}</p>
              </div>
              <button
                className="btn-secondary inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm"
                onClick={clearSelectedImage}
                type="button"
              >
                <X className="h-4 w-4" />
                移除
              </button>
            </div>
          </div>
        ) : null}

        <div className="rounded-[1.25rem] border border-[#FFE8D6] bg-white p-3">
          <label className="text-sm font-medium text-[#2D3436]" htmlFor={`tutor-question-${currentSlide.id}`}>
            输入问题
          </label>
          <textarea
            id={`tutor-question-${currentSlide.id}`}
            className="mt-2.5 min-h-24 w-full rounded-xl border border-[#FFE8D6] bg-[#FFF9F5] px-3 py-2.5 text-sm leading-7 text-[#2D3436] outline-none transition placeholder:text-[#9CA3AF] focus:border-[#4ECDC4]/50"
            maxLength={300}
            onChange={(event) => setQuestion(event.target.value)}
            placeholder={`例如：第 ${currentSlideIndex + 1} 页这里为什么要这样理解？如果截图里的式子看不懂，也可以一起上传。`}
            value={question}
          />
          <div className="mt-2.5 flex items-center justify-between gap-3 text-xs text-[#64748B]">
            <span>答疑会结合当前页标题、要点、示例和最近几轮消息作答。</span>
            <span>{question.length}/300</span>
          </div>
        </div>

        <button
          className="btn-primary inline-flex w-full items-center justify-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-semibold disabled:cursor-not-allowed"
          disabled={isSending}
          type="submit"
        >
          {isSending ? <LoaderCircle className="h-4 w-4 animate-spin" /> : <SendHorizontal className="h-4 w-4" />}
          {isSending ? "正在生成答疑..." : "发送问题"}
        </button>
      </form>
    </aside>
  );
}
