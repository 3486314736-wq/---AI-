"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { getPlanStorageKey } from "@/features/planning/storage";
import {
  plannerSchema,
  type PlannerFormValues,
  type PlannerInput,
} from "@/lib/validations/planner";
import type { WeeklyPlan } from "@/types/plan";

export function LearnerProfileForm() {
  const router = useRouter();
  const [submitError, setSubmitError] = useState<string | null>(null);
  const defaults = useMemo<PlannerFormValues>(
    () => ({
      subject: "",
      stage: "",
      challenge: "",
      dailyMinutes: 60,
      goal: "",
    }),
    [],
  );

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<PlannerFormValues, undefined, PlannerInput>({
    resolver: zodResolver(plannerSchema),
    defaultValues: defaults,
  });

  const onSubmit = handleSubmit(async (values) => {
    setSubmitError(null);

    try {
      const planId = crypto.randomUUID();
      const response = await fetch("/api/plan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...values,
          planId,
        }),
      });

      const payload = (await response.json()) as {
        message?: string;
        plan?: WeeklyPlan;
      };

      if (!response.ok || !payload.plan) {
        throw new Error(payload.message ?? "AI 学习计划生成失败，请稍后重试。");
      }

      sessionStorage.setItem(
        getPlanStorageKey(payload.plan.id),
        JSON.stringify({
          plan: payload.plan,
          profile: values,
        }),
      );

      const query = new URLSearchParams({
        subject: values.subject,
        stage: values.stage,
        challenge: values.challenge,
        dailyMinutes: String(values.dailyMinutes),
        goal: values.goal,
      });

      router.push(`/plan/${payload.plan.id}?${query.toString()}`);
    } catch (error) {
      setSubmitError(
        error instanceof Error ? error.message : "AI 学习计划生成失败，请稍后重试。",
      );
    }
  });

  return (
    <form className="space-y-6" onSubmit={onSubmit}>
      <div>
        <p className="text-sm font-medium text-[#4ECDC4]">输入学习画像</p>
        <h2 className="mt-2 text-2xl font-bold text-[#2D3436]">生成一周学习计划</h2>
        <p className="mt-2 text-sm leading-7 text-[#64748B]">
          表单结构已经按后续 Agent 输入 schema 设计，Phase 2 可直接接入模型生成。
        </p>
      </div>

      <label className="block text-sm font-medium text-[#2D3436]">
        学科与年级
        <input
          {...register("subject")}
          className="input-field mt-2 w-full"
          placeholder="例如：初二物理"
        />
        {errors.subject ? <p className="mt-2 text-xs text-[#FF6B6B]">{errors.subject.message}</p> : null}
      </label>

      <label className="block text-sm font-medium text-[#2D3436]">
        当前学习阶段
        <textarea
          {...register("stage")}
          className="input-field mt-2 w-full min-h-24 resize-none"
          placeholder="例如：力学基础薄弱，受力分析不熟"
        />
        {errors.stage ? <p className="mt-2 text-xs text-[#FF6B6B]">{errors.stage.message}</p> : null}
      </label>

      <label className="block text-sm font-medium text-[#2D3436]">
        主要困难
        <textarea
          {...register("challenge")}
          className="input-field mt-2 w-full min-h-24 resize-none"
          placeholder="例如：题目一综合就不知道从哪一步下手"
        />
        {errors.challenge ? (
          <p className="mt-2 text-xs text-[#FF6B6B]">{errors.challenge.message}</p>
        ) : null}
      </label>

      <label className="block text-sm font-medium text-[#2D3436]">
        每日可学习时长（分钟）
        <input
          {...register("dailyMinutes")}
          className="input-field mt-2 w-full"
          inputMode="numeric"
          placeholder="60"
          type="number"
        />
        {errors.dailyMinutes ? (
          <p className="mt-2 text-xs text-[#FF6B6B]">{errors.dailyMinutes.message}</p>
        ) : null}
      </label>

      <label className="block text-sm font-medium text-[#2D3436]">
        一周目标
        <textarea
          {...register("goal")}
          className="input-field mt-2 w-full min-h-24 resize-none"
          placeholder="例如：补基础，能完成老师布置的基础与中档题"
        />
        {errors.goal ? <p className="mt-2 text-xs text-[#FF6B6B]">{errors.goal.message}</p> : null}
      </label>

      <button
        className="btn-primary inline-flex w-full items-center justify-center rounded-2xl px-6 py-4 text-lg font-semibold"
        disabled={isSubmitting}
        type="submit"
      >
        {isSubmitting ? "正在调用 AI 生成..." : "生成 7 天计划 ✨"}
      </button>

      {submitError ? (
        <div className="rounded-2xl border border-[#FF6B6B]/20 bg-[#FF6B6B]/10 px-5 py-4 text-sm leading-7 text-[#FF6B6B]">
          {submitError}
        </div>
      ) : null}
    </form>
  );
}
