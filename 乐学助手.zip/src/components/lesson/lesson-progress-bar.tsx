"use client";

import type { LessonDeck } from "@/types/slide";

interface LessonProgressBarProps {
  deck: LessonDeck;
  viewedSlideIds: string[];
}

export function LessonProgressBar({ deck, viewedSlideIds }: LessonProgressBarProps) {
  const viewedCount = deck.slides.filter((slide) => viewedSlideIds.includes(slide.id)).length;
  const percent = deck.slides.length > 0 ? Math.round((viewedCount / deck.slides.length) * 100) : 0;

  return (
    <div className="rounded-3xl border border-[#FFE8D6] bg-white px-4 py-3">
      <div className="flex items-center justify-between gap-3 text-sm">
        <span className="text-[#64748B]">学习进度</span>
        <span className="font-medium text-[#2D3436]">
          {viewedCount} / {deck.slides.length} 页 · {percent}%
        </span>
      </div>
      <div className="mt-3 h-2 overflow-hidden rounded-full bg-[#FFE8D6]">
        <div
          className="h-full rounded-full gradient-bg transition-all duration-300"
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
}
