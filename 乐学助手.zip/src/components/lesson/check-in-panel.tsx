"use client";

import { CalendarCheck2, LoaderCircle } from "lucide-react";
import type { CheckInLevel } from "@/types/progress";

interface CheckInPanelProps {
  eligibleLevel: CheckInLevel | null;
  checkInStatus: "not_started" | "in_progress" | "completed";
  checkInLevel: CheckInLevel | null;
  requirements: {
    light: string;
    standard: string;
    full: string;
  };
  isSubmitting: boolean;
  error: string | null;
  onCheckIn: () => void;
}

function getLevelLabel(level: CheckInLevel | null) {
  switch (level) {
    case "full":
      return "完整打卡";
    case "standard":
      return "标准打卡";
    case "light":
      return "轻量打卡";
    default:
      return null;
  }
}

export function CheckInPanel({
  eligibleLevel,
  checkInStatus,
  checkInLevel,
  requirements,
  isSubmitting,
  error,
  onCheckIn,
}: CheckInPanelProps) {
  const isCompleted = checkInStatus === "completed";

  return (
    <section className="surface rounded-[2rem] p-5">
      <div className="flex flex-col lg:flex-row items-stretch gap-4">
        {/* 左边：文字信息 - 50% */}
        <div className="lg:w-1/2">
          <div className="flex items-start gap-3">
            <div className="rounded-2xl bg-[#4ECDC4]/15 p-3 text-[#4ECDC4]">
              <CalendarCheck2 className="h-5 w-5" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-medium text-[#4ECDC4]">今日打卡</p>
              <h2 className="mt-1 text-xl font-bold text-[#2D3436]">
                {isCompleted
                  ? `已完成${getLevelLabel(checkInLevel) ?? "打卡"}`
                  : "完成学习后即可打卡"}
              </h2>
              <div className="mt-3 space-y-2 text-sm leading-7 text-[#64748B]">
                <p>轻量：{requirements.light}</p>
                <p>标准：{requirements.standard}</p>
                <p>完整：{requirements.full}</p>
              </div>
            </div>
          </div>
        </div>

        {/* 右边：按钮区域 - 50%，居中 */}
        <div className="lg:w-1/2 flex flex-col items-center justify-center gap-3">
          {error ? (
            <p className="rounded-2xl border border-[#FF6B6B]/20 bg-[#FF6B6B]/10 px-4 py-3 text-sm text-[#FF6B6B] w-full text-center max-w-[320px]">
              {error}
            </p>
          ) : null}

          {isCompleted ? (
            <span className="inline-flex items-center justify-center rounded-2xl border border-[#4ECDC4]/20 bg-[#4ECDC4]/10 px-6 py-4 text-lg font-medium text-[#4ECDC4] w-full max-w-[320px]">
              今日已记录学习，可在计划页查看本周进度
            </span>
          ) : (
            <button
              className="btn-primary inline-flex items-center justify-center gap-2 rounded-2xl px-6 py-4 text-lg font-semibold disabled:cursor-not-allowed w-full max-w-[320px]"
              disabled={!eligibleLevel || isSubmitting}
              onClick={onCheckIn}
              type="button"
            >
              {isSubmitting ? <LoaderCircle className="h-6 w-6 animate-spin" /> : <CalendarCheck2 className="h-6 w-6" />}
              {eligibleLevel
                ? `完成今日${getLevelLabel(eligibleLevel) ?? "打卡"}`
                : "继续学习以解锁打卡"}
            </button>
          )}
          {!isCompleted && eligibleLevel ? (
            <span className="text-base text-[#64748B] text-center">当前可达到：{getLevelLabel(eligibleLevel)}</span>
          ) : null}
        </div>
      </div>
    </section>
  );
}
