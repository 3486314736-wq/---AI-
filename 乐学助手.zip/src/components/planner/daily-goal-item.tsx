import { Clock3, Sparkles } from "lucide-react";
import type { DayCheckInStatus } from "@/types/progress";
import type { DailyPlan } from "@/types/plan";

export function DailyGoalItem({
  day,
  status = "not_started",
}: {
  day: DailyPlan;
  status?: DayCheckInStatus;
}) {
  const statusLabel =
    status === "completed" ? "已打卡 ✓" : status === "in_progress" ? "进行中…" : "未开始";

  return (
    <div className="rounded-2xl border border-[#FFE8D6] bg-white p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-sm font-medium text-[#4ECDC4]">第 {day.day} 天</p>
          <h3 className="mt-1 text-lg font-bold text-[#2D3436]">{day.topic}</h3>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#FFE8D6] bg-white px-3 py-1 text-xs text-[#64748B]">
            <Clock3 className="h-3.5 w-3.5" />
            {day.durationMinutes} 分钟
          </div>
          <span
            className={`rounded-full border px-3 py-1 text-xs font-semibold ${
              status === "completed"
                ? "border-[#4ECDC4]/50 bg-[#4ECDC4]/10 text-[#4ECDC4]"
                : status === "in_progress"
                  ? "border-[#FFD93D]/50 bg-[#FFD93D]/10 text-[#FFD93D]"
                  : "border-[#FFE8D6] bg-white text-[#64748B]"
            }`}
          >
            {statusLabel}
          </span>
        </div>
      </div>

      <p className="mt-3 text-sm leading-7 text-[#64748B]">{day.goal}</p>

      <div className="mt-4 flex items-start gap-2 rounded-2xl bg-[#A55EEA]/10 px-4 py-3 text-sm text-[#A55EEA]">
        <Sparkles className="mt-0.5 h-4 w-4 shrink-0" />
        <span>{day.coachTip}</span>
      </div>
    </div>
  );
}
