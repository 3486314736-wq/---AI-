"use client";

import Link from "next/link";
import { buildLessonHref } from "@/features/lesson-generation/storage";
import type { PlanProgress } from "@/types/progress";
import type { LearnerProfile, WeeklyPlan } from "@/types/plan";

interface WeeklyProgressStripProps {
  plan: WeeklyPlan;
  profile: LearnerProfile;
  planProgress: PlanProgress | null;
  recommendedDay: number;
}

function getDayTone(status: PlanProgress["days"][number]["status"], day: number, recommendedDay: number) {
  if (status === "completed") {
    return "border-[#4ECDC4]/50 bg-[#4ECDC4]/15 text-[#4ECDC4]";
  }

  if (status === "in_progress") {
    return "border-[#FFD93D]/50 bg-[#FFD93D]/15 text-[#FFD93D]";
  }

  if (day === recommendedDay) {
    return "border-[#FF6B6B]/50 bg-[#FF6B6B]/15 text-[#FF6B6B]";
  }

  return "border-[#FFE8D6] bg-white/50 text-[#64748B]";
}

export function WeeklyProgressStrip({
  plan,
  profile,
  planProgress,
  recommendedDay,
}: WeeklyProgressStripProps) {
  const completedCount = planProgress?.completedDayCount ?? 0;
  const streak = planProgress?.streak ?? 0;

  return (
    <section className="surface rounded-[2rem] p-5 sm:p-6">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <p className="text-sm font-medium text-[#4ECDC4]">本周学习进度</p>
          <h2 className="mt-2 text-2xl font-bold text-[#2D3436]">
            已完成 {completedCount} / 7 天
            {streak > 0 ? ` · 连续 ${streak} 天 🎉` : ""}
          </h2>
          <p className="mt-2 text-sm text-[#64748B]">
            建议今天学习第 {recommendedDay} 天，完成课程与小测后可打卡。
          </p>
        </div>

        <Link
          href={buildLessonHref({
            subject: profile.subject,
            focus: plan.days.find((day) => day.day === recommendedDay)?.topic ?? plan.days[0]?.topic ?? "",
            dayNumber: recommendedDay,
            planId: plan.id,
          })}
          className="btn-primary inline-flex items-center justify-center rounded-2xl px-6 py-3 text-sm font-semibold"
        >
          开始今日学习 ✨
        </Link>
      </div>

      <div className="mt-6 grid grid-cols-7 gap-2">
        {plan.days.map((day) => {
          const progressDay = planProgress?.days.find((entry) => entry.day === day.day);
          const status = progressDay?.status ?? "not_started";

          return (
            <Link
              key={day.day}
              href={buildLessonHref({
                subject: profile.subject,
                focus: day.topic,
                dayNumber: day.day,
                planId: plan.id,
              })}
              className={`card-hover rounded-2xl border px-2 py-4 text-center transition hover:opacity-90 ${getDayTone(status, day.day, recommendedDay)}`}
              title={day.topic}
            >
              <p className="text-xs font-bold">D{day.day}</p>
              <p className="mt-2 text-xl font-bold">
                {status === "completed" ? "✓" : status === "in_progress" ? "…" : "○"}
              </p>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
