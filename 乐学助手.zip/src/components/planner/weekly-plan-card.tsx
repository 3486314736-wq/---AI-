import Link from "next/link";
import { ArrowRight, Star } from "lucide-react";
import { buildLessonHref } from "@/features/lesson-generation/storage";
import type { PlanProgress } from "@/types/progress";
import type { LearnerProfile, WeeklyPlan } from "@/types/plan";
import { DailyGoalItem } from "./daily-goal-item";

export function WeeklyPlanCard({
  plan,
  profile,
  planId,
  planProgress,
}: {
  plan: WeeklyPlan;
  profile: LearnerProfile;
  planId: string;
  planProgress: PlanProgress | null;
}) {
  return (
    <section className="grid gap-6 xl:grid-cols-[1.4fr_0.72fr]">
      <div className="surface rounded-[2rem] p-5 sm:p-6">
        <div className="flex items-center justify-between gap-4 border-b border-[#FFE8D6] pb-4">
          <div>
            <h2 className="text-2xl font-bold text-[#2D3436]">一周时间表 📅</h2>
            <p className="mt-2 text-sm leading-7 text-[#64748B]">
              {plan.source === "llm"
                ? "当前结果由大模型生成，已按结构化 JSON 渲染为可执行的一周安排。"
                : "当前页使用 mock 计划数据，但结构已对齐后续 JSON 输出格式。"}
            </p>
          </div>
          <div className="rounded-2xl bg-[#4ECDC4]/10 px-5 py-3 text-right text-sm text-[#2D3436]">
            <p className="font-medium">预计总时长</p>
            <p className="mt-1 text-lg font-bold">{plan.totalMinutes} 分钟</p>
          </div>
        </div>

        <div className="mt-6 grid gap-4">
          {plan.days.map((day) => (
            <div key={day.day} className="space-y-4">
              <DailyGoalItem
                day={day}
                status={planProgress?.days.find((entry) => entry.day === day.day)?.status ?? "not_started"}
              />
              <div className="flex justify-end">
                <Link
                  href={buildLessonHref({
                    subject: profile.subject,
                    focus: day.topic,
                    dayNumber: day.day,
                    planId,
                  })}
                  className="btn-secondary inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold"
                >
                  开始今日学习
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>

      <aside className="space-y-6">
        <div className="surface rounded-[2rem] p-5">
          <h2 className="text-xl font-bold text-[#2D3436] flex items-center gap-2">
            <Star className="h-5 w-5 text-[#FFD93D]" />
            本周目标
          </h2>
          <p className="mt-3 text-sm leading-7 text-[#64748B]">{profile.goal}</p>
        </div>

        <div className="surface rounded-[2rem] p-5">
          <h2 className="text-xl font-bold text-[#2D3436]">学习提醒 💡</h2>
          <ul className="mt-4 space-y-3 text-sm leading-7 text-[#64748B]">
            <li>每天先学新知识，再做 1 组针对练习。</li>
            <li>第 4 天安排回顾，避免前学后忘。</li>
            <li>课程页将预留截图提问入口，便于随学随问。</li>
          </ul>
        </div>
      </aside>
    </section>
  );
}
