"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState } from "react";
import { AlertCircle, ArrowLeft, RefreshCw } from "lucide-react";
import { WeeklyPlanCard } from "@/components/planner/weekly-plan-card";
import { WeeklyProgressStrip } from "@/components/planner/weekly-progress-strip";
import { getRecommendedDayNumber } from "@/features/progress/compute";
import { getPlanStorageKey } from "@/features/planning/storage";
import type { PlanProgress } from "@/types/progress";
import type { LearnerProfile, WeeklyPlan } from "@/types/plan";

interface PlanResultClientProps {
  planId: string;
  profile: LearnerProfile;
}

interface PlanApiResponse {
  plan: WeeklyPlan;
}

function parseErrorMessage(payload: unknown) {
  if (
    typeof payload === "object" &&
    payload !== null &&
    "message" in payload &&
    typeof payload.message === "string"
  ) {
    return payload.message;
  }

  return "AI 计划生成失败，请稍后重试。";
}

export function PlanResultClient({ planId, profile }: PlanResultClientProps) {
  const router = useRouter();
  const [plan, setPlan] = useState<WeeklyPlan | null>(null);
  const [planProgress, setPlanProgress] = useState<PlanProgress | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const syncPlanProgress = useCallback(async (nextPlan: WeeklyPlan, nextProfile: LearnerProfile) => {
    await fetch("/api/progress", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        planId: nextPlan.id,
        subject: nextProfile.subject,
        days: nextPlan.days.map((day) => ({ day: day.day, topic: day.topic })),
      }),
    });

    const response = await fetch(`/api/progress?planId=${encodeURIComponent(nextPlan.id)}`);
    const payload = (await response.json()) as { planProgress?: PlanProgress | null };

    if (response.ok && payload.planProgress) {
      setPlanProgress(payload.planProgress);
    }
  }, []);

  const generatePlan = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/plan", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...profile,
          planId,
        }),
      });

      const payload = (await response.json()) as PlanApiResponse | { message?: string };

      if (!response.ok || !("plan" in payload) || !payload.plan) {
        throw new Error(parseErrorMessage(payload));
      }

      setPlan(payload.plan);
      sessionStorage.setItem(
        getPlanStorageKey(planId),
        JSON.stringify({
          plan: payload.plan,
          profile,
        }),
      );
      await syncPlanProgress(payload.plan, profile);
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : "AI 计划生成失败，请稍后重试。",
      );
    } finally {
      setIsLoading(false);
    }
  }, [planId, profile, syncPlanProgress]);

  useEffect(() => {
    async function initializePlan() {
      const cachedValue = sessionStorage.getItem(getPlanStorageKey(planId));

      if (cachedValue) {
        try {
          const parsed = JSON.parse(cachedValue) as { plan?: WeeklyPlan };

          if (parsed.plan) {
            setPlan(parsed.plan);
            await syncPlanProgress(parsed.plan, profile);
            setIsLoading(false);
            return;
          }
        } catch {
          sessionStorage.removeItem(getPlanStorageKey(planId));
        }
      }

      await generatePlan();
    }

    void initializePlan();
  }, [generatePlan, planId, profile, syncPlanProgress]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <section className="surface rounded-[2rem] p-6">
          <p className="text-sm font-medium text-[#4ECDC4]">Phase 2 / AI 生成中 ✨</p>
          <h2 className="mt-2 text-3xl font-bold text-[#2D3436]">正在生成个性化一周计划</h2>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-[#64748B]">
            系统正在根据学生画像调用大模型生成结构化 7 天学习安排，请稍候。
          </p>
        </section>

        <div className="grid gap-4 xl:grid-cols-[1.4fr_0.72fr]">
          <div className="surface rounded-[2rem] p-6">
            <div className="h-6 w-40 animate-pulse rounded-full bg-[#2D3436]/8" />
            <div className="mt-6 space-y-4">
              {Array.from({ length: 3 }).map((_, index) => (
                <div key={index} className="rounded-2xl border border-[#FFE8D6] bg-white p-4">
                  <div className="h-5 w-28 animate-pulse rounded-full bg-[#2D3436]/8" />
                  <div className="mt-3 h-4 w-full animate-pulse rounded-full bg-[#2D3436]/8" />
                  <div className="mt-2 h-4 w-3/4 animate-pulse rounded-full bg-[#2D3436]/8" />
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <div className="surface rounded-[2rem] p-6">
              <div className="h-5 w-24 animate-pulse rounded-full bg-[#2D3436]/8" />
              <div className="mt-4 h-4 w-full animate-pulse rounded-full bg-[#2D3436]/8" />
              <div className="mt-2 h-4 w-5/6 animate-pulse rounded-full bg-[#2D3436]/8" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !plan) {
    return (
      <section className="surface rounded-[2rem] p-6">
        <div className="flex items-start gap-3">
          <div className="rounded-2xl bg-[#FF6B6B]/10 p-3 text-[#FF6B6B]">
            <AlertCircle className="h-5 w-5" />
          </div>
          <div>
            <p className="text-sm font-medium text-[#FF6B6B]">Phase 2 / 计划生成失败</p>
            <h2 className="mt-2 text-2xl font-bold text-[#2D3436]">暂时无法生成 AI 计划</h2>
            <p className="mt-3 max-w-3xl text-sm leading-7 text-[#64748B]">
              {error ?? "未获取到学习计划结果。"}
            </p>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap gap-3">
          <button
            className="btn-primary inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold"
            onClick={() => void generatePlan()}
            type="button"
          >
            <RefreshCw className="h-4 w-4" />
            重新生成
          </button>
          <button
            className="btn-secondary inline-flex items-center rounded-2xl px-5 py-3 text-sm font-semibold"
            onClick={() => router.push("/planner")}
            type="button"
          >
            返回重填
          </button>
        </div>
      </section>
    );
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <Link
            href="/planner"
            className="inline-flex items-center gap-2 text-sm text-[#64748B] transition hover:text-[#2D3436]"
          >
            <ArrowLeft className="h-4 w-4" />
            返回重新填写
          </Link>
          <p className="mt-4 text-sm font-medium text-[#4ECDC4]">Phase 2 / AI 规划结果页</p>
          <h1 className="mt-2 text-4xl font-bold text-[#2D3436]">{plan.title}</h1>
          <p className="mt-3 max-w-3xl text-base leading-8 text-[#64748B]">{plan.summary}</p>
        </div>

        <div className="surface rounded-3xl px-6 py-4 text-sm text-[#2D3436]">
          <p className="font-medium">📚 学科：{profile.subject}</p>
          <p>🎯 当前阶段：{profile.stage}</p>
          <p>⏱️ 每日时长：{profile.dailyMinutes} 分钟</p>
        </div>
      </div>

      <WeeklyProgressStrip
        plan={plan}
        profile={profile}
        planProgress={planProgress}
        recommendedDay={getRecommendedDayNumber(planProgress?.startedAt ?? new Date().toISOString())}
      />
      <WeeklyPlanCard
        plan={plan}
        profile={profile}
        planId={plan.id}
        planProgress={planProgress}
      />
    </div>
  );
}
