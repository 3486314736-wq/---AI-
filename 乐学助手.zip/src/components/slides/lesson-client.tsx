"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState, useRef } from "react";
import { AlertCircle, ArrowLeft, History, RefreshCw, Home, Download } from "lucide-react";
import { TutorChatPanel } from "@/components/chat/tutor-chat-panel";
import { CheckInPanel } from "@/components/lesson/check-in-panel";
import { LessonProgressBar } from "@/components/lesson/lesson-progress-bar";
import { SlideRenderer } from "@/components/slides/slide-renderer";
import { computeCheckInLevel, getCheckInRequirements } from "@/features/progress/compute";
import {
  type LessonHistoryEntry,
  getLessonHistoryStorageKey,
  getLessonRequestKey,
  getLessonStorageKey,
  mergeLessonHistory,
} from "@/features/lesson-generation/storage";
import type { LessonProgress, QuizAnswerRecord } from "@/types/progress";
import type { LessonDeck, LessonSlide } from "@/types/slide";

interface LessonApiResponse {
  lesson: LessonDeck;
  history?: LessonHistoryEntry[];
}

interface LessonHistoryResponse {
  lesson: LessonDeck | null;
  history: LessonHistoryEntry[];
}

interface LessonClientProps {
  subject: string;
  focus: string;
  dayNumber: number;
  planId: string | null;
}

interface LessonProgressResponse {
  lessonProgress?: LessonProgress | null;
}

function parseErrorMessage(payload: unknown) {
  if (
    typeof payload === "object" &&
    payload !== null &&
    "message" in payload &&
    typeof payload.message === "string"
  ) {
    return payload.message;
  }

  return "课程生成失败，请稍后重试或检查模型与搜索配置。";
}

function formatGeneratedAt(value: string) {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "刚刚生成";
  }

  return new Intl.DateTimeFormat("zh-CN", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

function readCachedLesson(storageKey: string) {
  if (typeof window === "undefined") {
    return null;
  }

  try {
    const raw = sessionStorage.getItem(storageKey);

    if (!raw) {
      return null;
    }

    return JSON.parse(raw) as LessonDeck;
  } catch {
    sessionStorage.removeItem(storageKey);
    return null;
  }
}

function readCachedHistory(storageKey: string) {
  if (typeof window === "undefined") {
    return [] as LessonHistoryEntry[];
  }

  try {
    const raw = sessionStorage.getItem(storageKey);

    if (!raw) {
      return [] as LessonHistoryEntry[];
    }

    const parsed = JSON.parse(raw) as LessonHistoryEntry[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    sessionStorage.removeItem(storageKey);
    return [] as LessonHistoryEntry[];
  }
}

export function LessonClient({ subject, focus, dayNumber, planId }: LessonClientProps) {
  console.log('[LessonClient] 组件开始渲染，参数:', { subject, focus, dayNumber, planId });
  
  const requestKey = useMemo(
    () =>
      getLessonRequestKey({
        subject,
        focus,
        dayNumber,
      }),
    [dayNumber, focus, subject],
  );
  const scopedLessonId = requestKey;
  const lessonStorageKey = useMemo(() => getLessonStorageKey(requestKey), [requestKey]);
  const historyStorageKey = useMemo(() => getLessonHistoryStorageKey(requestKey), [requestKey]);
  const [deck, setDeck] = useState<LessonDeck | null>(null);
  const [history, setHistory] = useState<LessonHistoryEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true); // 始终先显示加载状态
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [activeSlideIndex, setActiveSlideIndex] = useState(0);
  const [lessonProgress, setLessonProgress] = useState<LessonProgress | null>(null);
  const [checkInError, setCheckInError] = useState<string | null>(null);
  const [isCheckingIn, setIsCheckingIn] = useState(false);
  const [isExportingPpt, setIsExportingPpt] = useState(false);
  const hasInitializedRef = useRef(false);

  const patchLessonProgress = useCallback(
    async (patch: {
      viewedSlideIds?: string[];
      quizAnswers?: QuizAnswerRecord[];
      tutorQuestionCount?: number;
    }) => {
      const response = await fetch("/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "lesson_patch",
          requestKey,
          planId,
          subject,
          focus,
          dayNumber,
          ...patch,
        }),
      });
      const payload = (await response.json()) as LessonProgressResponse & { message?: string };

      if (!response.ok || !payload.lessonProgress) {
        throw new Error(payload.message ?? "学习进度保存失败。");
      }

      setLessonProgress(payload.lessonProgress);
      return payload.lessonProgress;
    },
    [dayNumber, focus, planId, requestKey, subject],
  );

  const loadLessonProgress = useCallback(async () => {
    const response = await fetch(`/api/progress?requestKey=${encodeURIComponent(requestKey)}`);
    const payload = (await response.json()) as LessonProgressResponse;

    if (response.ok && payload.lessonProgress) {
      setLessonProgress(payload.lessonProgress);
      return;
    }

    await patchLessonProgress({});
  }, [patchLessonProgress, requestKey]);

  useEffect(() => {
    const timeoutId = window.setTimeout(() => {
      void loadLessonProgress();
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, [loadLessonProgress]);

  useEffect(() => {
    if (!deck?.slides.length) {
      return;
    }

    const slide = deck.slides[activeSlideIndex];

    if (!slide) {
      return;
    }

    const timeoutId = window.setTimeout(() => {
      void patchLessonProgress({
        viewedSlideIds: [slide.id],
      }).catch(() => {});
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, [activeSlideIndex, deck, patchLessonProgress]);

  const handleActiveSlideChange = useCallback(
    (index: number) => {
      setActiveSlideIndex(index);

      if (!deck) {
        return;
      }

      const slide = deck.slides[index];

      if (!slide) {
        return;
      }

      void patchLessonProgress({
        viewedSlideIds: [slide.id],
      }).catch(() => {});
    },
    [deck, patchLessonProgress],
  );

  const handleQuizSubmit = useCallback(
    async (answers: QuizAnswerRecord[]) => {
      await patchLessonProgress({ quizAnswers: answers });
    },
    [patchLessonProgress],
  );

  const handleQuestionAnswered = useCallback(() => {
    void patchLessonProgress({
      tutorQuestionCount: (lessonProgress?.tutorQuestionCount ?? 0) + 1,
    }).catch(() => {});
  }, [lessonProgress?.tutorQuestionCount, patchLessonProgress]);

  const handleCheckIn = useCallback(async () => {
    setIsCheckingIn(true);
    setCheckInError(null);

    try {
      const response = await fetch("/api/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "check_in",
          requestKey,
          planId,
          subject,
          focus,
          dayNumber,
        }),
      });
      const payload = (await response.json()) as LessonProgressResponse & { message?: string };

      if (!response.ok || !payload.lessonProgress) {
        throw new Error(payload.message ?? "打卡失败，请继续完成学习后再试。");
      }

      setLessonProgress(payload.lessonProgress);
    } catch (checkInRequestError) {
      setCheckInError(
        checkInRequestError instanceof Error ? checkInRequestError.message : "打卡失败，请稍后重试。",
      );
    } finally {
      setIsCheckingIn(false);
    }
  }, [dayNumber, focus, planId, requestKey, subject]);

  const handleExportPpt = useCallback(async () => {
    if (!deck) {
      return;
    }

    setIsExportingPpt(true);
    try {
      const response = await fetch("/api/ppt", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          deck,
          lessonId: scopedLessonId,
        }),
      });

      if (!response.ok) {
        const error = (await response.json()) as { error?: string };
        throw new Error(error.error || "PPT生成失败");
      }

      const result = (await response.json()) as { pptUrl: string; fileName: string };

      // 下载文件
      const a = document.createElement("a");
      a.href = result.pptUrl;
      a.download = `${deck.title}_${Date.now()}.pptx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

    } catch (error) {
      console.error("导出PPT失败:", error);
      alert(`导出PPT失败：${error instanceof Error ? error.message : "未知错误"}`);
    } finally {
      setIsExportingPpt(false);
    }
  }, [deck, scopedLessonId]);

  const persistLesson = useCallback(
    (nextDeck: LessonDeck, nextHistoryFromServer?: LessonHistoryEntry[]) => {
      console.log('[LessonClient] persistLesson 被调用', nextDeck.title);
      const currentHistory = (() => {
        try {
          const raw = sessionStorage.getItem(historyStorageKey);

          if (!raw) {
            return [] as LessonHistoryEntry[];
          }

          const parsed = JSON.parse(raw) as LessonHistoryEntry[];
          return Array.isArray(parsed) ? parsed : [];
        } catch {
          return [] as LessonHistoryEntry[];
        }
      })();

      const nextHistory = nextHistoryFromServer ?? mergeLessonHistory(nextDeck, currentHistory);
      sessionStorage.setItem(lessonStorageKey, JSON.stringify(nextDeck));
      sessionStorage.setItem(historyStorageKey, JSON.stringify(nextHistory));
      setDeck(nextDeck);
      setHistory(nextHistory);
      setIsLoading(false); // 确保设置 isLoading 为 false
      console.log('[LessonClient] persistLesson 完成，isLoading 设为 false');
    },
    [historyStorageKey, lessonStorageKey],
  );

  const loadPersistedLesson = useCallback(async () => {
    console.log('[LessonClient] loadPersistedLesson 开始，参数:', { subject, focus, dayNumber });
    const query = new URLSearchParams({
      lessonId: scopedLessonId,
      subject,
      focus,
      dayNumber: String(dayNumber),
    });
    
    try {
      const response = await fetch(`/api/lesson?${query.toString()}`, {
        method: "GET",
      });
      console.log('[LessonClient] loadPersistedLesson 响应状态:', response.status);
      
      const payload = (await response.json()) as LessonHistoryResponse | { message?: string };
      console.log('[LessonClient] loadPersistedLesson 响应数据:', payload);

      if (!response.ok) {
        throw new Error(parseErrorMessage(payload));
      }

      if ("lesson" in payload && payload.lesson) {
        console.log('[LessonClient] loadPersistedLesson 找到历史课程，调用 persistLesson');
        persistLesson(payload.lesson, payload.history);
        // persistLesson 内部会调用 setIsLoading(false)
        return true;
      }

      if ("history" in payload && Array.isArray(payload.history)) {
        console.log('[LessonClient] loadPersistedLesson 只找到历史记录');
        sessionStorage.setItem(historyStorageKey, JSON.stringify(payload.history));
        setHistory(payload.history);
      }

      console.log('[LessonClient] loadPersistedLesson 返回 false，没有可用课程');
      return false;
    } catch (error) {
      console.error('[LessonClient] 加载历史课程出错:', error);
      throw error;
    }
  }, [dayNumber, focus, historyStorageKey, persistLesson, scopedLessonId, subject]);

  const generateLesson = useCallback(
    async (forceRefresh = false) => {
      console.log('[LessonClient] generateLesson 开始，forceRefresh:', forceRefresh);
      if (forceRefresh) {
        setIsRefreshing(true);
      } else {
        setIsLoading(true);
      }
      setError(null);

      try {
        console.log('[LessonClient] generateLesson 发送 POST 请求');
        const response = await fetch("/api/lesson", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            lessonId: scopedLessonId,
            subject,
            focus,
            dayNumber,
          }),
        });

        console.log('[LessonClient] generateLesson 响应状态:', response.status);
        const payload = (await response.json()) as LessonApiResponse | { message?: string };
        console.log('[LessonClient] generateLesson 响应数据:', payload);

        if (!response.ok || !("lesson" in payload) || !payload.lesson) {
          throw new Error(parseErrorMessage(payload));
        }

        console.log('[LessonClient] generateLesson 课程生成成功，调用 persistLesson');
        persistLesson(payload.lesson, payload.history);
      } catch (requestError) {
        console.error('[LessonClient] generateLesson 出错:', requestError);
        setError(
          requestError instanceof Error
            ? requestError.message
            : "课程生成失败，请稍后重试或检查模型与搜索配置。",
        );
      } finally {
        setIsLoading(false);
        setIsRefreshing(false);
        console.log('[LessonClient] generateLesson finally 块执行，isLoading 设为 false');
      }
    },
    [dayNumber, focus, persistLesson, scopedLessonId, subject],
  );

  // 从 sessionStorage 读取缓存（仅在客户端）
  useEffect(() => {
    const cachedDeck = readCachedLesson(lessonStorageKey);
    const cachedHistory = readCachedHistory(historyStorageKey);
    if (cachedDeck) {
      console.log('[LessonClient] 从缓存读取 deck:', cachedDeck.title);
      setDeck(cachedDeck);
    }
    if (cachedHistory.length > 0) {
      console.log('[LessonClient] 从缓存读取 history:', cachedHistory.length, '条');
      setHistory(cachedHistory);
    }
  }, [lessonStorageKey, historyStorageKey]);

  useEffect(() => {
    console.log('[LessonClient] 主 useEffect 运行');
    if (hasInitializedRef.current) {
      console.log('[LessonClient] 已初始化，跳过');
      return;
    }
    
    const timeoutId = window.setTimeout(() => {
      void (async () => {
        console.log('[LessonClient] 开始初始化流程');
        try {
          console.log('[LessonClient] 尝试加载历史课程');
          const loaded = await loadPersistedLesson();
          console.log('[LessonClient] loadPersistedLesson 返回:', loaded);

          if (loaded) {
            console.log('[LessonClient] 历史课程加载成功，设置 isLoading=false');
            setIsLoading(false);
            hasInitializedRef.current = true;
            return;
          }
          
          if (!deck) {
            console.log('[LessonClient] 没有历史也没有缓存，开始生成新课程');
            await generateLesson();
          } else {
            console.log('[LessonClient] 有缓存，直接显示');
            setIsLoading(false);
          }
          hasInitializedRef.current = true;
        } catch (requestError) {
          console.error('[LessonClient] 初始化流程出错:', requestError);
          if (!deck) {
            console.log('[LessonClient] 没有缓存，尝试生成课程');
            try {
              await generateLesson();
            } catch (e) {
              console.error('[LessonClient] 生成课程也失败:', e);
              setError(e instanceof Error ? e.message : "未知错误");
              setIsLoading(false);
            }
          } else {
            console.log('[LessonClient] 有缓存，显示缓存');
            setError(requestError instanceof Error ? requestError.message : "加载历史失败，但有本地缓存");
            setIsLoading(false);
          }
          hasInitializedRef.current = true;
        }
        console.log('[LessonClient] 初始化流程完成');
      })();
    }, 0);

    return () => window.clearTimeout(timeoutId);
  }, []);

  const handleUseHistory = (entry: LessonHistoryEntry) => {
    sessionStorage.setItem(lessonStorageKey, JSON.stringify(entry.deck));
    setDeck(entry.deck);
  };

  if (isLoading && !deck) {
    return (
      <main className="mx-auto min-h-screen w-full max-w-7xl px-6 py-10 lg:px-10 bg-[#FFF9F5]">
        <section className="surface rounded-[2rem] p-6">
          <p className="text-sm font-medium text-[#4ECDC4]">Phase 3 / 课程生成中 ✨</p>
          <h1 className="mt-2 text-3xl font-bold text-[#2D3436]">正在生成今日课程</h1>
          <p className="mt-3 max-w-3xl text-sm leading-7 text-[#64748B]">
            系统正在围绕当前主题检索资料并生成结构化课件，请稍候。
          </p>
        </section>
      </main>
    );
  }

  if (!deck) {
    return (
      <main className="mx-auto min-h-screen w-full max-w-7xl px-6 py-10 lg:px-10 bg-[#FFF9F5]">
        <section className="surface rounded-[2rem] p-6">
          <Link
            href="/planner"
            className="inline-flex items-center gap-2 text-sm text-[#64748B] transition hover:text-[#2D3436]"
          >
            <ArrowLeft className="h-4 w-4" />
            返回规划入口
          </Link>

          <div className="mt-6 flex items-start gap-3">
            <div className="rounded-2xl bg-[#FF6B6B]/10 p-3 text-[#FF6B6B]">
              <AlertCircle className="h-5 w-5" />
            </div>
            <div>
              <p className="text-sm font-medium text-[#FF6B6B]">Phase 3 / 课程生成失败</p>
              <h1 className="mt-2 text-3xl font-bold text-[#2D3436]">暂时无法生成今日课程</h1>
              <p className="mt-3 max-w-3xl text-sm leading-7 text-[#64748B]">
                {error ?? "课程生成失败，请稍后重试或检查模型与搜索配置。"}
              </p>
              <p className="mt-2 text-sm leading-7 text-[#64748B]">
                当前主题：{subject} / {focus} / 第 {dayNumber} 天
              </p>
            </div>
          </div>

          <div className="mt-6 flex flex-wrap gap-3">
            <button
              className="btn-primary inline-flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-semibold"
              onClick={() => void generateLesson(true)}
              type="button"
            >
              <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
              重新生成课程
            </button>
          </div>
        </section>
      </main>
    );
  }

  const effectiveActiveSlideIndex = Math.min(activeSlideIndex, Math.max(deck.slides.length - 1, 0));
  const currentSlide: LessonSlide = deck.slides[effectiveActiveSlideIndex] ?? deck.slides[0];
  const viewedSlideIds = lessonProgress?.viewedSlideIds ?? [];
  const quizAnswers = lessonProgress?.quizAnswers ?? [];
  const eligibleLevel = lessonProgress
    ? computeCheckInLevel(deck, lessonProgress)
    : computeCheckInLevel(deck, {
        viewedSlideIds: [],
        quizAnswers: [],
        tutorQuestionCount: 0,
        sessionStartedAt: new Date().toISOString(),
      });
  const checkInRequirements = getCheckInRequirements(deck);

  return (
    <main className="mx-auto min-h-screen w-full max-w-7xl px-6 py-10 lg:px-10 bg-[#FFF9F5]">
      <div className="mb-6 flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
        <div>
          <div className="flex items-center gap-3 mb-4">
            <Link
              href="/"
              className="btn-secondary inline-flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold"
            >
              <Home className="h-3.5 w-3.5" />
              返回首页
            </Link>
            <Link
              href={planId ? `/plan/${planId}` : "/planner"}
              className="inline-flex items-center gap-2 text-sm text-[#64748B] transition hover:text-[#2D3436]"
            >
              <ArrowLeft className="h-4 w-4" />
              {planId ? "返回本周计划" : "返回规划入口"}
            </Link>
          </div>
          <p className="text-sm font-medium text-[#4ECDC4]">今日课程 · 第 {dayNumber} 天</p>
          <h1 className="mt-2 text-4xl font-bold text-[#2D3436]">{deck.title}</h1>
          <p className="mt-3 max-w-3xl text-base leading-8 text-[#64748B]">{deck.description}</p>
        </div>

        <div className="flex flex-col gap-3">
          <div className="rounded-3xl border border-[#4ECDC4]/30 bg-[#4ECDC4]/10 px-4 py-3 text-sm text-[#2D3436]">
            当前为 Web 幻灯片预览，可读取缓存、重新生成并查看最近历史版本。
          </div>
          <div className="rounded-3xl border border-[#FFE8D6] bg-white px-4 py-3 text-sm text-[#64748B]">
            最近生成：{formatGeneratedAt(deck.generatedAt)}
          </div>
          <div className="rounded-3xl border border-[#FFE8D6] bg-white px-4 py-3 text-sm text-[#64748B]">
            当前答疑上下文：第 {effectiveActiveSlideIndex + 1} 页 · {currentSlide.title}
          </div>
        </div>
      </div>

      {error ? (
        <div className="mb-6 rounded-3xl border border-[#FFD93D]/30 bg-[#FFD93D]/10 px-4 py-3 text-sm leading-7 text-[#FFD93D]">
          本次重新生成失败，已保留上一次可用课程内容。错误信息：{error}
        </div>
      ) : null}

      <div className="mb-6">
        <LessonProgressBar deck={deck} viewedSlideIds={viewedSlideIds} />
      </div>

      {/* 主内容：PPT 和答疑区域 - 优化比例，填满空间 */}
      <div className="mb-6 grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
        <SlideRenderer
          deck={deck}
          activeSlideIndex={effectiveActiveSlideIndex}
          viewedSlideIds={viewedSlideIds}
          quizAnswers={quizAnswers}
          onActiveSlideChange={handleActiveSlideChange}
          onSubmitQuizAnswers={handleQuizSubmit}
        />
        <TutorChatPanel
          lessonId={scopedLessonId}
          subject={subject}
          focus={focus}
          lessonTitle={deck.title}
          currentSlide={currentSlide}
          currentSlideIndex={effectiveActiveSlideIndex}
          totalSlides={deck.slides.length}
          slides={deck.slides}
          onJumpToSlide={handleActiveSlideChange}
          onQuestionAnswered={handleQuestionAnswered}
        />
      </div>

      <div className="mb-6">
        <CheckInPanel
          eligibleLevel={eligibleLevel}
          checkInStatus={lessonProgress?.checkInStatus ?? "not_started"}
          checkInLevel={lessonProgress?.checkInLevel ?? null}
          requirements={checkInRequirements}
          isSubmitting={isCheckingIn}
          error={checkInError}
          onCheckIn={() => void handleCheckIn()}
        />
      </div>

      {/* 底部：缓存与重新生成模块 */}
      <div className="grid gap-4 lg:grid-cols-[1.1fr_0.9fr]">
        <div className="surface rounded-[2rem] p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm font-medium text-[#4ECDC4]">课程操作</p>
              <h2 className="mt-2 text-xl font-bold text-[#2D3436]">导出与重新生成</h2>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                className="btn-secondary inline-flex items-center gap-2 rounded-2xl px-4 py-2 text-sm font-semibold disabled:cursor-not-allowed"
                disabled={isExportingPpt || !deck}
                onClick={() => void handleExportPpt()}
                type="button"
              >
                <Download className={`h-4 w-4 ${isExportingPpt ? "animate-spin" : ""}`} />
                {isExportingPpt ? "正在生成PPT..." : "导出PPT"}
              </button>
              <button
                className="btn-primary inline-flex items-center gap-2 rounded-2xl px-4 py-2 text-sm font-semibold disabled:cursor-not-allowed"
                disabled={isRefreshing}
                onClick={() => void generateLesson(true)}
                type="button"
              >
                <RefreshCw className={`h-4 w-4 ${isRefreshing ? "animate-spin" : ""}`} />
                {isRefreshing ? "正在重新生成..." : "重新生成课程"}
              </button>
            </div>
          </div>
          <p className="mt-3 text-sm leading-7 text-[#64748B]">
            当前主题：{subject} / {focus} / 第 {dayNumber} 天。导出PPT会生成一份完整的教学课件供阅读。
          </p>
        </div>

        <div className="surface rounded-[2rem] p-5">
          <div className="flex items-center gap-2 text-sm font-medium text-[#2D3436]">
            <History className="h-4 w-4 text-[#4ECDC4]" />
            最近课程历史
          </div>
          <div className="mt-4 space-y-3">
            {history.length > 0 ? (
              history.map((entry, index) => (
                <button
                  key={entry.versionId}
                  className={`w-full rounded-2xl border px-4 py-3 text-left text-sm transition ${
                    deck.generatedAt === entry.generatedAt
                      ? "border-[#4ECDC4]/50 bg-[#4ECDC4]/10 text-[#2D3436]"
                      : "border-[#FFE8D6] bg-white text-[#64748B] hover:bg-[#4ECDC4]/5"
                  }`}
                  onClick={() => handleUseHistory(entry)}
                  type="button"
                >
                  版本 {history.length - index} · {formatGeneratedAt(entry.generatedAt)}
                </button>
              ))
            ) : (
              <p className="text-sm leading-7 text-[#64748B]">当前还没有可切换的历史版本。</p>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
