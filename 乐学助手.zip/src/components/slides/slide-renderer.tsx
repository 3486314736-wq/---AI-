"use client";

import { CheckCircle2, HelpCircle } from "lucide-react";
import { QuizSlidePanel } from "@/components/slides/quiz-slide-panel";
import type { QuizAnswerRecord } from "@/types/progress";
import type { LessonDeck } from "@/types/slide";

interface SlideRendererProps {
  deck: LessonDeck;
  activeSlideIndex: number;
  viewedSlideIds: string[];
  quizAnswers: QuizAnswerRecord[];
  onActiveSlideChange: (index: number) => void;
  onSubmitQuizAnswers: (answers: QuizAnswerRecord[]) => Promise<void>;
}

export function SlideRenderer({
  deck,
  activeSlideIndex,
  viewedSlideIds,
  quizAnswers,
  onActiveSlideChange,
  onSubmitQuizAnswers,
}: SlideRendererProps) {
  const activeSlide = deck.slides[activeSlideIndex] ?? deck.slides[0];

  return (
    <section className="surface rounded-[2rem] p-4 sm:p-5">
      <div className="flex items-center justify-between gap-4 border-b border-[#FFE8D6] pb-3">
        <div>
          <p className="text-sm font-medium text-[#4ECDC4]">Web 幻灯片预览</p>
          <h2 className="mt-1 text-xl font-bold text-[#2D3436]">
            第 {activeSlideIndex + 1} 页 / 共 {deck.slides.length} 页
          </h2>
        </div>
        <div className="rounded-xl bg-[#4ECDC4]/10 px-3 py-2 text-sm text-[#2D3436]">
          已浏览 {viewedSlideIds.length} 页
        </div>
      </div>

      <div className="mt-4 grid gap-4 xl:grid-cols-[0.7fr_1.3fr]">
        <div className="rounded-[1.5rem] border border-[#FFE8D6] bg-white p-3">
          <p className="text-sm font-medium text-[#2D3436]">课程目录</p>
          <div className="mt-3 space-y-2">
            {deck.slides.map((slide, index) => {
              const isViewed = viewedSlideIds.includes(slide.id);

              return (
                <button
                  key={slide.id}
                  className={`w-full rounded-xl border px-3 py-2.5 text-left text-sm transition card-hover ${
                    index === activeSlideIndex
                      ? "border-[#4ECDC4]/50 bg-[#4ECDC4]/15 text-[#2D3436]"
                      : "border-[#FFE8D6] bg-[#FFF9F5] text-[#64748B]"
                  }`}
                  onClick={() => onActiveSlideChange(index)}
                  type="button"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="inline-flex items-center gap-2">
                      第 {index + 1} 页
                      {isViewed ? (
                        <span className="rounded-full bg-[#4ECDC4]/20 px-1.5 py-0.5 text-[10px] text-[#4ECDC4] font-bold">
                          已读
                        </span>
                      ) : null}
                    </span>
                    <span className="text-xs text-[#64748B]">
                      {slide.kind === "quiz" ? "小测" : "讲解"}
                    </span>
                  </div>
                  <p className="mt-1.5 line-clamp-2 text-sm">{slide.title}</p>
                </button>
              );
            })}
          </div>
        </div>

        <article className="rounded-[1.5rem] border border-[#FFE8D6] bg-white p-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-sm font-medium text-[#4ECDC4]">第 {activeSlideIndex + 1} 页</p>
              <h3 className="mt-1 text-lg font-bold text-[#2D3436]">{activeSlide.title}</h3>
            </div>
            <div className="rounded-full border border-[#FFE8D6] bg-[#FFF9F5] px-3 py-1 text-xs text-[#64748B] font-medium">
              {activeSlide.kind === "quiz" ? "课后小测" : "知识讲解"}
            </div>
          </div>

          <p className="mt-3 text-sm leading-7 text-[#64748B]">{activeSlide.summary}</p>

          {activeSlide.kind === "quiz" ? (
            <QuizSlidePanel
              slide={activeSlide}
              savedAnswers={quizAnswers}
              onSubmitAnswers={onSubmitQuizAnswers}
            />
          ) : (
            <>
              <div className="mt-4 grid gap-3 lg:grid-cols-2">
                <div className="rounded-xl border border-[#4ECDC4]/30 bg-[#4ECDC4]/10 p-3">
                  <div className="flex items-center gap-2 text-sm font-medium text-[#2D3436]">
                    <CheckCircle2 className="h-4 w-4 text-[#4ECDC4]" />
                    核心要点
                  </div>
                  <ul className="mt-2.5 space-y-2.5 text-sm leading-7 text-[#64748B]">
                    {activeSlide.bullets.map((bullet) => (
                      <li key={bullet}>{bullet}</li>
                    ))}
                  </ul>
                </div>

                <div className="rounded-xl border border-[#A55EEA]/30 bg-[#A55EEA]/10 p-3">
                  <div className="flex items-center gap-2 text-sm font-medium text-[#2D3436]">
                    <HelpCircle className="h-4 w-4 text-[#A55EEA]" />
                    示例或提问
                  </div>
                  <p className="mt-2.5 text-sm leading-7 text-[#64748B]">{activeSlide.example}</p>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-3">
                <button
                  className="btn-secondary inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50"
                  disabled={activeSlideIndex === 0}
                  onClick={() => onActiveSlideChange(Math.max(0, activeSlideIndex - 1))}
                  type="button"
                >
                  上一页
                </button>
                <button
                  className="btn-primary inline-flex items-center gap-2 rounded-xl px-3.5 py-2.5 text-sm font-semibold disabled:cursor-not-allowed disabled:opacity-50"
                  disabled={activeSlideIndex === deck.slides.length - 1}
                  onClick={() =>
                    onActiveSlideChange(Math.min(deck.slides.length - 1, activeSlideIndex + 1))
                  }
                  type="button"
                >
                  下一页
                </button>
              </div>
            </>
          )}
        </article>
      </div>
    </section>
  );
}
