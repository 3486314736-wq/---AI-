"use client";

import { useMemo, useState } from "react";
import { CheckCircle2, CircleAlert, Sparkles } from "lucide-react";
import { deriveQuizQuestions } from "@/lib/quiz";
import type { QuizAnswerRecord } from "@/types/progress";
import type { LessonSlide } from "@/types/slide";

interface QuizSlidePanelProps {
  slide: LessonSlide;
  savedAnswers: QuizAnswerRecord[];
  onSubmitAnswers: (answers: QuizAnswerRecord[]) => Promise<void>;
}

export function QuizSlidePanel({ slide, savedAnswers, onSubmitAnswers }: QuizSlidePanelProps) {
  const questions = useMemo(() => deriveQuizQuestions(slide), [slide]);
  const [selections, setSelections] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};

    for (const answer of savedAnswers) {
      initial[answer.questionId] = answer.selectedOptionId;
    }

    return initial;
  });
  const [revealed, setRevealed] = useState(savedAnswers.length > 0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const score = useMemo(() => {
    if (!revealed) {
      return null;
    }

    const correctCount = questions.filter(
      (question) => selections[question.id] === question.correctOptionId,
    ).length;

    return {
      correctCount,
      total: questions.length,
    };
  }, [questions, revealed, selections]);

  const handleSubmit = async () => {
    const unanswered = questions.filter((question) => !selections[question.id]);

    if (unanswered.length > 0) {
      setError(`还有 ${unanswered.length} 道题未作答。`);
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      const answers: QuizAnswerRecord[] = questions.map((question) => ({
        questionId: question.id,
        selectedOptionId: selections[question.id] ?? "",
        correct: selections[question.id] === question.correctOptionId,
        answeredAt: new Date().toISOString(),
      }));

      await onSubmitAnswers(answers);
      setRevealed(true);
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "小测提交失败，请稍后重试。");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="mt-5 space-y-5">
      {questions.map((question, index) => {
        const selectedOptionId = selections[question.id];
        const isCorrect = revealed && selectedOptionId === question.correctOptionId;

        return (
          <article
            key={question.id}
            className="rounded-2xl border border-[#FFE8D6] bg-white p-4"
          >
            <p className="text-sm font-medium text-[#4ECDC4]">第 {index + 1} 题</p>
            <h4 className="mt-2 text-base font-bold text-[#2D3436]">{question.stem}</h4>

            <div className="mt-4 space-y-2">
              {question.options.map((option) => {
                const isSelected = selectedOptionId === option.id;
                const showCorrect = revealed && option.id === question.correctOptionId;
                const showWrong = revealed && isSelected && !showCorrect;

                return (
                  <button
                    key={option.id}
                    className={`w-full rounded-2xl border px-4 py-3 text-left text-sm transition card-hover ${
                      showCorrect
                        ? "border-[#4ECDC4]/50 bg-[#4ECDC4]/10 text-[#2D3436]"
                        : showWrong
                          ? "border-[#FF6B6B]/50 bg-[#FF6B6B]/10 text-[#2D3436]"
                          : isSelected
                            ? "border-[#A55EEA]/50 bg-[#A55EEA]/10 text-[#2D3436]"
                            : "border-[#FFE8D6] bg-[#FFF9F5] text-[#64748B]"
                    }`}
                    disabled={revealed}
                    onClick={() =>
                      setSelections((current) => ({
                        ...current,
                        [question.id]: option.id,
                      }))
                    }
                    type="button"
                  >
                    {option.text}
                  </button>
                );
              })}
            </div>

            {revealed ? (
              <p className="mt-3 flex items-start gap-2 text-sm leading-7 text-[#64748B]">
                {isCorrect ? (
                  <CheckCircle2 className="mt-1 h-4 w-4 shrink-0 text-[#4ECDC4]" />
                ) : (
                  <CircleAlert className="mt-1 h-4 w-4 shrink-0 text-[#FFD93D]" />
                )}
                <span>{question.explanation}</span>
              </p>
            ) : null}
          </article>
        );
      })}

      {error ? (
        <p className="rounded-2xl border border-[#FF6B6B]/30 bg-[#FF6B6B]/10 px-4 py-3 text-sm text-[#FF6B6B]">
          {error}
        </p>
      ) : null}

      <div className="flex flex-wrap items-center gap-3">
        {!revealed ? (
          <button
            className="btn-primary inline-flex items-center gap-2 rounded-2xl px-4 py-2 text-sm font-semibold disabled:cursor-not-allowed"
            disabled={isSubmitting}
            onClick={() => void handleSubmit()}
            type="button"
          >
            <Sparkles className="h-4 w-4" />
            {isSubmitting ? "提交中..." : "提交小测答案"}
          </button>
        ) : score ? (
          <div className="rounded-2xl border border-[#4ECDC4]/30 bg-[#4ECDC4]/10 px-4 py-3 text-sm text-[#2D3436]">
            小测得分：{score.correctCount} / {score.total}
            {score.correctCount === score.total ? "，全部正确，太棒了！" : "，错题可看解析，也可在右侧继续提问。"}
          </div>
        ) : null}
      </div>
    </div>
  );
}
