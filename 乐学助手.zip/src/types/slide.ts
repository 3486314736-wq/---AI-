export interface QuizOption {
  id: string;
  text: string;
}

export interface QuizQuestion {
  id: string;
  stem: string;
  options: QuizOption[];
  correctOptionId: string;
  explanation: string;
}

export interface LessonSlide {
  id: string;
  kind: "content" | "quiz";
  title: string;
  summary: string;
  bullets: string[];
  example: string;
  questions?: QuizQuestion[];
}

export interface LessonSource {
  title: string;
  url: string;
  snippet: string;
  score?: number;
}

export interface LessonDeck {
  id: string;
  title: string;
  description: string;
  generatedAt: string;
  searchSummary?: string | null;
  sources: LessonSource[];
  source: "mock" | "llm";
  slides: LessonSlide[];
}
