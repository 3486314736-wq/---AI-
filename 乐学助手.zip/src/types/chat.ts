export interface TutorMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  attachmentName?: string | null;
  attachmentUrl?: string | null;
  createdAt?: string;
  slideId?: string;
  slideTitle?: string;
  providerName?: string;
  modelName?: string;
}
