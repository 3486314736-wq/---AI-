export interface LearnerProfile {
  subject: string;
  stage: string;
  challenge: string;
  dailyMinutes: number;
  goal: string;
}

export interface DailyPlan {
  day: number;
  topic: string;
  durationMinutes: number;
  goal: string;
  coachTip: string;
}

export interface WeeklyPlan {
  id: string;
  title: string;
  summary: string;
  totalMinutes: number;
  source: "mock" | "llm";
  days: DailyPlan[];
}
