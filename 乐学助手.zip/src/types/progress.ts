export type DayCheckInStatus = "not_started" | "in_progress" | "completed";

export type CheckInLevel = "light" | "standard" | "full";

export interface QuizAnswerRecord {
  questionId: string;
  selectedOptionId: string;
  correct: boolean;
  answeredAt: string;
}

export interface LessonProgress {
  requestKey: string;
  planId: string | null;
  subject: string;
  focus: string;
  dayNumber: number;
  viewedSlideIds: string[];
  quizAnswers: QuizAnswerRecord[];
  tutorQuestionCount: number;
  sessionStartedAt: string;
  lastVisitedAt: string;
  checkInStatus: DayCheckInStatus;
  checkInLevel: CheckInLevel | null;
  completedAt: string | null;
}

export interface PlanDayProgress {
  day: number;
  topic: string;
  status: DayCheckInStatus;
  checkInLevel: CheckInLevel | null;
  completedAt: string | null;
  requestKey: string | null;
}

export interface PlanProgress {
  planId: string;
  subject: string;
  startedAt: string;
  updatedAt: string;
  days: PlanDayProgress[];
  completedDayCount: number;
  streak: number;
}
