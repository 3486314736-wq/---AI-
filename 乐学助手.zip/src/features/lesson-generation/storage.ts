import type { LessonDeck } from "@/types/slide";

export interface LessonRequestDescriptor {
  subject: string;
  focus: string;
  dayNumber: number;
  planId?: string;
}

export interface LessonHistoryEntry {
  versionId: string;
  generatedAt: string;
  deck: LessonDeck;
}

const LESSON_HISTORY_LIMIT = 4;

export function getLessonRequestKey({ subject, focus, dayNumber }: LessonRequestDescriptor) {
  return `${subject}__${focus}__day-${dayNumber}`;
}

export function getLessonRouteId(request: LessonRequestDescriptor) {
  return getLessonRequestKey(request);
}

export function parseLessonRouteId(routeId: string): LessonRequestDescriptor | null {
  const decoded = decodeURIComponent(routeId);
  const daySuffixMatch = decoded.match(/__day-(\d+)$/);

  if (!daySuffixMatch) {
    return null;
  }

  const dayNumber = Number(daySuffixMatch[1]);

  if (!Number.isInteger(dayNumber) || dayNumber < 1 || dayNumber > 7) {
    return null;
  }

  const subjectAndFocus = decoded.slice(0, -daySuffixMatch[0].length);
  const separatorIndex = subjectAndFocus.indexOf("__");

  if (separatorIndex <= 0 || separatorIndex >= subjectAndFocus.length - 2) {
    return null;
  }

  const subject = subjectAndFocus.slice(0, separatorIndex);
  const focus = subjectAndFocus.slice(separatorIndex + 2);

  if (!subject || !focus) {
    return null;
  }

  return { subject, focus, dayNumber };
}

export function buildLessonHref(request: LessonRequestDescriptor) {
  const query = new URLSearchParams({
    subject: request.subject,
    focus: request.focus,
    day: String(request.dayNumber),
  });

  if (request.planId) {
    query.set("planId", request.planId);
  }

  return `/lesson/${encodeURIComponent(getLessonRouteId(request))}?${query.toString()}`;
}

export function getLessonStorageKey(requestKey: string) {
  return `lesson-cache:${requestKey}`;
}

export function getLessonHistoryStorageKey(requestKey: string) {
  return `lesson-history:${requestKey}`;
}

export function buildLessonHistoryEntry(deck: LessonDeck): LessonHistoryEntry {
  return {
    versionId: `${deck.id}:${deck.generatedAt}`,
    generatedAt: deck.generatedAt,
    deck,
  };
}

export function mergeLessonHistory(deck: LessonDeck, existingHistory: LessonHistoryEntry[]) {
  const nextEntry = buildLessonHistoryEntry(deck);

  return [nextEntry, ...existingHistory.filter((entry) => entry.versionId !== nextEntry.versionId)].slice(
    0,
    LESSON_HISTORY_LIMIT,
  );
}
