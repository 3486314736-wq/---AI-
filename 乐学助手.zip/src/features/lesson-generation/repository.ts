import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import {
  type LessonRequestDescriptor,
  buildLessonHistoryEntry,
  getLessonRequestKey,
  mergeLessonHistory,
} from "@/features/lesson-generation/storage";
import type { LessonDeck } from "@/types/slide";

export interface PersistedLessonHistory {
  requestKey: string;
  subject: string;
  focus: string;
  dayNumber: number;
  history: ReturnType<typeof buildLessonHistoryEntry>[];
}

const DATA_DIRECTORY = path.join(process.cwd(), ".data", "lessons");

function toFileName(requestKey: string) {
  return `${Buffer.from(requestKey).toString("base64url")}.json`;
}

function getLessonFilePath(request: LessonRequestDescriptor) {
  const requestKey = getLessonRequestKey(request);
  return path.join(DATA_DIRECTORY, toFileName(requestKey));
}

async function ensureDataDirectory() {
  await mkdir(DATA_DIRECTORY, { recursive: true });
}

export async function readPersistedLessonHistory(
  request: LessonRequestDescriptor,
): Promise<PersistedLessonHistory | null> {
  try {
    const filePath = getLessonFilePath(request);
    const raw = await readFile(filePath, "utf8");
    return JSON.parse(raw) as PersistedLessonHistory;
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "ENOENT") {
      return null;
    }

    throw error;
  }
}

export async function savePersistedLesson(
  request: LessonRequestDescriptor,
  deck: LessonDeck,
): Promise<PersistedLessonHistory> {
  await ensureDataDirectory();

  const current = await readPersistedLessonHistory(request);
  const nextHistory = mergeLessonHistory(deck, current?.history ?? []);
  const payload: PersistedLessonHistory = {
    requestKey: getLessonRequestKey(request),
    subject: request.subject,
    focus: request.focus,
    dayNumber: request.dayNumber,
    history: nextHistory,
  };

  await writeFile(getLessonFilePath(request), JSON.stringify(payload, null, 2), "utf8");
  return payload;
}
