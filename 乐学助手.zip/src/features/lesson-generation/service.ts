import {
  APICallError,
  JSONParseError,
  NoObjectGeneratedError,
  RetryError,
  TypeValidationError,
} from "ai";
import {
  StructuredGenerationError,
  generateStructuredOutput,
} from "@/lib/ai/structured-output";
import {
  type LessonDeckGeneration,
  type LessonRequestInput,
  lessonDeckGenerationSchema,
} from "@/lib/validations/lesson";
import { SearchServiceError, searchLessonSources } from "@/lib/search/tavily";
import type { LessonDeck, LessonSlide } from "@/types/slide";

export class LessonGenerationError extends Error {
  constructor(
    message: string,
    public readonly statusCode = 500,
    public readonly code = "LESSON_GENERATION_FAILED",
  ) {
    super(message);
    this.name = "LessonGenerationError";
  }
}

function buildLessonPrompt(
  input: LessonRequestInput,
  searchSummary: string | null,
  sources: Awaited<ReturnType<typeof searchLessonSources>>["sources"],
) {
  const sourceLines = sources
    .map(
      (source, index) =>
        `来源 ${index + 1}：${source.title}\n链接：${source.url}\n摘要：${source.snippet}`,
    )
    .join("\n\n");

  return `
你是一名面向中小学生的课程设计老师。请根据当天学习主题，输出一个适合网页幻灯片展示的课程结构。

学生背景：
- 学科与年级：${input.subject}
- 当天主题：${input.focus}
- 学习日：第 ${input.dayNumber} 天

搜索摘要：
${searchSummary ?? "暂无单独摘要，请以下方来源内容为准。"}

参考资料：
${sourceLines}

输出要求：
- 必须输出中文
- title 要像当天课程标题
- description 要概括本节课的学习逻辑和收获
- slides 需要 5 到 8 页
- slides 中每一页都必须包含以下字段：kind、title、summary、bullets、example
- kind 只能是 content 或 quiz
- 除最后一页外，其他页的 kind 必须为 content
- 最后一页的 kind 必须为 quiz
- 每一页都必须提供 summary，不能缺省、不能留空
- 前 4 页优先讲清概念、规律、易错点和例题
- 最后一页必须是 quiz
- quiz 页必须额外提供 questions 字段，包含 2 到 3 道选择题
- 每道 questions 需要 stem、options(2-4个)、correctOptionId、explanation
- bullets 要让中小学生看得懂，句子短、重点明确
- example 需要给出贴近教学的例子、提问或练习引导
- 内容必须贴合搜索资料，不要脱离主题随意扩写
- 只输出符合要求的 JSON，不要输出 markdown

字段格式示例：
{
  "title": "课程标题",
  "description": "课程概述",
  "slides": [
    {
      "kind": "content",
      "title": "知识点标题",
      "summary": "本页讲解摘要",
      "bullets": ["要点1", "要点2", "要点3"],
      "example": "例题或提问"
    },
    {
      "kind": "quiz",
      "title": "随堂练习",
      "summary": "本页用于检查掌握情况",
      "bullets": ["题目1", "题目2", "题目3"],
      "example": "提示学生先独立作答，再对照讲解",
      "questions": [
        {
          "id": "q1",
          "stem": "下列哪项是本节核心概念？",
          "options": [
            { "id": "a", "text": "选项A" },
            { "id": "b", "text": "选项B" }
          ],
          "correctOptionId": "a",
          "explanation": "解释为什么选A"
        }
      ]
    }
  ]
}
  `.trim();
}

function normalizeSlides(slides: LessonDeckGeneration["slides"]): LessonSlide[] {
  return slides.map((slide, index) => ({
    id: `slide-${index + 1}`,
    kind: slide.kind,
    title: slide.title,
    summary: slide.summary,
    bullets: slide.bullets,
    example: slide.example,
    questions: slide.kind === "quiz" ? slide.questions : undefined,
  }));
}

function mapLessonGenerationError(error: unknown): LessonGenerationError {
  if (error instanceof StructuredGenerationError) {
    return new LessonGenerationError(error.message, error.statusCode, error.code);
  }

  if (error instanceof SearchServiceError) {
    return new LessonGenerationError(error.message, error.statusCode, error.code);
  }

  if (error instanceof Error && error.message === "MISSING_DEEPSEEK_API_KEY") {
    return new LessonGenerationError(
      "当前已强制使用 DeepSeek，但未检测到 DEEPSEEK_API_KEY，请先完成环境变量配置。",
      503,
      "MISSING_DEEPSEEK_API_KEY",
    );
  }

  if (error instanceof Error && error.message === "MISSING_OPENAI_API_KEY") {
    return new LessonGenerationError(
      "当前已强制使用 OpenAI，但未检测到 OPENAI_API_KEY，请先完成环境变量配置。",
      503,
      "MISSING_OPENAI_API_KEY",
    );
  }

  if (error instanceof Error && error.message === "MISSING_MODEL_API_KEY") {
    return new LessonGenerationError(
      "未检测到模型 API Key，请先配置 DEEPSEEK_API_KEY；如需回退，也可配置 OPENAI_API_KEY。",
      503,
      "MISSING_MODEL_API_KEY",
    );
  }

  if (APICallError.isInstance(error)) {
    if (error.statusCode === 401 || error.statusCode === 403) {
      return new LessonGenerationError(
        "模型鉴权失败，请检查 DeepSeek/OpenAI 的 API Key 是否正确、是否仍然有效。",
        401,
        "MODEL_AUTH_FAILED",
      );
    }

    if (error.statusCode === 429) {
      return new LessonGenerationError(
        "模型调用频率受限或账户余额不足，请稍后重试。",
        429,
        "MODEL_RATE_LIMITED",
      );
    }

    if (error.statusCode && error.statusCode >= 500) {
      return new LessonGenerationError(
        "模型服务暂时不可用，请稍后重试。",
        503,
        "MODEL_PROVIDER_UNAVAILABLE",
      );
    }
  }

  if (
    NoObjectGeneratedError.isInstance(error) ||
    TypeValidationError.isInstance(error) ||
    JSONParseError.isInstance(error)
  ) {
    return new LessonGenerationError(
      "模型返回的课程结构不符合 slide schema，请重试或调整模型配置。",
      502,
      "INVALID_MODEL_OUTPUT",
    );
  }

  if (RetryError.isInstance(error)) {
    return new LessonGenerationError(
      "模型多次重试后仍未成功返回课程结果，请稍后再试。",
      504,
      "MODEL_RETRY_EXHAUSTED",
    );
  }

  return new LessonGenerationError(
    "课程生成失败，请稍后重试或检查搜索/模型配置是否可用。",
    500,
    "LESSON_GENERATION_FAILED",
  );
}

export async function generateLessonDeck(input: LessonRequestInput): Promise<LessonDeck> {
  try {
    const searchResult = await searchLessonSources({
      subject: input.subject,
      focus: input.focus,
    });

    const finalResult = await generateStructuredOutput({
      schema: lessonDeckGenerationSchema,
      system:
        "你是一个认真、耐心、擅长把知识点讲给中小学生听懂的中文课程助手。输出必须结构化、具体、适合网页课件展示。",
      prompt: buildLessonPrompt(input, searchResult.answer, searchResult.sources),
      temperature: 0.4,
      maxRetries: 1,
      maxTokens: 5000,
    });

    return {
      id: input.lessonId ?? crypto.randomUUID(),
      title: finalResult.object.title,
      description: `${finalResult.object.description} 本次课程由 ${finalResult.providerName} 的 ${finalResult.modelName} 结合搜索资料自动生成。`,
      generatedAt: new Date().toISOString(),
      searchSummary: searchResult.answer,
      sources: searchResult.sources,
      source: "llm",
      slides: normalizeSlides(finalResult.object.slides),
    };
  } catch (error) {
    console.error('[API] 生成课程出错:', error);
    throw mapLessonGenerationError(error);
  }
}
