import type { LessonDeck, LessonSlide, QuizQuestion } from "@/types/slide";

function buildMockQuizQuestions(focus: string): QuizQuestion[] {
  return [
    {
      id: "q1",
      stem: `关于「${focus}」，下列哪项最适合作为第一步？`,
      options: [
        { id: "q1-a", text: "先圈已知条件，再判断适用方法" },
        { id: "q1-b", text: "直接套公式，不用读题" },
        { id: "q1-c", text: "先写最终答案，再补过程" },
      ],
      correctOptionId: "q1-a",
      explanation: "做题第一步永远是读题和整理已知条件，再选择方法。",
    },
    {
      id: "q2",
      stem: "遇到不确定的步骤时，更合理的做法是？",
      options: [
        { id: "q2-a", text: "跳过不管，直接写结果" },
        { id: "q2-b", text: "把步骤拆开，逐步验证每一步" },
        { id: "q2-c", text: "只背答案，不理解过程" },
      ],
      correctOptionId: "q2-b",
      explanation: "复杂题拆步骤验证，更容易发现错误，也更容易记住方法。",
    },
  ];
}

function buildSlides(subject: string, focus: string, dayNumber: number): LessonSlide[] {
  return [
    {
      id: `intro-${dayNumber}`,
      kind: "content",
      title: `${focus}：先搭框架`,
      summary: `用学生能听懂的话把 ${subject} 中的“${focus}”先讲清楚，确保知道这节课要学什么。`,
      bullets: [
        `先说清“${focus}”对应的核心概念和出现条件。`,
        "把容易混淆的旧知识点拿出来做对比。",
        "用一句话总结今天必须记住的结论。",
      ],
      example: "示例：先看一张生活场景图，判断这里涉及哪些已知条件和关键概念。",
    },
    {
      id: `explain-${dayNumber}`,
      kind: "content",
      title: `知识点拆解：${focus}`,
      summary: "第二页聚焦规则、公式或判断步骤，让学生知道做题时应该按什么顺序思考。",
      bullets: [
        "先看题目问什么，再圈出已知量。",
        "如果需要列公式，先判断使用前提是否满足。",
        "复杂问题拆成 2 到 3 个小步骤完成。",
      ],
      example: "示例：把一道题拆成“读题 -> 判断 -> 计算 -> 检查”四步。",
    },
    {
      id: `practice-${dayNumber}`,
      kind: "content",
      title: "典型例题跟练",
      summary: "通过一题一讲的方式示范思路，训练学生把课堂方法迁移到题目里。",
      bullets: [
        "先独立判断已知与未知。",
        "再写出解题的第一步，而不是直接求答案。",
        "做完后回头看有没有更简洁的表达方式。",
      ],
      example: "示例：展示一题标准解法，同时标出学生最容易出错的一步。",
    },
    {
      id: `quiz-${dayNumber}`,
      kind: "quiz",
      title: "课后小测",
      summary: "最后用选择题检查理解程度，完成后可打卡今日学习。",
      bullets: [
        "问题 1：今天的核心概念是什么？",
        "问题 2：遇到类似题目时第一步应该做什么？",
        "问题 3：哪一步最容易出错，为什么？",
      ],
      example: "提交答案后可查看解析；若不确定，可在右侧答疑区继续提问。",
      questions: buildMockQuizQuestions(focus),
    },
  ];
}

export function buildMockLessonDeck({
  lessonId,
  subject,
  focus,
  dayNumber,
}: {
  lessonId: string;
  subject: string;
  focus: string;
  dayNumber: number;
}): LessonDeck {
  return {
    id: lessonId,
    title: `第 ${dayNumber} 天课程：${focus}`,
    description: "当前课件由 mock 数据生成，后续会通过“搜索资料 -> LLM 提炼 -> slide JSON 输出”的流程替换。",
    generatedAt: new Date().toISOString(),
    searchSummary: null,
    sources: [],
    source: "mock",
    slides: buildSlides(subject, focus, dayNumber),
  };
}
