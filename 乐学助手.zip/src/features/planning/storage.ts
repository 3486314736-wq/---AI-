export function getPlanStorageKey(planId: string) {
  return `weekly-plan:${planId}`;
}
