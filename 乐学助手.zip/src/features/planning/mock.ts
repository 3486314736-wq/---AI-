import type { PlannerInput } from "@/lib/validations/planner";
import type { DailyPlan, LearnerProfile, WeeklyPlan } from "@/types/plan";

const topicPresets: Array<{ keywords: string[]; topics: string[] }> = [
  {
    keywords: ["物理", "力学"],
    topics: [
      "力和运动的关系",
      "受力分析入门",
      "牛顿第一定律",
      "牛顿第二定律",
      "摩擦力与支持力",
      "典型题拆解训练",
      "综合回顾与小测",
    ],
  },
  {
    keywords: ["数学", "分数"],
    topics: [
      "分数意义回顾",
      "同分母分数计算",
      "异分母分数通分",
      "分数应用题读题",
      "单位 1 与对应量",
      "典型应用题训练",
      "复盘与错题整理",
    ],
  },
  {
    keywords: ["英语"],
    topics: [
      "核心词汇热身",
      "一般现在时",
      "一般过去时",
      "进行时辨析",
      "句型替换训练",
      "阅读与语法结合",
      "本周复盘与输出",
    ],
  },
];

const fallbackTopics = [
  "基础知识梳理",
  "关键概念理解",
  "典型例题拆解",
  "易错点纠偏",
  "巩固练习",
  "综合运用",
  "回顾与小测",
];

function normalizeValue(value: string | string[] | undefined, fallback: string) {
  if (Array.isArray(value)) {
    return value[0] ?? fallback;
  }

  return value ?? fallback;
}

function pickTopics(subject: string) {
  const match = topicPresets.find((preset) =>
    preset.keywords.some((keyword) => subject.includes(keyword)),
  );

  return match?.topics ?? fallbackTopics;
}

function buildCoachTip(dayNumber: number, challenge: string) {
  if (dayNumber === 4) {
    return "今天安排回顾日，先口头复述知识点，再做 1 道小题检测记忆效果。";
  }

  if (dayNumber === 7) {
    return "最后一天重点做查漏补缺，把一周最容易错的内容再看一遍。";
  }

  return `遇到“${challenge}”相关题目时，先写出已知条件，再判断用哪条规则。`;
}

function buildGoal(topic: string, goal: string) {
  return `围绕“${topic}”完成知识理解、例题跟练和 1 次简短复盘，服务于本周目标：${goal}`;
}

export function coerceLearnerProfile(query: Record<string, string | string[] | undefined>): LearnerProfile {
  return {
    subject: normalizeValue(query.subject, "初二物理"),
    stage: normalizeValue(query.stage, "力学基础薄弱，容易混淆概念"),
    challenge: normalizeValue(query.challenge, "题目综合时不知道如何下手"),
    dailyMinutes: Number(normalizeValue(query.dailyMinutes, "60")) || 60,
    goal: normalizeValue(query.goal, "一周内补基础并完成典型题训练"),
  };
}

export function buildMockWeeklyPlan(input: PlannerInput): WeeklyPlan {
  const days: DailyPlan[] = pickTopics(input.subject).map((topic, index) => ({
    day: index + 1,
    topic,
    durationMinutes: input.dailyMinutes,
    goal: buildGoal(topic, input.goal),
    coachTip: buildCoachTip(index + 1, input.challenge),
  }));

  return {
    id: "mock-plan",
    title: `${input.subject} 7 天个性化学习计划`,
    summary: `系统根据“${input.stage}”和“${input.challenge}”生成了一份一周学习安排。当前版本由规则驱动，后续会替换为 LLM 输出的结构化计划。`,
    totalMinutes: days.reduce((sum, day) => sum + day.durationMinutes, 0),
    source: "mock",
    days,
  };
}
