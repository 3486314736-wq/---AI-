import {
  APICallError,
  JSONParseError,
  NoObjectGeneratedError,
  RetryError,
  TypeValidationError,
} from "ai";
import {
  StructuredGenerationError,
  generateStructuredOutput,
} from "@/lib/ai/structured-output";
import {
  type PlanRequestInput,
  type WeeklyPlanGeneration,
  weeklyPlanGenerationSchema,
} from "@/lib/validations/planner";
import type { DailyPlan, WeeklyPlan } from "@/types/plan";

export class PlanGenerationError extends Error {
  constructor(
    message: string,
    public readonly statusCode = 500,
    public readonly code = "PLAN_GENERATION_FAILED",
  ) {
    super(message);
    this.name = "PlanGenerationError";
  }
}

function getProviderDisplayName(providerName: string, modelName: string) {
  return `本次由 ${providerName} 的 ${modelName} 自动生成。`;
}

function mapPlanGenerationError(error: unknown): PlanGenerationError {
  if (error instanceof StructuredGenerationError) {
    return new PlanGenerationError(error.message, error.statusCode, error.code);
  }

  if (error instanceof Error && error.message === "MISSING_DEEPSEEK_API_KEY") {
    return new PlanGenerationError(
      "当前已强制使用 DeepSeek，但未检测到 DEEPSEEK_API_KEY，请先完成环境变量配置。",
      503,
      "MISSING_DEEPSEEK_API_KEY",
    );
  }

  if (error instanceof Error && error.message === "MISSING_OPENAI_API_KEY") {
    return new PlanGenerationError(
      "当前已强制使用 OpenAI，但未检测到 OPENAI_API_KEY，请先完成环境变量配置。",
      503,
      "MISSING_OPENAI_API_KEY",
    );
  }

  if (error instanceof Error && error.message === "MISSING_MODEL_API_KEY") {
    return new PlanGenerationError(
      "未检测到模型 API Key，请先配置 DEEPSEEK_API_KEY；如需回退，也可配置 OPENAI_API_KEY。",
      503,
      "MISSING_MODEL_API_KEY",
    );
  }

  if (APICallError.isInstance(error)) {
    if (error.statusCode === 401 || error.statusCode === 403) {
      return new PlanGenerationError(
        "模型鉴权失败，请检查 DeepSeek/OpenAI 的 API Key 是否正确、是否仍然有效。",
        401,
        "MODEL_AUTH_FAILED",
      );
    }

    if (error.statusCode === 429) {
      return new PlanGenerationError(
        "模型调用频率受限或账户余额不足，请稍后重试并检查 DeepSeek 账户额度。",
        429,
        "MODEL_RATE_LIMITED",
      );
    }

    if (error.statusCode && error.statusCode >= 500) {
      return new PlanGenerationError(
        "模型服务暂时不可用，请稍后重试。",
        503,
        "MODEL_PROVIDER_UNAVAILABLE",
      );
    }
  }

  if (
    NoObjectGeneratedError.isInstance(error) ||
    TypeValidationError.isInstance(error) ||
    JSONParseError.isInstance(error)
  ) {
    return new PlanGenerationError(
      "模型返回的结构化结果不符合计划 schema，请重试或调整模型配置。",
      502,
      "INVALID_MODEL_OUTPUT",
    );
  }

  if (RetryError.isInstance(error)) {
    return new PlanGenerationError(
      "模型多次重试后仍未成功返回结果，请稍后再试。",
      504,
      "MODEL_RETRY_EXHAUSTED",
    );
  }

  return new PlanGenerationError(
    "AI 学习计划生成失败，请稍后重试或检查模型配置是否可用。",
    500,
    "PLAN_GENERATION_FAILED",
  );
}

function buildPlannerPrompt(input: PlanRequestInput) {
  return `
你是一名面向中小学生的资深学习规划老师。请根据学生信息，生成一份严格为 7 天的一周学习计划。

学生信息：
- 学科与年级：${input.subject}
- 当前学习阶段：${input.stage}
- 主要困难：${input.challenge}
- 每日可学习时长：${input.dailyMinutes} 分钟
- 一周目标：${input.goal}

输出要求：
- 必须输出中文
- 必须严格生成 7 天计划，day 从 1 到 7，不能重复、不能缺失
- 每天的 topic 要具体，不要泛泛而谈
- 每天的 goal 要明确到“学什么、练什么、达到什么程度”
- 每天的 coachTip 要像老师给孩子和家长的提醒，语气耐心、具体、可执行
- 计划难度要符合中小学生认知水平
- 第 4 天优先安排回顾或巩固
- 第 7 天优先安排总结、小测或查漏补缺
- title 要像产品页面标题
- summary 要概括这周安排逻辑，突出个性化依据
  `.trim();
}

function normalizeGeneratedDays(days: WeeklyPlanGeneration["days"], dailyMinutes: number): DailyPlan[] {
  return [...days]
    .sort((left, right) => left.day - right.day)
    .map((day, index) => ({
      day: index + 1,
      topic: day.topic,
      durationMinutes: dailyMinutes,
      goal: day.goal,
      coachTip: day.coachTip,
    }));
}

export async function generateWeeklyPlan(input: PlanRequestInput): Promise<WeeklyPlan> {
  let modelName = "unknown";
  let providerName = "AI";

  try {
    const result = await generateStructuredOutput({
      schema: weeklyPlanGenerationSchema,
      system:
        "你是一个认真、耐心、擅长为中小学生制定学习计划的中文教学助手。输出必须结构化、具体、可执行。",
      prompt: buildPlannerPrompt(input),
      temperature: 0.5,
      maxRetries: 1,
    });
    modelName = result.modelName;
    providerName = result.providerName;

    const days = normalizeGeneratedDays(result.object.days, input.dailyMinutes);

    return {
      id: input.planId ?? crypto.randomUUID(),
      title: result.object.title,
      summary: `${result.object.summary} ${getProviderDisplayName(providerName, modelName)}`,
      totalMinutes: days.reduce((sum, day) => sum + day.durationMinutes, 0),
      source: "llm",
      days,
    };
  } catch (error) {
    throw mapPlanGenerationError(error);
  }
}
