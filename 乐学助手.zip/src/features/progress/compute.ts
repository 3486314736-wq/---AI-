import { scoreQuizAnswers, deriveQuizQuestions } from "@/lib/quiz";
import type { CheckInLevel, LessonProgress } from "@/types/progress";
import type { LessonDeck } from "@/types/slide";

export function getRecommendedDayNumber(planStartedAt: string) {
  const started = new Date(planStartedAt);
  const now = new Date();
  const diffMs = now.getTime() - started.getTime();
  const dayIndex = Math.floor(diffMs / (24 * 60 * 60 * 1000)) + 1;
  return Math.min(7, Math.max(1, dayIndex));
}

export function computeViewedRatio(deck: LessonDeck, viewedSlideIds: string[]) {
  if (deck.slides.length === 0) {
    return 0;
  }

  const viewedCount = deck.slides.filter((slide) => viewedSlideIds.includes(slide.id)).length;
  return viewedCount / deck.slides.length;
}

export function computeCheckInLevel(
  deck: LessonDeck,
  progress: Pick<LessonProgress, "viewedSlideIds" | "quizAnswers" | "tutorQuestionCount" | "sessionStartedAt">,
): CheckInLevel | null {
  const viewedRatio = computeViewedRatio(deck, progress.viewedSlideIds);
  const quizSlide = deck.slides.find((slide) => slide.kind === "quiz");
  const quizQuestions = quizSlide ? deriveQuizQuestions(quizSlide) : [];
  const quizScore = scoreQuizAnswers(
    quizQuestions,
    progress.quizAnswers.map((answer) => ({
      questionId: answer.questionId,
      selectedOptionId: answer.selectedOptionId,
    })),
  );
  const sessionMinutes =
    (Date.now() - new Date(progress.sessionStartedAt).getTime()) / (60 * 1000);

  const hasLight =
    sessionMinutes >= 1 || progress.viewedSlideIds.length >= 1 || progress.tutorQuestionCount >= 1;

  const contentSlides = deck.slides.filter((slide) => slide.kind === "content");
  const viewedContentSlides = contentSlides.filter((slide) => progress.viewedSlideIds.includes(slide.id));
  const hasStandard =
    (viewedContentSlides.length >= contentSlides.length || viewedRatio >= 0.85) &&
    (quizScore.allAttempted || progress.tutorQuestionCount >= 1);

  const hasFull =
    viewedRatio >= 0.99 &&
    quizScore.allCorrect &&
    progress.tutorQuestionCount >= 1;

  if (hasFull) {
    return "full";
  }

  if (hasStandard) {
    return "standard";
  }

  if (hasLight) {
    return "light";
  }

  return null;
}

export function computeStreak(completedDays: Array<{ day: number; completedAt: string | null }>) {
  const completedDaySet = new Set(
    completedDays.filter((entry) => entry.completedAt).map((entry) => entry.day),
  );

  if (completedDaySet.size === 0) {
    return 0;
  }

  let streak = 0;

  for (let day = 7; day >= 1; day -= 1) {
    if (completedDaySet.has(day)) {
      streak += 1;
    } else if (streak > 0) {
      break;
    }
  }

  return streak;
}

export function getCheckInRequirements(deck: LessonDeck) {
  const quizSlide = deck.slides.find((slide) => slide.kind === "quiz");
  const quizCount = quizSlide ? deriveQuizQuestions(quizSlide).length : 0;

  return {
    light: "进入课程并学习至少 1 页，或停留 1 分钟以上",
    standard: "看完讲解页并完成小测作答，或至少提问 1 次",
    full: "看完所有页面、小测全对且至少提问 1 次",
    quizCount,
    totalSlides: deck.slides.length,
  };
}
