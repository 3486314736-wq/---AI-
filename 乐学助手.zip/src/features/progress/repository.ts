import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { computeCheckInLevel, computeStreak } from "@/features/progress/compute";
import { getLessonRequestKey } from "@/features/lesson-generation/storage";
import type {
  CheckInLevel,
  DayCheckInStatus,
  LessonProgress,
  PlanDayProgress,
  PlanProgress,
} from "@/types/progress";
import type { LessonDeck } from "@/types/slide";

const PROGRESS_ROOT = path.join(process.cwd(), ".data", "progress");
const LESSON_PROGRESS_DIR = path.join(PROGRESS_ROOT, "lessons");
const PLAN_PROGRESS_DIR = path.join(PROGRESS_ROOT, "plans");

function getLessonProgressPath(requestKey: string) {
  return path.join(LESSON_PROGRESS_DIR, `${encodeURIComponent(requestKey)}.json`);
}

function getPlanProgressPath(planId: string) {
  return path.join(PLAN_PROGRESS_DIR, `${planId}.json`);
}

async function ensureProgressDirectories() {
  await mkdir(LESSON_PROGRESS_DIR, { recursive: true });
  await mkdir(PLAN_PROGRESS_DIR, { recursive: true });
}

async function readJsonFile<T>(filePath: string): Promise<T | null> {
  try {
    const raw = await readFile(filePath, "utf8");
    return JSON.parse(raw) as T;
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "ENOENT") {
      return null;
    }

    throw error;
  }
}

async function writeJsonFile<T>(filePath: string, payload: T) {
  await ensureProgressDirectories();
  await writeFile(filePath, JSON.stringify(payload, null, 2), "utf8");
}

function createEmptyLessonProgress(input: {
  requestKey: string;
  planId?: string | null;
  subject: string;
  focus: string;
  dayNumber: number;
}): LessonProgress {
  const now = new Date().toISOString();

  return {
    requestKey: input.requestKey,
    planId: input.planId ?? null,
    subject: input.subject,
    focus: input.focus,
    dayNumber: input.dayNumber,
    viewedSlideIds: [],
    quizAnswers: [],
    tutorQuestionCount: 0,
    sessionStartedAt: now,
    lastVisitedAt: now,
    checkInStatus: "not_started",
    checkInLevel: null,
    completedAt: null,
  };
}

function createEmptyPlanProgress(planId: string, subject: string, days: PlanDayProgress[]): PlanProgress {
  const now = new Date().toISOString();

  return {
    planId,
    subject,
    startedAt: now,
    updatedAt: now,
    days,
    completedDayCount: 0,
    streak: 0,
  };
}

export async function readLessonProgress(requestKey: string): Promise<LessonProgress | null> {
  return readJsonFile<LessonProgress>(getLessonProgressPath(requestKey));
}

export async function upsertLessonProgress(
  input: {
    requestKey: string;
    planId?: string | null;
    subject: string;
    focus: string;
    dayNumber: number;
    viewedSlideIds?: string[];
    quizAnswers?: LessonProgress["quizAnswers"];
    tutorQuestionCount?: number;
  },
  deck?: LessonDeck | null,
): Promise<LessonProgress> {
  const existing =
    (await readLessonProgress(input.requestKey)) ??
    createEmptyLessonProgress(input);
  const now = new Date().toISOString();

  const merged: LessonProgress = {
    ...existing,
    planId: input.planId ?? existing.planId,
    subject: input.subject,
    focus: input.focus,
    dayNumber: input.dayNumber,
    viewedSlideIds: input.viewedSlideIds
      ? [...new Set([...existing.viewedSlideIds, ...input.viewedSlideIds])]
      : existing.viewedSlideIds,
    quizAnswers: input.quizAnswers ?? existing.quizAnswers,
    tutorQuestionCount:
      typeof input.tutorQuestionCount === "number"
        ? Math.max(existing.tutorQuestionCount, input.tutorQuestionCount)
        : existing.tutorQuestionCount,
    lastVisitedAt: now,
    checkInStatus:
      existing.checkInStatus === "completed"
        ? "completed"
        : input.viewedSlideIds?.length || input.quizAnswers?.length || input.tutorQuestionCount
          ? "in_progress"
          : existing.checkInStatus === "not_started"
            ? "in_progress"
            : existing.checkInStatus,
  };

  if (deck && merged.checkInStatus !== "completed") {
    const level = computeCheckInLevel(deck, merged);

    if (level === "standard" || level === "full") {
      merged.checkInStatus = "in_progress";
    }
  }

  await writeJsonFile(getLessonProgressPath(input.requestKey), merged);

  if (merged.planId && merged.checkInStatus !== "completed") {
    await syncPlanDayFromLesson(merged.planId, {
      ...merged,
      checkInStatus: merged.checkInStatus === "not_started" ? "in_progress" : merged.checkInStatus,
    });
  }

  return merged;
}

async function syncPlanDayFromLesson(planId: string, lesson: LessonProgress) {
  const plan = await readPlanProgress(planId);

  if (!plan) {
    return;
  }

  const nextDays = plan.days.map((day) => {
    if (day.day !== lesson.dayNumber) {
      return day;
    }

    return {
      ...day,
      topic: day.topic || lesson.focus,
      status: lesson.checkInStatus,
      checkInLevel: lesson.checkInLevel,
      completedAt: lesson.completedAt,
      requestKey: lesson.requestKey,
    } satisfies PlanDayProgress;
  });

  await writePlanProgress({
    ...plan,
    days: nextDays,
  });
}

export async function completeLessonCheckIn(
  input: {
    requestKey: string;
    planId?: string | null;
    subject: string;
    focus: string;
    dayNumber: number;
    level?: CheckInLevel;
  },
  deck: LessonDeck,
): Promise<LessonProgress> {
  const existing = await upsertLessonProgress(input, deck);
  const level = input.level ?? computeCheckInLevel(deck, existing);

  if (!level) {
    throw new Error("CHECK_IN_NOT_READY");
  }

  const now = new Date().toISOString();
  const completed: LessonProgress = {
    ...existing,
    checkInStatus: "completed",
    checkInLevel: level,
    completedAt: now,
    lastVisitedAt: now,
  };

  await writeJsonFile(getLessonProgressPath(input.requestKey), completed);

  if (completed.planId) {
    await syncPlanDayFromLesson(completed.planId, completed);
  }

  return completed;
}

export async function initializePlanProgress(
  planId: string,
  subject: string,
  dayTopics: Array<{ day: number; topic: string }>,
): Promise<PlanProgress> {
  const existing = await readPlanProgress(planId);

  if (existing) {
    return existing;
  }

  const days: PlanDayProgress[] = dayTopics.map(({ day, topic }) => ({
    day,
    topic,
    status: "not_started",
    checkInLevel: null,
    completedAt: null,
    requestKey: getLessonRequestKey({ subject, focus: topic, dayNumber: day }),
  }));

  const plan = createEmptyPlanProgress(planId, subject, days);
  await writeJsonFile(getPlanProgressPath(planId), plan);
  return plan;
}

export async function readPlanProgress(planId: string): Promise<PlanProgress | null> {
  return readJsonFile<PlanProgress>(getPlanProgressPath(planId));
}

export async function writePlanProgress(plan: PlanProgress) {
  const completedDayCount = plan.days.filter((day) => day.status === "completed").length;
  const streak = computeStreak(plan.days);

  const payload: PlanProgress = {
    ...plan,
    completedDayCount,
    streak,
    updatedAt: new Date().toISOString(),
  };

  await writeJsonFile(getPlanProgressPath(plan.planId), payload);
  return payload;
}

export function getDayStatusLabel(status: DayCheckInStatus) {
  switch (status) {
    case "completed":
      return "已打卡";
    case "in_progress":
      return "进行中";
    default:
      return "未开始";
  }
}
