import { mkdir, readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import type { TutorMessage } from "@/types/chat";

const DATA_DIRECTORY = path.join(process.cwd(), ".data", "chats");
const TUTOR_HISTORY_LIMIT = 30;

export interface PersistedTutorConversation {
  lessonId: string;
  subject: string;
  focus: string;
  lessonTitle: string;
  updatedAt: string;
  messages: TutorMessage[];
}

interface SaveTutorConversationInput {
  lessonId: string;
  subject: string;
  focus: string;
  lessonTitle: string;
  messages: TutorMessage[];
}

function toFileName(lessonId: string) {
  return `${Buffer.from(lessonId).toString("base64url")}.json`;
}

function getConversationFilePath(lessonId: string) {
  return path.join(DATA_DIRECTORY, toFileName(lessonId));
}

async function ensureDataDirectory() {
  await mkdir(DATA_DIRECTORY, { recursive: true });
}

function normalizeMessages(messages: TutorMessage[]) {
  return messages
    .filter((message) => Boolean(message.id))
    .slice(-TUTOR_HISTORY_LIMIT)
    .map((message) => ({
      ...message,
      attachmentName: message.attachmentName ?? null,
    }));
}

export async function readPersistedTutorConversation(
  lessonId: string,
): Promise<PersistedTutorConversation | null> {
  try {
    const raw = await readFile(getConversationFilePath(lessonId), "utf8");
    return JSON.parse(raw) as PersistedTutorConversation;
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "ENOENT") {
      return null;
    }

    throw error;
  }
}

export async function saveTutorConversation(
  input: SaveTutorConversationInput,
): Promise<PersistedTutorConversation> {
  await ensureDataDirectory();

  const payload: PersistedTutorConversation = {
    lessonId: input.lessonId,
    subject: input.subject,
    focus: input.focus,
    lessonTitle: input.lessonTitle,
    updatedAt: new Date().toISOString(),
    messages: normalizeMessages(input.messages),
  };

  await writeFile(getConversationFilePath(input.lessonId), JSON.stringify(payload, null, 2), "utf8");
  return payload;
}

export async function appendTutorConversationMessages(
  input: SaveTutorConversationInput,
): Promise<PersistedTutorConversation> {
  const current = await readPersistedTutorConversation(input.lessonId);

  return saveTutorConversation({
    lessonId: input.lessonId,
    subject: input.subject,
    focus: input.focus,
    lessonTitle: input.lessonTitle,
    messages: [...(current?.messages ?? []), ...input.messages],
  });
}

export async function clearPersistedTutorConversation(lessonId: string) {
  try {
    await rm(getConversationFilePath(lessonId), { force: true });
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "ENOENT") {
      return;
    }

    throw error;
  }
}
