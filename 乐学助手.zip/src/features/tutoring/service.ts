import { getModelProviderStatus } from "@/lib/ai/provider";
import type { TutoringRequestInput } from "@/lib/validations/chat";

const MAX_IMAGE_BYTES = 3 * 1024 * 1024;

interface ChatCompletionResponse {
  choices?: Array<{
    message?: {
      content?: string | Array<{ type?: string; text?: string }>;
    };
  }>;
  error?: {
    message?: string;
  };
}

export class TutoringError extends Error {
  constructor(
    message: string,
    public readonly statusCode = 500,
    public readonly code = "TUTORING_FAILED",
  ) {
    super(message);
    this.name = "TutoringError";
  }
}

function getDataUrlBytes(dataUrl: string) {
  const [, payload = ""] = dataUrl.split(",", 2);
  return Math.floor((payload.length * 3) / 4);
}

function buildTextPrompt(input: TutoringRequestInput) {
  const historyLines =
    input.recentMessages?.map((message) => `${message.role === "assistant" ? "老师" : "学生"}：${message.content}`).join("\n") ??
    "暂无历史消息";

  return `
你是一名面向中小学生的耐心老师，请结合当前课程页内容回答问题。

课程信息：
- 学科与年级：${input.subject}
- 当前主题：${input.focus}
- 课程标题：${input.lessonTitle}

当前幻灯片：
- 标题：${input.currentSlide.title}
- 类型：${input.currentSlide.kind === "quiz" ? "练习页" : "讲解页"}
- 摘要：${input.currentSlide.summary}
- 要点：${input.currentSlide.bullets.join("；")}
- 示例：${input.currentSlide.example}

最近对话：
${historyLines}

学生问题：
${input.question}

回答要求：
- 必须使用中文
- 先直接回答学生问题，再补充为什么
- 用词适合中小学生，不要过度学术化
- 如果学生截图和当前页内容有关，要明确指出你从截图或当前页看到了什么线索
- 如果问题对应的是练习题，优先给思路提示，再给关键步骤，不要一上来只报答案
- 回答控制在 4 到 7 句
  `.trim();
}

async function callOpenAICompatibleChat({
  apiKey,
  baseURL,
  model,
  input,
}: {
  apiKey: string;
  baseURL: string;
  model: string;
  input: TutoringRequestInput;
}) {
  const textContent = buildTextPrompt(input);
  
  const isDeepSeekModel = baseURL.includes("deepseek");
  
  const isVisionModel = isDeepSeekModel ||
                        model.toLowerCase().includes("vision") || 
                        model.toLowerCase().includes("gpt-4o") ||
                        model.toLowerCase().includes("gpt-4-turbo");
  
  const useMultimodal = input.imageDataUrl !== null && isVisionModel;

  const messages = useMultimodal
    ? [
        {
          role: "system",
          content: "你是一名适合中小学生的多模态答疑老师。请结合截图、当前课程页和问题，用耐心、具体、易懂的中文回答。",
        },
        {
          role: "user",
          content: [
            { type: "text", text: textContent },
            { type: "image_url", image_url: { url: input.imageDataUrl! } },
          ],
        },
      ]
    : [
        {
          role: "system",
          content: "你是一名适合中小学生的答疑老师。请结合当前课程页和问题，用耐心、具体、易懂的中文回答。",
        },
        {
          role: "user",
          content: textContent,
        },
      ];

  const response = await fetch(`${baseURL}/chat/completions`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.4,
      max_tokens: 900,
    }),
  });

  const payload = (await response.json()) as ChatCompletionResponse;

  if (!response.ok) {
    if (response.status === 401 || response.status === 403) {
      throw new TutoringError("多模态答疑模型鉴权失败，请检查对应 API Key 是否正确。", 401, "TUTORING_AUTH_FAILED");
    }

    if (response.status === 429) {
      throw new TutoringError("多模态答疑模型当前限流或额度不足，请稍后重试。", 429, "TUTORING_RATE_LIMITED");
    }

    throw new TutoringError(
      payload.error?.message ?? "多模态答疑模型暂时不可用，请稍后重试。",
      502,
      "TUTORING_PROVIDER_UNAVAILABLE",
    );
  }

  const content = payload.choices?.[0]?.message?.content;

  if (typeof content === "string" && content.trim()) {
    return content.trim();
  }

  if (Array.isArray(content)) {
    const text = content
      .filter((part) => part.type === "text" && typeof part.text === "string")
      .map((part) => part.text?.trim())
      .filter(Boolean)
      .join("\n");

    if (text) {
      return text;
    }
  }

  throw new TutoringError("多模态答疑模型未返回可解析内容。", 502, "INVALID_TUTORING_OUTPUT");
}

export async function answerTutorQuestion(input: TutoringRequestInput) {
  if (input.imageDataUrl && getDataUrlBytes(input.imageDataUrl) > MAX_IMAGE_BYTES) {
    throw new TutoringError("截图过大，请压缩到 3MB 以内后重试。", 413, "IMAGE_TOO_LARGE");
  }

  if (process.env.OPENAI_API_KEY) {
    const modelName = process.env.OPENAI_MULTIMODAL_MODEL ?? "gpt-4o-mini";
    return {
      answer: await callOpenAICompatibleChat({
        apiKey: process.env.OPENAI_API_KEY,
        baseURL: "https://api.openai.com/v1",
        model: modelName,
        input,
      }),
      providerName: "OpenAI",
      modelName,
    };
  }

  if (process.env.DEEPSEEK_API_KEY) {
    const providerStatus = getModelProviderStatus();
    const modelName = providerStatus.modelName ?? process.env.DEEPSEEK_MODEL ?? "deepseek-v4-flash";
    
    return {
      answer: await callOpenAICompatibleChat({
        apiKey: process.env.DEEPSEEK_API_KEY,
        baseURL: providerStatus.baseURL ?? "https://api.deepseek.com",
        model: modelName,
        input,
      }),
      providerName: "DeepSeek",
      modelName,
    };
  }

  throw new TutoringError(
    "请配置 OPENAI_API_KEY 或 DEEPSEEK_API_KEY 来使用答疑功能。",
    503,
    "MISSING_PROVIDER",
  );
}
