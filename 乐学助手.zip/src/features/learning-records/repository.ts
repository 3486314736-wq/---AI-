import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import { buildLessonHref, getLessonRequestKey } from "@/features/lesson-generation/storage";
import type { PersistedLessonHistory } from "@/features/lesson-generation/repository";
import type { PersistedTutorConversation } from "@/features/tutoring/repository";
import type { LessonProgress } from "@/types/progress";

const LESSONS_DIRECTORY = path.join(process.cwd(), ".data", "lessons");
const CHATS_DIRECTORY = path.join(process.cwd(), ".data", "chats");
const LESSON_PROGRESS_DIRECTORY = path.join(process.cwd(), ".data", "progress", "lessons");

export interface LearningRecordSummary {
  requestKey: string;
  lessonId: string;
  href: string;
  subject: string;
  focus: string;
  dayNumber: number;
  lessonTitle: string;
  lessonDescription: string;
  latestGeneratedAt: string;
  lessonVersionCount: number;
  slideCount: number;
  latestTutorUpdatedAt: string | null;
  tutorMessageCount: number;
  tutorQuestionCount: number;
  latestQuestion: string | null;
  checkInStatus: LessonProgress["checkInStatus"];
  checkInLevel: LessonProgress["checkInLevel"];
  viewedSlideCount: number;
  quizCorrectCount: number;
}

interface LearningRecordsOverview {
  records: LearningRecordSummary[];
  totalLessonCount: number;
  totalTutorQuestionCount: number;
  latestActivityAt: string | null;
}

async function readJsonFiles<T>(directoryPath: string): Promise<T[]> {
  try {
    const fileNames = await readdir(directoryPath);
    const payloads: Array<T | null> = await Promise.all(
      fileNames
        .filter((fileName) => fileName.endsWith(".json"))
        .map(async (fileName) => {
          try {
            const raw = await readFile(path.join(directoryPath, fileName), "utf8");
            return JSON.parse(raw) as T;
          } catch {
            return null;
          }
        }),
    );

    return payloads.filter((payload): payload is T => payload !== null);
  } catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "ENOENT") {
      return [];
    }

    throw error;
  }
}

function buildSubjectFocusKey(subject: string, focus: string) {
  return `${subject}__${focus}`;
}

function getLatestQuestion(conversation: PersistedTutorConversation | undefined) {
  if (!conversation) {
    return null;
  }

  const latestUserMessage = [...conversation.messages]
    .reverse()
    .find((message) => message.role === "user" && message.content.trim().length > 0);

  return latestUserMessage?.content ?? null;
}

export async function listLearningRecords(): Promise<LearningRecordsOverview> {
  const [lessons, conversations, lessonProgressList] = await Promise.all([
    readJsonFiles<PersistedLessonHistory>(LESSONS_DIRECTORY),
    readJsonFiles<PersistedTutorConversation>(CHATS_DIRECTORY),
    readJsonFiles<LessonProgress>(LESSON_PROGRESS_DIRECTORY),
  ]);

  const progressByRequestKey = new Map(
    lessonProgressList.map((progress) => [progress.requestKey, progress]),
  );

  const conversationByLessonId = new Map(conversations.map((conversation) => [conversation.lessonId, conversation]));
  const fallbackConversationBySubjectFocus = new Map(
    conversations.map((conversation) => [
      buildSubjectFocusKey(conversation.subject, conversation.focus),
      conversation,
    ]),
  );

  const records = lessons
    .map((lessonHistory) => {
      const latestHistory = lessonHistory.history[0];

      if (!latestHistory?.deck) {
        return null;
      }

      const requestKey = getLessonRequestKey({
        subject: lessonHistory.subject,
        focus: lessonHistory.focus,
        dayNumber: lessonHistory.dayNumber,
      });
      const matchedConversation =
        conversationByLessonId.get(requestKey) ??
        fallbackConversationBySubjectFocus.get(buildSubjectFocusKey(lessonHistory.subject, lessonHistory.focus));
      const tutorQuestionCount = matchedConversation?.messages.filter((message) => message.role === "user").length ?? 0;
      const lessonProgress = progressByRequestKey.get(requestKey);

      return {
        requestKey,
        lessonId: requestKey,
        href: buildLessonHref({
          subject: lessonHistory.subject,
          focus: lessonHistory.focus,
          dayNumber: lessonHistory.dayNumber,
        }),
        subject: lessonHistory.subject,
        focus: lessonHistory.focus,
        dayNumber: lessonHistory.dayNumber,
        lessonTitle: latestHistory.deck.title,
        lessonDescription: latestHistory.deck.description,
        latestGeneratedAt: latestHistory.generatedAt,
        lessonVersionCount: lessonHistory.history.length,
        slideCount: latestHistory.deck.slides.length,
        latestTutorUpdatedAt: matchedConversation?.updatedAt ?? null,
        tutorMessageCount: matchedConversation?.messages.length ?? 0,
        tutorQuestionCount,
        latestQuestion: getLatestQuestion(matchedConversation),
        checkInStatus: lessonProgress?.checkInStatus ?? "not_started",
        checkInLevel: lessonProgress?.checkInLevel ?? null,
        viewedSlideCount: lessonProgress?.viewedSlideIds.length ?? 0,
        quizCorrectCount: lessonProgress?.quizAnswers.filter((answer) => answer.correct).length ?? 0,
      } satisfies LearningRecordSummary;
    })
    .filter((record): record is LearningRecordSummary => record !== null)
    .sort((left, right) => {
      const rightTimestamp = new Date(right.latestTutorUpdatedAt ?? right.latestGeneratedAt).getTime();
      const leftTimestamp = new Date(left.latestTutorUpdatedAt ?? left.latestGeneratedAt).getTime();
      return rightTimestamp - leftTimestamp;
    });

  const latestActivityAt =
    records[0]?.latestTutorUpdatedAt ?? records[0]?.latestGeneratedAt ?? null;

  return {
    records,
    totalLessonCount: records.length,
    totalTutorQuestionCount: records.reduce((sum, record) => sum + record.tutorQuestionCount, 0),
    latestActivityAt,
  };
}
