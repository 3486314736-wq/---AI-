import { z } from "zod";

const dataUrlPattern = /^data:image\/(png|jpeg|jpg|webp);base64,[A-Za-z0-9+/=]+$/i;

export const tutorMessageSchema = z.object({
  id: z.string().min(1).optional(),
  role: z.enum(["user", "assistant"]),
  content: z.string().min(1).max(800),
  attachmentName: z.string().max(120).nullable().optional(),
  createdAt: z.string().datetime().optional(),
  slideId: z.string().min(1).max(120).optional(),
  slideTitle: z.string().min(1).max(120).optional(),
  providerName: z.string().max(40).optional(),
  modelName: z.string().max(80).optional(),
});

export const tutoringHistoryQuerySchema = z.object({
  lessonId: z.string().min(1).max(120),
});

export const tutoringRequestSchema = z.object({
  lessonId: z.string().min(1).max(120),
  subject: z.string().min(2).max(30),
  focus: z.string().min(2).max(40),
  lessonTitle: z.string().min(4).max(80),
  question: z.string().min(2).max(300),
  imageDataUrl: z.string().regex(dataUrlPattern, "截图格式不正确").optional(),
  imageMimeType: z.enum(["image/png", "image/jpeg", "image/jpg", "image/webp"]).optional(),
  imageName: z.string().max(120).optional(),
  currentSlide: z.object({
    id: z.string().min(1),
    kind: z.enum(["content", "quiz"]),
    title: z.string().min(2).max(60),
    summary: z.string().min(2).max(240),
    bullets: z.array(z.string().min(1).max(120)).min(1).max(6),
    example: z.string().min(1).max(180),
  }),
  recentMessages: z.array(tutorMessageSchema).max(6).optional(),
});

export type TutoringRequestInput = z.infer<typeof tutoringRequestSchema>;
export type TutoringHistoryQueryInput = z.infer<typeof tutoringHistoryQuerySchema>;
