import { z } from "zod";

const quizOptionSchema = z.object({
  id: z.string().min(1).max(20),
  text: z.string().min(1).max(80),
});

const quizQuestionSchema = z.object({
  id: z.string().min(1).max(20),
  stem: z.string().min(6).max(120),
  options: z.array(quizOptionSchema).min(2).max(4),
  correctOptionId: z.string().min(1).max(20),
  explanation: z.string().min(6).max(160),
});

export const lessonRequestSchema = z.object({
  lessonId: z.string().min(1).optional(),
  subject: z.string().min(2, "请填写学科与年级").max(30),
  focus: z.string().min(2, "请填写当天学习主题").max(40),
  dayNumber: z.coerce.number().int().min(1).max(7),
});

export const lessonDeckGenerationSchema = z.object({
  title: z.string().min(2).max(120),
  description: z.string().min(10).max(360),
  slides: z
    .array(
      z.object({
        kind: z.enum(["content", "quiz"]),
        title: z.string().min(2).max(80),
        summary: z.string().min(5).max(320),
        bullets: z.array(z.string().min(2).max(160)).min(1).max(8),
        example: z.string().min(2).max(240),
        questions: z.array(quizQuestionSchema).min(0).max(5).optional(),
      }),
    )
    .min(2)
    .max(15),
});

export type LessonRequestInput = z.infer<typeof lessonRequestSchema>;
export type LessonDeckGeneration = z.infer<typeof lessonDeckGenerationSchema>;
