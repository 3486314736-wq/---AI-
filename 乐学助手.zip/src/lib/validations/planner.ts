import { z } from "zod";

export const plannerSchema = z.object({
  subject: z.string().min(2, "请填写学科与年级").max(30, "内容请控制在 30 个字以内"),
  stage: z.string().min(6, "请描述当前学习阶段").max(120, "内容请控制在 120 个字以内"),
  challenge: z.string().min(6, "请描述主要困难").max(120, "内容请控制在 120 个字以内"),
  dailyMinutes: z.coerce.number().min(20, "建议至少安排 20 分钟").max(180, "建议不要超过 180 分钟"),
  goal: z.string().min(6, "请填写一周目标").max(120, "内容请控制在 120 个字以内"),
});

export const planRequestSchema = plannerSchema.extend({
  planId: z.string().min(1).optional(),
});

export const weeklyPlanGenerationSchema = z.object({
  title: z.string().min(6).max(60),
  summary: z.string().min(20).max(220),
  days: z
    .array(
      z.object({
        day: z.number().int().min(1).max(7),
        topic: z.string().min(2).max(30),
        goal: z.string().min(10).max(120),
        coachTip: z.string().min(10).max(120),
      }),
    )
    .length(7),
});

export type PlannerFormValues = z.input<typeof plannerSchema>;
export type PlannerInput = z.infer<typeof plannerSchema>;
export type PlanRequestInput = z.infer<typeof planRequestSchema>;
export type WeeklyPlanGeneration = z.infer<typeof weeklyPlanGenerationSchema>;
