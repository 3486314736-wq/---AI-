import { z } from "zod";

export const quizAnswerRecordSchema = z.object({
  questionId: z.string().min(1),
  selectedOptionId: z.string().min(1),
  correct: z.boolean(),
  answeredAt: z.string().datetime(),
});

export const lessonProgressPatchSchema = z.object({
  type: z.literal("lesson_patch"),
  requestKey: z.string().min(1).max(200),
  planId: z.string().min(1).max(80).nullable().optional(),
  subject: z.string().min(2).max(30),
  focus: z.string().min(2).max(40),
  dayNumber: z.coerce.number().int().min(1).max(7),
  viewedSlideIds: z.array(z.string().min(1)).optional(),
  quizAnswers: z.array(quizAnswerRecordSchema).optional(),
  tutorQuestionCount: z.coerce.number().int().min(0).optional(),
});

export const checkInRequestSchema = z.object({
  type: z.literal("check_in"),
  requestKey: z.string().min(1).max(200),
  planId: z.string().min(1).max(80).nullable().optional(),
  subject: z.string().min(2).max(30),
  focus: z.string().min(2).max(40),
  dayNumber: z.coerce.number().int().min(1).max(7),
  level: z.enum(["light", "standard", "full"]).optional(),
});

export const progressPostSchema = z.discriminatedUnion("type", [
  lessonProgressPatchSchema,
  checkInRequestSchema,
]);

export const progressQuerySchema = z.object({
  planId: z.string().min(1).max(80).optional(),
  requestKey: z.string().min(1).max(200).optional(),
});
