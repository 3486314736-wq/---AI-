import type { QuizQuestion } from "@/types/slide";
import type { LessonSlide } from "@/types/slide";

export function deriveQuizQuestions(slide: LessonSlide): QuizQuestion[] {
  if (slide.questions && slide.questions.length > 0) {
    return slide.questions;
  }

  const stems = slide.bullets.slice(0, 3);

  return stems.map((bullet, index) => {
    const correctId = `opt-${index}-a`;
    const distractors = slide.bullets
      .filter((_, bulletIndex) => bulletIndex !== index)
      .slice(0, 2)
      .map((text, distractorIndex) => ({
        id: `opt-${index}-${String.fromCharCode(98 + distractorIndex)}`,
        text,
      }));

    return {
      id: `fallback-q-${index + 1}`,
      stem: bullet.endsWith("？") || bullet.endsWith("?") ? bullet : `${bullet}（请选择最符合的说法）`,
      options: [
        { id: correctId, text: bullet },
        ...distractors,
        { id: `opt-${index}-d`, text: "以上说法都不完整" },
      ],
      correctOptionId: correctId,
      explanation: slide.example,
    };
  });
}

export function scoreQuizAnswers(
  questions: QuizQuestion[],
  answers: Array<{ questionId: string; selectedOptionId: string }>,
) {
  const correctCount = answers.filter((answer) => {
    const question = questions.find((item) => item.id === answer.questionId);
    return question?.correctOptionId === answer.selectedOptionId;
  }).length;

  return {
    correctCount,
    total: questions.length,
    allAttempted: answers.length >= questions.length,
    allCorrect: correctCount === questions.length && questions.length > 0,
  };
}
