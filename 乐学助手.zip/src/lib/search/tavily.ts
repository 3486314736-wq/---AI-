import type { LessonSource } from "@/types/slide";

interface TavilyResult {
  title?: string;
  url?: string;
  content?: string;
  score?: number;
}

interface TavilyResponse {
  answer?: string;
  results?: TavilyResult[];
}

const MIN_SOURCE_SCORE = 0.55;
const MAX_USABLE_SOURCES = 4;

export class SearchServiceError extends Error {
  constructor(
    message: string,
    public readonly statusCode = 500,
    public readonly code = "SEARCH_SERVICE_FAILED",
  ) {
    super(message);
    this.name = "SearchServiceError";
  }
}

function buildSearchQuery(subject: string, focus: string) {
  return `${subject} ${focus} 知识点讲解 通俗解释 经典例题`;
}

function normalizeUrl(url: string) {
  return url.replace(/\/+$/, "");
}

export async function searchLessonSources({
  subject,
  focus,
}: {
  subject: string;
  focus: string;
}): Promise<{ answer: string | null; sources: LessonSource[] }> {
  const apiKey = process.env.TAVILY_API_KEY;

  if (!apiKey) {
    throw new SearchServiceError(
      "未检测到 TAVILY_API_KEY，请先配置搜索服务后再生成课程。",
      503,
      "MISSING_TAVILY_API_KEY",
    );
  }

  const response = await fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      api_key: apiKey,
      query: buildSearchQuery(subject, focus),
      search_depth: "basic",
      topic: "general",
      max_results: 5,
      include_answer: true,
      include_raw_content: false,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    if (response.status === 401 || response.status === 403) {
      throw new SearchServiceError(
        "Tavily 鉴权失败，请检查 TAVILY_API_KEY 是否填写正确。",
        401,
        "SEARCH_AUTH_FAILED",
      );
    }

    if (response.status === 429) {
      throw new SearchServiceError(
        "Tavily 搜索频率受限，请稍后重试。",
        429,
        "SEARCH_RATE_LIMITED",
      );
    }

    throw new SearchServiceError(
      `搜索服务暂时不可用 (${response.status}): ${errorText}`,
      502,
      "SEARCH_PROVIDER_UNAVAILABLE",
    );
  }

  const payload = (await response.json()) as TavilyResponse;
  const seenUrls = new Set<string>();
  const sources =
    payload.results
      ?.filter((item): item is Required<Pick<TavilyResult, "title" | "url" | "content">> & TavilyResult =>
        Boolean(item.title && item.url && item.content),
      )
      .filter((item) => (item.score ?? 0) >= MIN_SOURCE_SCORE)
      .filter((item) => {
        const normalizedUrl = normalizeUrl(item.url!);

        if (seenUrls.has(normalizedUrl)) {
          return false;
        }

        seenUrls.add(normalizedUrl);
        return true;
      })
      .sort((left, right) => (right.score ?? 0) - (left.score ?? 0))
      .slice(0, MAX_USABLE_SOURCES)
      .map((item) => ({
        title: item.title!,
        url: item.url!,
        snippet: item.content!,
        score: item.score,
      })) ?? [];

  if (sources.length === 0) {
    throw new SearchServiceError(
      "未检索到足够的参考资料，请更换主题后重试。",
      404,
      "SEARCH_NO_RESULTS",
    );
  }

  return {
    answer: payload.answer ?? null,
    sources,
  };
}
