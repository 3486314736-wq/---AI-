import { createOpenAI } from "@ai-sdk/openai";

export type ModelProviderPreference = "auto" | "deepseek" | "openai";

export interface ModelProviderStatus {
  configuredProvider: "DeepSeek" | "OpenAI" | null;
  effectiveProvider: "DeepSeek" | "OpenAI" | null;
  modelName: string | null;
  baseURL: string | null;
  hasDeepSeekKey: boolean;
  hasOpenAIKey: boolean;
  preference: ModelProviderPreference;
  usingFallback: boolean;
}

function normalizeBaseUrl(baseURL: string) {
  return baseURL.replace(/\/+$/, "");
}

function getProviderPreference(): ModelProviderPreference {
  const preference = process.env.MODEL_PROVIDER?.trim().toLowerCase();

  if (preference === "deepseek" || preference === "openai" || preference === "auto") {
    return preference;
  }

  return "auto";
}

export function getModelProviderStatus(): ModelProviderStatus {
  const preference = getProviderPreference();
  const hasDeepSeekKey = Boolean(process.env.DEEPSEEK_API_KEY);
  const hasOpenAIKey = Boolean(process.env.OPENAI_API_KEY);
  const deepSeekBaseURL = normalizeBaseUrl(
    process.env.DEEPSEEK_BASE_URL ?? "https://api.deepseek.com",
  );
  const deepSeekModelName = process.env.DEEPSEEK_MODEL ?? "deepseek-v4-flash";
  const openAIModelName = process.env.OPENAI_MODEL ?? "gpt-4o-mini";

  if (preference === "deepseek") {
    return {
      configuredProvider: "DeepSeek",
      effectiveProvider: hasDeepSeekKey ? "DeepSeek" : null,
      modelName: hasDeepSeekKey ? deepSeekModelName : null,
      baseURL: hasDeepSeekKey ? deepSeekBaseURL : null,
      hasDeepSeekKey,
      hasOpenAIKey,
      preference,
      usingFallback: false,
    };
  }

  if (preference === "openai") {
    return {
      configuredProvider: "OpenAI",
      effectiveProvider: hasOpenAIKey ? "OpenAI" : null,
      modelName: hasOpenAIKey ? openAIModelName : null,
      baseURL: null,
      hasDeepSeekKey,
      hasOpenAIKey,
      preference,
      usingFallback: false,
    };
  }

  if (hasDeepSeekKey) {
    return {
      configuredProvider: "DeepSeek",
      effectiveProvider: "DeepSeek",
      modelName: deepSeekModelName,
      baseURL: deepSeekBaseURL,
      hasDeepSeekKey,
      hasOpenAIKey,
      preference,
      usingFallback: false,
    };
  }

  if (hasOpenAIKey) {
    return {
      configuredProvider: "OpenAI",
      effectiveProvider: "OpenAI",
      modelName: openAIModelName,
      baseURL: null,
      hasDeepSeekKey,
      hasOpenAIKey,
      preference,
      usingFallback: true,
    };
  }

  return {
    configuredProvider: null,
    effectiveProvider: null,
    modelName: null,
    baseURL: null,
    hasDeepSeekKey,
    hasOpenAIKey,
    preference,
    usingFallback: false,
  };
}

export function getLanguageModel() {
  const status = getModelProviderStatus();

  if (status.effectiveProvider === "DeepSeek" && process.env.DEEPSEEK_API_KEY) {
    const deepseek = createOpenAI({
      apiKey: process.env.DEEPSEEK_API_KEY,
      baseURL: status.baseURL ?? "https://api.deepseek.com",
      name: "deepseek",
    });

    return {
      model: deepseek.chat(status.modelName ?? "deepseek-chat"),
      modelName: status.modelName ?? "deepseek-chat",
      providerName: "DeepSeek" as const,
      baseURL: status.baseURL,
      usingFallback: status.usingFallback,
    };
  }

  if (status.effectiveProvider === "OpenAI" && process.env.OPENAI_API_KEY) {
    const openai = createOpenAI({ apiKey: process.env.OPENAI_API_KEY });

    return {
      model: openai(status.modelName ?? "gpt-4o-mini"),
      modelName: status.modelName ?? "gpt-4o-mini",
      providerName: "OpenAI" as const,
      baseURL: null,
      usingFallback: status.usingFallback,
    };
  }

  if (status.preference === "deepseek") {
    throw new Error("MISSING_DEEPSEEK_API_KEY");
  }

  if (status.preference === "openai") {
    throw new Error("MISSING_OPENAI_API_KEY");
  }

  throw new Error("MISSING_MODEL_API_KEY");
}
