import { generateObject } from "ai";
import { z } from "zod";
import { getLanguageModel, getModelProviderStatus } from "@/lib/ai/provider";

export class StructuredGenerationError extends Error {
  constructor(
    message: string,
    public readonly statusCode = 500,
    public readonly code = "STRUCTURED_GENERATION_FAILED",
  ) {
    super(message);
    this.name = "StructuredGenerationError";
  }
}

interface DeepSeekChatCompletionResponse {
  choices?: Array<{
    message?: {
      content?: string;
    };
  }>;
}

export async function generateStructuredOutput<T>({
  schema,
  system,
  prompt,
  temperature = 0.4,
  maxRetries = 1,
  maxTokens = 4000,
}: {
  schema: z.ZodType<T>;
  system: string;
  prompt: string;
  temperature?: number;
  maxRetries?: number;
  maxTokens?: number;
}): Promise<{
  object: T;
  providerName: "DeepSeek" | "OpenAI";
  modelName: string;
}> {
  const status = getModelProviderStatus();

  if (status.effectiveProvider === "DeepSeek") {
    const apiKey = process.env.DEEPSEEK_API_KEY;
    const baseURL = status.baseURL ?? "https://api.deepseek.com";
    const modelName = status.modelName ?? "deepseek-chat";

    if (!apiKey) {
      throw new StructuredGenerationError(
        "当前已选择 DeepSeek，但未检测到 DEEPSEEK_API_KEY。",
        503,
        "MISSING_DEEPSEEK_API_KEY",
      );
    }

    const response = await fetch(`${baseURL}/chat/completions`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: modelName,
        messages: [
          {
            role: "system",
            content: `${system}\n\nYou must return valid JSON only.`,
          },
          {
            role: "user",
            content: `请严格按要求完成，并且只返回合法的 JSON 对象，不要添加 markdown、解释或额外文本。\n\n${prompt}`,
          },
        ],
        response_format: { type: "json_object" },
        temperature,
        max_tokens: maxTokens,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      if (response.status === 401 || response.status === 403) {
        throw new StructuredGenerationError(
          "DeepSeek 鉴权失败，请检查 API Key 是否正确。",
          401,
          "MODEL_AUTH_FAILED",
        );
      }

      if (response.status === 429) {
        throw new StructuredGenerationError(
          "DeepSeek 调用频率受限或账户余额不足，请稍后重试。",
          429,
          "MODEL_RATE_LIMITED",
        );
      }

      throw new StructuredGenerationError(
        `DeepSeek 服务暂时不可用 (${response.status}): ${errorText}`,
        503,
        "MODEL_PROVIDER_UNAVAILABLE",
      );
    }

    const payload = (await response.json()) as DeepSeekChatCompletionResponse;
    const content = payload.choices?.[0]?.message?.content;

    if (!content) {
      throw new StructuredGenerationError(
        "DeepSeek 未返回可解析的 JSON 内容。",
        502,
        "INVALID_MODEL_OUTPUT",
      );
    }

    let parsed: unknown;

    try {
      parsed = JSON.parse(content);
    } catch {
      throw new StructuredGenerationError(
        "DeepSeek 返回了非 JSON 内容，无法完成结构化解析。",
        502,
        "INVALID_MODEL_OUTPUT",
      );
    }

    const validated = schema.safeParse(parsed);

    if (!validated.success) {
      const issues = validated.error.issues;
      const issueSummary = issues
        .slice(0, 3)
        .map((issue) => {
          const path = issue.path.join(".") || "根对象";
          return `· ${path}: ${issue.message}`;
        })
        .join("\n");
      const extraNote =
        issues.length > 3 ? `\n· ... 其余 ${issues.length - 3} 项问题不再列出。` : "";
      throw new StructuredGenerationError(
        `DeepSeek 返回的结果不符合要求，具体问题：\n${issueSummary}${extraNote}\n\n请重试，或尝试换用更稳定的模型。`,
        502,
        "INVALID_MODEL_OUTPUT",
      );
    }

    return {
      object: validated.data,
      providerName: "DeepSeek",
      modelName,
    };
  }

  const languageModel = getLanguageModel();
  const result = await generateObject({
    model: languageModel.model,
    schema,
    system,
    prompt,
    temperature,
    maxRetries,
  });

  return {
    object: result.object,
    providerName: languageModel.providerName,
    modelName: languageModel.modelName,
  };
}
