# 🎓 中小学生个性化学习助手 - v1.0

> 腾讯黑客松参赛作品
>
> 基于 AI 大模型的智能教育平台，为中小学生提供个性化学习方案、AI 生成课程和多模态答疑服务。

---

## 📖 项目简介

中小学生个性化学习助手是一款 **AI 驱动的自适应学习平台**，通过大语言模型为学生量身定制学习计划，自动生成精美课件，并提供智能答疑服务。

### ✨ 核心特性

| 功能 | 描述 |
|------|------|
| 📅 **智能学习规划** | 根据学生画像自动生成 7 天个性化学习计划 |
| 📚 **AI 课程生成** | 结合网络搜索资料，自动生成结构化课件 |
| 🎨 **PPT 一键导出** | 自动配图，生成精美教学 PowerPoint |
| 💬 **多模态答疑** | 支持文字 + 图片上传，AI 智能解答 |
| 📊 **学习进度追踪** | 实时记录学习进度，错题回顾，打卡激励 |

---

## 🛠️ 技术栈

| 类别 | 技术 |
|------|------|
| **前端框架** | Next.js 16 + React 19 + TypeScript |
| **样式方案** | Tailwind CSS |
| **AI SDK** | Vercel AI SDK |
| **大模型** | DeepSeek (主要) / OpenAI (备用) |
| **搜索服务** | Tavily Search API |
| **PPT 生成** | Python + python-pptx |
| **表单验证** | React Hook Form + Zod |

---

## 🚀 快速开始

### 环境要求

- Node.js >= 18
- Python >= 3.9 (用于 PPT 生成)

### 1. 安装依赖

```bash
npm install
```

### 2. 配置环境变量

复制环境变量模板：

```bash
copy .env.example .env.local
```

编辑 `.env.local`，填入你的 API 密钥：

```env
# 模型配置
MODEL_PROVIDER=auto

# DeepSeek 配置 (推荐)
DEEPSEEK_API_KEY=your_deepseek_api_key
DEEPSEEK_BASE_URL=https://api.deepseek.com
DEEPSEEK_MODEL=deepseek-v4-flash
DEEPSEEK_MULTIMODAL_MODEL=deepseek-chat

# Tavily 搜索配置
TAVILY_API_KEY=your_tavily_api_key

# OpenAI 备用配置
# OPENAI_API_KEY=your_openai_api_key
# OPENAI_MODEL=gpt-4o-mini
```

### 3. 启动开发服务器

```bash
npm run dev
```

浏览器会自动打开 [http://localhost:3000](http://localhost:3000)

### 4. 验证配置

访问自检接口确认配置正确：

```bash
curl http://localhost:3000/api/model
```

---

## 📚 功能使用指南

### 1️⃣ 生成学习计划

1. 访问 `/planner` 页面
2. 填写学习画像（科目、年级、学习目标等）
3. 点击「生成计划」
4. AI 自动生成 7 天个性化学习计划

### 2️⃣ 学习课程

1. 在计划页点击任意一天的「开始学习」
2. 进入 Web 幻灯片课程页
3. 浏览课件内容，完成随堂小测
4. 点击「导出PPT」下载精美课件

### 3️⃣ 多模态答疑

1. 在课程页右侧答疑区输入问题
2. 可上传题目截图辅助 AI 理解
3. AI 给出针对性解答

### 4️⃣ 学习记录

1. 访问 `/records` 页面
2. 查看历史学习进度和数据统计

---

## 🏗️ 项目架构

```
📁 src/
├── 📁 app/                    # Next.js App Router
│   ├── 📁 api/                # API 路由
│   │   ├── 📁 plan/          # 学习计划生成
│   │   ├── 📁 lesson/        # 课程生成
│   │   ├── 📁 ppt/           # PPT 导出
│   │   ├── 📁 chat/          # 多模态答疑
│   │   ├── 📁 progress/      # 进度追踪
│   │   └── 📁 model/         # 模型配置自检
│   ├── 📁 planner/           # 计划生成页
│   ├── 📁 plan/[planId]/     # 周计划展示页
│   ├── 📁 lesson/[lessonId]/ # 课程学习页
│   └── 📁 records/           # 学习记录页
├── 📁 components/            # React 组件
│   ├── 📁 planner/           # 计划相关组件
│   ├── 📁 slides/            # 课件组件
│   ├── 📁 chat/              # 答疑组件
│   └── 📁 lesson/            # 课程组件
├── 📁 features/              # 业务逻辑
│   ├── 📁 planning/          # 计划生成服务
│   ├── 📁 lesson-generation/ # 课程生成服务
│   ├── 📁 tutoring/          # 答疑服务
│   └── 📁 progress/          # 进度计算
├── 📁 lib/                   # 工具库
│   ├── 📁 ai/                # AI 提供者
│   ├── 📁 search/            # 搜索服务
│   └── 📁 validations/       # Zod 校验
└── 📁 types/                 # TypeScript 类型定义

📁 scripts/                   # Python 脚本
└── 📄 ppt_generator_enhanced.py  # PPT 生成器
```

---

## 🎯 核心亮点

### 1. 智能学习规划
- 基于学生画像的个性化计划生成
- 结构化输出，自动 Zod Schema 校验
- 优雅的错误处理和用户提示

### 2. AI 课程生成
- Tavily 网络搜索 + 大模型整合
- 自动生成知识点、例题、小测
- 支持历史版本管理和回退

### 3. 多模态答疑
- 支持图片上传（题目截图）
- DeepSeek 视觉模型智能识别
- 实时聊天体验

### 4. PPT 智能配图
- 学科相关的自动配图
- 图片缓存机制
- 一键下载精美课件

---

## 📊 已完成功能 (v1.0)

### ✅ Phase 1 - 基础框架
- [x] 产品页面骨架
- [x] 学习画像表单
- [x] 周计划结果页
- [x] 课程页原型
- [x] 简洁美观的 UI

### ✅ Phase 2 - 学习规划
- [x] DeepSeek 模型接入
- [x] 7 天学习计划生成
- [x] Schema 校验和错误处理
- [x] OpenAI 备用方案

### ✅ Phase 3 - 课程生成
- [x] Tavily 搜索集成
- [x] 结构化课程生成
- [x] 本地缓存和历史版本
- [x] PPT 导出（带自动配图）

### ✅ Phase 4 - 多模态答疑
- [x] 图片上传和预览
- [x] DeepSeek 视觉模型接入
- [x] 历史聊天记录

---

## 🔧 配置说明

### 模型策略

项目默认采用 `MODEL_PROVIDER=auto` 策略：
- 有 `DEEPSEEK_API_KEY` 时，优先使用 DeepSeek
- 没有 DeepSeek 但有 `OPENAI_API_KEY` 时，自动回退 OpenAI
- 两者都没有时，返回明确错误提示

### API 密钥获取

| 服务 | 获取地址 | 说明 |
|------|---------|------|
| DeepSeek | https://platform.deepseek.com | 推荐，性价比高 |
| OpenAI | https://platform.openai.com | 备用，GPT-4o 效果好 |
| Tavily | https://tavily.com | 搜索服务，免费额度充足 |

---

## 🐛 常见问题

### Q: PPT 导出失败怎么办？
A: 确保已安装 Python 和依赖：
```bash
pip install python-pptx
```

### Q: 模型调用报错？
A: 检查 `.env.local` 中的 API Key 是否正确，访问 `/api/model` 查看配置状态。

### Q: 如何切换模型？
A: 在 `.env.local` 中设置 `MODEL_PROVIDER=deepseek` 或 `MODEL_PROVIDER=openai` 强制指定。

---

## 📝 开发命令

```bash
npm run dev          # 启动开发服务器（自动打开浏览器）
npm run build        # 构建生产版本
npm start            # 启动生产服务器
npm run lint         # 代码检查
```

---

## 🏆 参赛说明

### 作品主题
**AI + 教育 - 让学习更智能、更个性化**

### 创新点
1. **个性化学习** - AI 根据学生特点定制学习路径
2. **内容生成** - 自动生成结构化课件和练习题
3. **多模态交互** - 支持图文混合的智能答疑
4. **落地性强** - 完整闭环，可直接投入使用

### 技术亮点
- 前后端一体化 Next.js 方案
- 多模型容错和自动回退机制
- 结构化输出 + Zod 校验保证质量
- Python + TypeScript 跨语言协作

---

## 📄 许可证

MIT License

---

## 🤝 致谢

感谢以下开源项目和服务：
- Next.js - React 框架
- Vercel AI SDK - AI 应用开发
- DeepSeek - 大语言模型
- Tavily - 搜索服务
- Picsum Photos - 免费图片服务

---

## 📮 联系方式

如有问题或建议，欢迎提交 Issue！

---

**💡 让每个孩子都能享受 AI 带来的个性化教育！**
