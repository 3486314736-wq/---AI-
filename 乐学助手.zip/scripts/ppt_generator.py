#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
PPT课件生成器 - 完整版
使用 python-pptx 库将课程内容生成精美的PowerPoint文档
支持学科配色、多种布局模板、占位图、完整教学流程
"""

import json
import sys
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN


class SubjectColors:
    """学科配色方案"""
    CHINESE = {
        "primary": RGBColor(198, 40, 40),
        "secondary": RGBColor(27, 94, 32),
        "accent": RGBColor(255, 193, 7)
    }
    MATH = {
        "primary": RGBColor(0, 137, 123),
        "secondary": RGBColor(27, 94, 32),
        "accent": RGBColor(255, 152, 0)
    }
    ENGLISH = {
        "primary": RGBColor(26, 35, 126),
        "secondary": RGBColor(106, 27, 154),
        "accent": RGBColor(240, 98, 146)
    }
    PHYSICS = {
        "primary": RGBColor(69, 39, 160),
        "secondary": RGBColor(0, 188, 212),
        "accent": RGBColor(255, 87, 34)
    }
    DEFAULT = {
        "primary": RGBColor(13, 148, 136),
        "secondary": RGBColor(100, 116, 139),
        "accent": RGBColor(249, 115, 22)
    }


class PPTGenerator:
    def __init__(self, deck_data):
        self.deck_data = deck_data
        self.prs = Presentation()
        self.prs.slide_width = Inches(13.333)
        self.prs.slide_height = Inches(7.5)
        
        # 识别学科配色
        self.colors = self._detect_subject_colors()
        
        # 空白布局
        self.blank_layout = self.prs.slide_layouts[6]
        
        print("PPT Generator initialized with colors")

    def _detect_subject_colors(self):
        """根据课程标题识别学科配色"""
        title = self.deck_data.get("title", "").lower()
        
        if "语文" in title or "文言文" in title or "诗词" in title:
            return SubjectColors.CHINESE
        elif "数学" in title or "几何" in title or "代数" in title:
            return SubjectColors.MATH
        elif "英语" in title or "English" in title:
            return SubjectColors.ENGLISH
        elif "物理" in title:
            return SubjectColors.PHYSICS
        else:
            return SubjectColors.DEFAULT

    def _set_background(self, slide):
        """设置背景颜色"""
        try:
            background = slide.background
            fill = background.fill
            fill.solid()
            fill.fore_color.rgb = RGBColor(255, 255, 255)
        except Exception as e:
            print(f"Warning: Could not set background: {e}")

    def _add_textbox(self, slide, left, top, width, height, text, font_size, bold=False, color=None, align=PP_ALIGN.LEFT):
        """添加文本框 - 支持中文字体"""
        txBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txBox.text_frame
        tf.word_wrap = True
        
        # 清空默认段落
        for p in tf.paragraphs:
            p.clear()
        
        p = tf.paragraphs[0]
        p.text = text
        p.font.size = Pt(font_size)
        p.font.bold = bold
        p.font.name = "Microsoft YaHei"
        if color:
            p.font.color.rgb = color
        p.alignment = align
        
        return txBox

    def add_title_slide(self):
        """1. 封面页"""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        title = self.deck_data.get("title", "课程课件")
        description = self.deck_data.get("description", "")
        
        # 主标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(2.5),
            width=Inches(11.333),
            height=Inches(1.5),
            text=title,
            font_size=48,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 副标题
        if description:
            self._add_textbox(
                slide,
                left=Inches(1),
                top=Inches(4.2),
                width=Inches(11.333),
                height=Inches(1),
                text=description,
                font_size=24,
                color=RGBColor(100, 116, 139),
                align=PP_ALIGN.CENTER
            )
        
        # 占位图区域
        self._add_placeholder_box(slide, Inches(10), Inches(1), Inches(2), Inches(2), "配图区")
        
        print("Title slide created")

    def add_toc_slide(self):
        """2. 目录页"""
        slides = self.deck_data.get("slides", [])
        content_slides = [s for s in slides if s.get("kind") == "content"]
        
        if not content_slides:
            return
        
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 目录标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.8),
            width=Inches(11.333),
            height=Inches(0.8),
            text="本节课学习内容",
            font_size=32,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 目录列表
        toc_text = ""
        for i, s in enumerate(content_slides[:6], 1):
            toc_text += f"{i}. {s.get('title', '')}\n"
        
        self._add_textbox(
            slide,
            left=Inches(2),
            top=Inches(2),
            width=Inches(9.333),
            height=Inches(4),
            text=toc_text,
            font_size=20,
            color=RGBColor(51, 65, 85)
        )
        
        print("TOC slide created")

    def add_intro_slide(self, first_slide_data):
        """3. 情境导入页"""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.8),
            width=Inches(11.333),
            height=Inches(0.8),
            text="情境导入",
            font_size=32,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 左侧：占位图
        self._add_placeholder_box(slide, Inches(0.5), Inches(2), Inches(5), Inches(4), "情境图")
        
        # 右侧：内容
        summary = first_slide_data.get("summary", "")
        bullets = first_slide_data.get("bullets", [])
        
        intro_text = summary + "\n\n"
        if bullets:
            intro_text += "思考问题：\n"
            intro_text += "\n".join([f"* {b}" for b in bullets[:2]])
        
        self._add_textbox(
            slide,
            left=Inches(6),
            top=Inches(2),
            width=Inches(6.833),
            height=Inches(4.5),
            text=intro_text,
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        print("Intro slide created")

    def add_content_slide(self, slide_data, index):
        """4. 知识讲解页 - 左右分栏布局"""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        title = slide_data.get("title", "")
        summary = slide_data.get("summary", "")
        bullets = slide_data.get("bullets", [])
        example = slide_data.get("example", "")
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.5),
            width=Inches(11.333),
            height=Inches(0.7),
            text=title,
            font_size=28,
            bold=True,
            color=self.colors["primary"]
        )
        
        # 左侧：占位图
        self._add_placeholder_box(slide, Inches(0.5), Inches(1.5), Inches(4.5), Inches(5), "示意图")
        
        # 右侧：内容
        content_text = summary + "\n\n" if summary else ""
        content_text += "知识要点：\n"
        content_text += "\n".join([f"* {b}" for b in bullets])
        
        if example:
            content_text += f"\n\n示例：{example}"
        
        self._add_textbox(
            slide,
            left=Inches(5.2),
            top=Inches(1.5),
            width=Inches(7.633),
            height=Inches(5.2),
            text=content_text,
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        print(f"Content slide {index} created")

    def add_example_slide(self, slide_data):
        """5. 例题解析页"""
        example = slide_data.get("example", "")
        if not example:
            return
        
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.5),
            width=Inches(11.333),
            height=Inches(0.7),
            text="例题解析",
            font_size=28,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 左侧：题目
        self._add_textbox(
            slide,
            left=Inches(0.5),
            top=Inches(1.5),
            width=Inches(5.5),
            height=Inches(5),
            text=f"题目：\n{example}",
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        # 右侧：解题步骤占位
        solution_text = """解题步骤

步骤一：分析已知条件
步骤二：寻找解题思路
步骤三：列式计算
步骤四：检验答案

关键提示：
注意公式运用和计算准确性"""
        
        self._add_textbox(
            slide,
            left=Inches(6.3),
            top=Inches(1.5),
            width=Inches(6.533),
            height=Inches(5),
            text=solution_text,
            font_size=18,
            color=self.colors["secondary"]
        )
        
        print("Example slide created")

    def add_quiz_slide(self, quiz_slide_data):
        """6. 练习巩固页 - 显示Quiz题目"""
        questions = quiz_slide_data.get("questions", [])
        
        if not questions:
            return
        
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.5),
            width=Inches(11.333),
            height=Inches(0.7),
            text="练习巩固",
            font_size=28,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 展示前2道题
        quiz_text = ""
        for i, q in enumerate(questions[:2], 1):
            quiz_text += f"第 {i} 题：{q.get('stem', '')}\n"
            options = q.get('options', [])
            for opt in options:
                quiz_text += f"  {opt.get('id', '')}. {opt.get('text', '')}\n"
            quiz_text += "\n"
        
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(1.5),
            width=Inches(11.333),
            height=Inches(5),
            text=quiz_text,
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        print("Quiz slide created")

    def add_summary_slide(self):
        """7. 课堂总结页"""
        slides = self.deck_data.get("slides", [])
        content_slides = [s for s in slides if s.get("kind") == "content"]
        
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.5),
            width=Inches(11.333),
            height=Inches(0.7),
            text="课堂总结",
            font_size=28,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 左侧：思维导图占位
        self._add_placeholder_box(slide, Inches(0.5), Inches(1.5), Inches(5.5), Inches(5), "思维导图")
        
        # 右侧：要点总结
        summary_text = "本节课重点：\n\n"
        for i, s in enumerate(content_slides[:5], 1):
            summary_text += f"{i}. {s.get('title', '')}\n"
        
        summary_text += "\n\n课后作业：\n"
        summary_text += "* 完成课本对应练习题\n"
        summary_text += "* 整理本节课笔记"
        
        self._add_textbox(
            slide,
            left=Inches(6.3),
            top=Inches(1.5),
            width=Inches(6.533),
            height=Inches(5),
            text=summary_text,
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        print("Summary slide created")

    def _add_placeholder_box(self, slide, left, top, width, height, label="图片"):
        """添加占位图框"""
        # 添加矩形框
        try:
            shape = slide.shapes.add_shape(
                1,  # MSO_SHAPE.RECTANGLE
                left, top, width, height
            )
            
            # 设置虚线边框
            fill = shape.fill
            fill.solid()
            fill.fore_color.rgb = RGBColor(245, 245, 245)
            
            line = shape.line
            line.color.rgb = RGBColor(200, 200, 200)
            line.dash_style = 4  # DASHED
        except Exception as e:
            print(f"Warning: Could not add placeholder box: {e}")
        
        # 添加标签文本
        try:
            self._add_textbox(
                slide,
                left, top + height/2 - Inches(0.2),
                width, Inches(0.4),
                text=f"[{label}]",
                font_size=14,
                color=RGBColor(150, 150, 150),
                align=PP_ALIGN.CENTER
            )
        except Exception as e:
            print(f"Warning: Could not add placeholder label: {e}")

    def generate(self, output_path):
        """生成完整PPT"""
        slides = self.deck_data.get("slides", [])
        content_slides = [s for s in slides if s.get("kind") == "content"]
        quiz_slides = [s for s in slides if s.get("kind") == "quiz"]
        
        # 1. 封面页
        self.add_title_slide()
        
        # 2. 目录页
        self.add_toc_slide()
        
        # 3. 情境导入页（使用第一页内容）
        if content_slides:
            self.add_intro_slide(content_slides[0])
        
        # 4. 知识讲解页
        for i, slide_data in enumerate(content_slides, 1):
            self.add_content_slide(slide_data, i)
            # 有示例的话添加例题页
            if slide_data.get("example", ""):
                self.add_example_slide(slide_data)
        
        # 5. 练习巩固页
        for quiz_slide in quiz_slides:
            self.add_quiz_slide(quiz_slide)
        
        # 6. 课堂总结页
        self.add_summary_slide()
        
        # 保存
        self.prs.save(output_path)
        print(f"PPT saved to: {output_path}")
        print("[SUCCESS] PPT Generation COMPLETED!")
        print(f"[OK] Total slides: {len(self.prs.slides)}")


def main():
    if len(sys.argv) < 3:
        print("Usage: python ppt_generator.py <input_json> <output_pptx>")
        sys.exit(1)

    input_path = sys.argv[1]
    output_path = sys.argv[2]

    print("=" * 50)
    print("Enhanced PPT Generator Starting...")
    print("=" * 50)
    print("Input JSON:", input_path)
    print("Output PPT:", output_path)

    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            deck_data = json.load(f)
        print("[OK] JSON data loaded")
    except Exception as e:
        print(f"[ERROR] loading JSON: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

    try:
        generator = PPTGenerator(deck_data)
        generator.generate(output_path)
        print("=" * 50)
        print("[SUCCESS]")
        print("=" * 50)
        sys.exit(0)
    except Exception as e:
        print(f"[ERROR] generating PPT: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
