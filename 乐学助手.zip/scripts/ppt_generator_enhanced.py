#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
PPT课件生成器 - 配图增强版
使用 python-pptx 库将课程内容生成精美的PowerPoint文档
支持学科配色、多种布局模板、自动配图、完整教学流程
"""

import json
import sys
import os
import re
import urllib.request
import urllib.parse
import hashlib
from pathlib import Path
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN


class SubjectColors:
    """学科配色方案"""
    CHINESE = {
        "primary": RGBColor(198, 40, 40),
        "secondary": RGBColor(27, 94, 32),
        "accent": RGBColor(255, 193, 7)
    }
    MATH = {
        "primary": RGBColor(0, 137, 123),
        "secondary": RGBColor(27, 94, 32),
        "accent": RGBColor(255, 152, 0)
    }
    ENGLISH = {
        "primary": RGBColor(26, 35, 126),
        "secondary": RGBColor(106, 27, 154),
        "accent": RGBColor(240, 98, 146)
    }
    PHYSICS = {
        "primary": RGBColor(69, 39, 160),
        "secondary": RGBColor(0, 188, 212),
        "accent": RGBColor(255, 87, 34)
    }
    DEFAULT = {
        "primary": RGBColor(13, 148, 136),
        "secondary": RGBColor(100, 116, 139),
        "accent": RGBColor(249, 115, 22)
    }


class SubjectImageKeywords:
    """学科图片关键词映射"""
    CHINESE_KEYWORDS = ["chinese calligraphy", "ancient china", "ink painting", "confucius", "traditional chinese", "bamboo", "chinese literature"]
    MATH_KEYWORDS = ["mathematics", "geometry", "numbers", "equations", "calculus", "math education", "abacus"]
    ENGLISH_KEYWORDS = ["english literature", "books", "language learning", "shakespeare", "education", "classroom"]
    PHYSICS_KEYWORDS = ["physics", "science experiment", "laboratory", "newton", "einstein", "atom", "quantum physics"]
    DEFAULT_KEYWORDS = ["education", "learning", "classroom", "students", "teacher", "school", "knowledge"]


class ImageProvider:
    """图片提供者 - 使用免费图片API"""
    
    def __init__(self, cache_dir=None):
        self.cache_dir = cache_dir or Path(__file__).parent.parent / "public" / "images" / "cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # 使用稳定的占位图片服务
        self.placeholder_services = [
            "https://picsum.photos/800/600?random={seed}",
            "https://placehold.co/800x600/e2e8f0/64748b?text={text}",
        ]
    
    def get_image_url(self, keywords, index=0):
        """获取图片URL - 使用随机图片服务"""
        seed = abs(hash(keywords + str(index))) % 10000
        
        # 使用 picsum.photos
        url = self.placeholder_services[0].format(seed=seed)
        return url
    
    def download_image(self, keywords, index=0):
        """下载图片并缓存"""
        cache_key = hashlib.md5(f"{keywords}_{index}".encode()).hexdigest()
        cache_file = self.cache_dir / f"{cache_key}.jpg"
        
        if cache_file.exists():
            print(f"[Image] 使用缓存图片: {cache_file}")
            return str(cache_file)
        
        try:
            url = self.get_image_url(keywords, index)
            print(f"[Image] 下载图片: {url}")
            
            # 设置超时和用户代理
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            req = urllib.request.Request(url, headers=headers)
            
            with urllib.request.urlopen(req, timeout=10) as response:
                with open(cache_file, 'wb') as f:
                    f.write(response.read())
            
            print(f"[Image] 图片已缓存: {cache_file}")
            return str(cache_file)
            
        except Exception as e:
            print(f"[Image] 下载失败: {e}")
            return None


class PPTGenerator:
    def __init__(self, deck_data):
        self.deck_data = deck_data
        self.prs = Presentation()
        self.prs.slide_width = Inches(13.333)
        self.prs.slide_height = Inches(7.5)
        
        # 识别学科配色和关键词
        self.colors = self._detect_subject_colors()
        self.keywords = self._detect_subject_keywords()
        
        # 图片提供者
        self.image_provider = ImageProvider()
        
        # 空白布局
        self.blank_layout = self.prs.slide_layouts[6]
        
        print("PPT Generator initialized with colors and images")
    
    def _detect_subject_colors(self):
        """根据课程标题识别学科配色"""
        title = self.deck_data.get("title", "").lower()
        
        if "语文" in title or "文言文" in title or "诗词" in title:
            return SubjectColors.CHINESE
        elif "数学" in title or "几何" in title or "代数" in title:
            return SubjectColors.MATH
        elif "英语" in title or "English" in title:
            return SubjectColors.ENGLISH
        elif "物理" in title:
            return SubjectColors.PHYSICS
        else:
            return SubjectColors.DEFAULT
    
    def _detect_subject_keywords(self):
        """根据课程标题识别学科关键词"""
        title = self.deck_data.get("title", "").lower()
        
        if "语文" in title or "文言文" in title or "诗词" in title:
            return SubjectImageKeywords.CHINESE_KEYWORDS
        elif "数学" in title or "几何" in title or "代数" in title:
            return SubjectImageKeywords.MATH_KEYWORDS
        elif "英语" in title or "English" in title:
            return SubjectImageKeywords.ENGLISH_KEYWORDS
        elif "物理" in title:
            return SubjectImageKeywords.PHYSICS_KEYWORDS
        else:
            return SubjectImageKeywords.DEFAULT_KEYWORDS
    
    def _set_background(self, slide):
        """设置背景颜色"""
        try:
            background = slide.background
            fill = background.fill
            fill.solid()
            fill.fore_color.rgb = RGBColor(255, 255, 255)
        except Exception as e:
            print(f"Warning: Could not set background: {e}")
    
    def _add_textbox(self, slide, left, top, width, height, text, font_size, bold=False, color=None, align=PP_ALIGN.LEFT):
        """添加文本框 - 支持中文字体"""
        txBox = slide.shapes.add_textbox(left, top, width, height)
        tf = txBox.text_frame
        tf.word_wrap = True
        
        # 清空默认段落
        for p in tf.paragraphs:
            p.clear()
        
        p = tf.paragraphs[0]
        p.text = text
        p.font.size = Pt(font_size)
        p.font.bold = bold
        p.font.name = "Microsoft YaHei"
        if color:
            p.font.color.rgb = color
        p.alignment = align
        
        return txBox
    
    def _add_image(self, slide, left, top, width, height, keywords, index=0):
        """添加图片到PPT"""
        try:
            # 尝试下载图片
            image_path = self.image_provider.download_image(keywords, index)
            
            if image_path and os.path.exists(image_path):
                slide.shapes.add_picture(image_path, left, top, width, height)
                print(f"[Image] 图片已添加: {keywords}")
                return True
            else:
                print(f"[Image] 使用占位框: {keywords}")
                self._add_placeholder_box(slide, left, top, width, height, keywords.split()[0] if keywords else "图片")
                return False
                
        except Exception as e:
            print(f"Warning: Could not add image: {e}")
            self._add_placeholder_box(slide, left, top, width, height, keywords.split()[0] if keywords else "图片")
            return False
    
    def add_title_slide(self):
        """1. 封面页"""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        title = self.deck_data.get("title", "课程课件")
        description = self.deck_data.get("description", "")
        
        # 主标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(2.5),
            width=Inches(11.333),
            height=Inches(1.5),
            text=title,
            font_size=48,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 副标题
        if description:
            self._add_textbox(
                slide,
                left=Inches(1),
                top=Inches(4.2),
                width=Inches(11.333),
                height=Inches(1),
                text=description,
                font_size=24,
                color=RGBColor(100, 116, 139),
                align=PP_ALIGN.CENTER
            )
        
        # 添加配图 - 使用学科相关关键词
        keywords = " ".join(self.keywords[:2])
        self._add_image(slide, Inches(10), Inches(1), Inches(2), Inches(2), keywords, 0)
        
        print("Title slide created")
    
    def add_toc_slide(self):
        """2. 目录页"""
        slides = self.deck_data.get("slides", [])
        content_slides = [s for s in slides if s.get("kind") == "content"]
        
        if not content_slides:
            return
        
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 目录标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.8),
            width=Inches(11.333),
            height=Inches(0.8),
            text="本节课学习内容",
            font_size=32,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 目录列表
        toc_text = ""
        for i, s in enumerate(content_slides[:6], 1):
            toc_text += f"{i}. {s.get('title', '')}\n"
        
        self._add_textbox(
            slide,
            left=Inches(3),
            top=Inches(2),
            width=Inches(9.333),
            height=Inches(4),
            text=toc_text,
            font_size=20,
            color=RGBColor(51, 65, 85)
        )
        
        # 添加配图
        keywords = " ".join(self.keywords[1:3])
        self._add_image(slide, Inches(0.5), Inches(2.5), Inches(2), Inches(3), keywords, 1)
        
        print("TOC slide created")
    
    def add_intro_slide(self, first_slide_data):
        """3. 情境导入页"""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.8),
            width=Inches(11.333),
            height=Inches(0.8),
            text="情境导入",
            font_size=32,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 左侧：配图
        slide_title = first_slide_data.get("title", "")
        keywords = f"{slide_title} education learning"
        self._add_image(slide, Inches(0.5), Inches(2), Inches(5), Inches(4), keywords, 2)
        
        # 右侧：内容
        summary = first_slide_data.get("summary", "")
        bullets = first_slide_data.get("bullets", [])
        
        intro_text = summary + "\n\n"
        if bullets:
            intro_text += "思考问题：\n"
            intro_text += "\n".join([f"* {b}" for b in bullets[:2]])
        
        self._add_textbox(
            slide,
            left=Inches(6),
            top=Inches(2),
            width=Inches(6.833),
            height=Inches(4.5),
            text=intro_text,
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        print("Intro slide created")
    
    def add_content_slide(self, slide_data, index):
        """4. 知识讲解页 - 左右分栏布局"""
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        title = slide_data.get("title", "")
        summary = slide_data.get("summary", "")
        bullets = slide_data.get("bullets", [])
        example = slide_data.get("example", "")
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.5),
            width=Inches(11.333),
            height=Inches(0.7),
            text=title,
            font_size=28,
            bold=True,
            color=self.colors["primary"]
        )
        
        # 左侧：配图
        keywords = f"{title} {' '.join(self.keywords[:1])} diagram illustration"
        self._add_image(slide, Inches(0.5), Inches(1.5), Inches(4.5), Inches(5), keywords, index + 3)
        
        # 右侧：内容
        content_text = summary + "\n\n" if summary else ""
        content_text += "知识要点：\n"
        content_text += "\n".join([f"* {b}" for b in bullets])
        
        if example:
            content_text += f"\n\n示例：{example}"
        
        self._add_textbox(
            slide,
            left=Inches(5.2),
            top=Inches(1.5),
            width=Inches(7.633),
            height=Inches(5.2),
            text=content_text,
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        print(f"Content slide {index} created")
    
    def add_example_slide(self, slide_data):
        """5. 例题解析页"""
        example = slide_data.get("example", "")
        if not example:
            return
        
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.5),
            width=Inches(11.333),
            height=Inches(0.7),
            text="例题解析",
            font_size=28,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 左侧：题目
        self._add_textbox(
            slide,
            left=Inches(0.5),
            top=Inches(1.5),
            width=Inches(5.5),
            height=Inches(5),
            text=f"题目：\n{example}",
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        # 右侧：配图
        keywords = "problem solving study work"
        self._add_image(slide, Inches(6.3), Inches(1.5), Inches(6.533), Inches(2.5), keywords, 10)
        
        # 解题步骤
        solution_text = """解题步骤

步骤一：分析已知条件
步骤二：寻找解题思路
步骤三：列式计算
步骤四：检验答案

关键提示：
注意公式运用和计算准确性"""
        
        self._add_textbox(
            slide,
            left=Inches(6.3),
            top=Inches(4.2),
            width=Inches(6.533),
            height=Inches(2.3),
            text=solution_text,
            font_size=16,
            color=self.colors["secondary"]
        )
        
        print("Example slide created")
    
    def add_quiz_slide(self, quiz_slide_data):
        """6. 练习巩固页 - 显示Quiz题目"""
        questions = quiz_slide_data.get("questions", [])
        
        if not questions:
            return
        
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.5),
            width=Inches(11.333),
            height=Inches(0.7),
            text="练习巩固",
            font_size=28,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 左侧：配图
        keywords = "quiz test examination study"
        self._add_image(slide, Inches(0.5), Inches(1.5), Inches(3), Inches(5), keywords, 15)
        
        # 展示前2道题
        quiz_text = ""
        for i, q in enumerate(questions[:2], 1):
            quiz_text += f"第 {i} 题：{q.get('stem', '')}\n"
            options = q.get('options', [])
            for opt in options:
                quiz_text += f"  {opt.get('id', '')}. {opt.get('text', '')}\n"
            quiz_text += "\n"
        
        self._add_textbox(
            slide,
            left=Inches(3.7),
            top=Inches(1.5),
            width=Inches(9),
            height=Inches(5),
            text=quiz_text,
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        print("Quiz slide created")
    
    def add_summary_slide(self):
        """7. 课堂总结页"""
        slides = self.deck_data.get("slides", [])
        content_slides = [s for s in slides if s.get("kind") == "content"]
        
        slide = self.prs.slides.add_slide(self.blank_layout)
        self._set_background(slide)
        
        # 标题
        self._add_textbox(
            slide,
            left=Inches(1),
            top=Inches(0.5),
            width=Inches(11.333),
            height=Inches(0.7),
            text="课堂总结",
            font_size=28,
            bold=True,
            color=self.colors["primary"],
            align=PP_ALIGN.CENTER
        )
        
        # 左侧：配图
        keywords = "summary recap knowledge learning"
        self._add_image(slide, Inches(0.5), Inches(1.5), Inches(5.5), Inches(5), keywords, 20)
        
        # 右侧：要点总结
        summary_text = "本节课重点：\n\n"
        for i, s in enumerate(content_slides[:5], 1):
            summary_text += f"{i}. {s.get('title', '')}\n"
        
        summary_text += "\n\n课后作业：\n"
        summary_text += "* 完成课本对应练习题\n"
        summary_text += "* 整理本节课笔记"
        
        self._add_textbox(
            slide,
            left=Inches(6.3),
            top=Inches(1.5),
            width=Inches(6.533),
            height=Inches(5),
            text=summary_text,
            font_size=18,
            color=RGBColor(51, 65, 85)
        )
        
        print("Summary slide created")
    
    def _add_placeholder_box(self, slide, left, top, width, height, label="图片"):
        """添加占位图框"""
        try:
            shape = slide.shapes.add_shape(
                1,  # MSO_SHAPE.RECTANGLE
                left, top, width, height
            )
            
            fill = shape.fill
            fill.solid()
            fill.fore_color.rgb = RGBColor(245, 245, 245)
            
            line = shape.line
            line.color.rgb = RGBColor(200, 200, 200)
            line.dash_style = 4  # DASHED
        except Exception as e:
            print(f"Warning: Could not add placeholder box: {e}")
        
        try:
            self._add_textbox(
                slide,
                left, top + height/2 - Inches(0.2),
                width, Inches(0.4),
                text=f"[{label}]",
                font_size=14,
                color=RGBColor(150, 150, 150),
                align=PP_ALIGN.CENTER
            )
        except Exception as e:
            print(f"Warning: Could not add placeholder label: {e}")
    
    def generate(self, output_path):
        """生成完整PPT"""
        slides = self.deck_data.get("slides", [])
        content_slides = [s for s in slides if s.get("kind") == "content"]
        quiz_slides = [s for s in slides if s.get("kind") == "quiz"]
        
        # 1. 封面页
        self.add_title_slide()
        
        # 2. 目录页
        self.add_toc_slide()
        
        # 3. 情境导入页（使用第一页内容）
        if content_slides:
            self.add_intro_slide(content_slides[0])
        
        # 4. 知识讲解页
        for i, slide_data in enumerate(content_slides, 1):
            self.add_content_slide(slide_data, i)
            if slide_data.get("example", ""):
                self.add_example_slide(slide_data)
        
        # 5. 练习巩固页
        for quiz_slide in quiz_slides:
            self.add_quiz_slide(quiz_slide)
        
        # 6. 课堂总结页
        self.add_summary_slide()
        
        # 保存
        self.prs.save(output_path)
        print(f"PPT saved to: {output_path}")
        print("[SUCCESS] PPT Generation COMPLETED!")
        print(f"[OK] Total slides: {len(self.prs.slides)}")


def main():
    if len(sys.argv) < 3:
        print("Usage: python ppt_generator_enhanced.py <input_json> <output_pptx>")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    print("=" * 50)
    print("Enhanced PPT Generator with Images Starting...")
    print("=" * 50)
    print("Input JSON:", input_path)
    print("Output PPT:", output_path)
    
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            deck_data = json.load(f)
        print("[OK] JSON data loaded")
    except Exception as e:
        print(f"[ERROR] loading JSON: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    try:
        generator = PPTGenerator(deck_data)
        generator.generate(output_path)
        print("=" * 50)
        print("[SUCCESS]")
        print("=" * 50)
        sys.exit(0)
    except Exception as e:
        print(f"[ERROR] generating PPT: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
