import fs from "fs";
import path from "path";

const srcDir = "D:\\code\\Agent\\src";
const backupDir = "D:\\code\\Agent\\backup";

console.log("正在备份...");

try {
  if (!fs.existsSync(backupDir)) fs.mkdirSync(backupDir);
  if (fs.existsSync(srcDir)) copyDir(srcDir, path.join(backupDir, "src"));
  console.log("备份完成！");
} catch (e) {
  console.error("备份失败:", e);
}

function copyDir(src, dest) {
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });
  const entries = fs.readdirSync(src, { withFileTypes: true });
  for (const entry of entries) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDir(s, d);
    else fs.copyFileSync(s, d);
  }
}
