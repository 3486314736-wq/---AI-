# PPT导出功能说明

## 功能概述

本项目已集成PPT导出功能，可以将Web幻灯片预览导出为完整的PowerPoint文档供阅读使用。

## 使用方式

### 1. 安装Python依赖

在项目根目录运行：

```bash
pip install python-pptx
```

如果网络有问题，可以尝试使用国内镜像源：

```bash
pip install python-pptx -i https://pypi.tuna.tsinghua.edu.cn/simple
```

### 2. 在前端使用

1. 访问课程学习页面
2. 页面底部有"导出PPT"按钮
3. 点击按钮，等待PPT生成
4. 浏览器会自动下载生成的PPT文件

## 文件说明

- `scripts/ppt_generator.py` - PPT生成Python脚本
- `src/app/api/ppt/route.ts` - Next.js API路由
- `src/components/slides/lesson-client.tsx` - 包含导出按钮的前端组件
- `scripts/requirements.txt` - Python依赖列表

## PPT内容格式

生成的PPT包含：
1. 标题页（课程标题 + 描述）
2. 内容页（每页幻灯片包含标题、摘要、要点列表）
3. 测验页（包含题目和选项）

## 配色方案

根据学科自动匹配配色：
- 语文（含古诗）：深红色+米色+金色
- 数学：青绿+深绿+橙色
- 英语：靛蓝+紫色+粉色
- 其他学科：默认数学配色

