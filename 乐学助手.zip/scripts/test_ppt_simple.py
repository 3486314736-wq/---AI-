#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""测试PPT生成功能 - 简化版"""

import sys
import json
from pathlib import Path

print("=" * 50)
print("测试PPT生成功能")
print("=" * 50)

try:
    print("\n[1] 测试导入 python-pptx...")
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.enum.text import PP_ALIGN
    from pptx.dml.color import RGBColor
    print("[OK] python-pptx 导入成功！")
except Exception as e:
    print(f"[ERROR] 导入失败: {e}")
    print(f"错误类型: {type(e).__name__}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

try:
    print("\n[2] 测试创建简单的PPT...")
    prs = Presentation()
    
    # 标题页
    slide_layout = prs.slide_layouts[0]
    slide = prs.slides.add_slide(slide_layout)
    title_shape = slide.shapes.title
    title_shape.text = "测试PPT"
    if len(slide.shapes.placeholders) > 1:
        subtitle = slide.shapes.placeholders[1]
        subtitle.text = "这是一个测试文档"
    
    # 保存
    test_file = Path(__file__).parent / "test_output.pptx"
    prs.save(test_file)
    print(f"[OK] PPT创建成功！文件保存到: {test_file}")
    
except Exception as e:
    print(f"[ERROR] 创建PPT失败: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n" + "=" * 50)
print("[OK] 所有测试通过！")
print("=" * 50)
