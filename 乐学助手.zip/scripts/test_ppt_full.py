#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""测试完整版PPT生成器"""

import json
import sys
from pathlib import Path

# 模拟课程数据
test_deck_data = {
    "id": "test-ppt-001",
    "title": "初二数学：三角形的基本概念与分类",
    "description": "理解三角形的基本概念，掌握按角和按边的分类方法",
    "generatedAt": "2026-05-20",
    "slides": [
        {
            "id": "slide-1",
            "kind": "content",
            "title": "什么是三角形",
            "summary": "由三条线段首尾顺次连接所围成的封闭图形叫做三角形。",
            "bullets": [
                "有三条边：a, b, c",
                "有三个角：∠A, ∠B, ∠C",
                "有三个顶点：A, B, C"
            ],
            "example": "用长度为3cm, 4cm, 5cm的三条线段可以构成三角形吗？"
        },
        {
            "id": "slide-2",
            "kind": "content",
            "title": "按角分类",
            "summary": "根据三角形内角的大小，可以将三角形分为三类。",
            "bullets": [
                "锐角三角形：三个角都是锐角",
                "直角三角形：有一个角是直角",
                "钝角三角形：有一个角是钝角"
            ],
            "example": "一个三角形的三个角分别是60°, 70°, 50°，它是什么三角形？"
        },
        {
            "id": "slide-3",
            "kind": "content",
            "title": "按边分类",
            "summary": "根据三角形边长的关系，可以将三角形分为两类。",
            "bullets": [
                "不等边三角形：三条边都不相等",
                "等腰三角形：有两条边相等",
                "等边三角形：三条边都相等（特殊的等腰三角形）"
            ],
            "example": "一个三角形的三条边分别是5cm, 5cm, 6cm，它是什么三角形？"
        },
        {
            "id": "quiz-1",
            "kind": "quiz",
            "title": "练习巩固",
            "summary": "测试你对三角形概念的理解",
            "bullets": [],
            "example": "",
            "questions": [
                {
                    "id": "q1",
                    "stem": "下列哪个图形是三角形？",
                    "options": [
                        {"id": "A", "text": "有三条直线组成的图形"},
                        {"id": "B", "text": "有三条线段组成的封闭图形"},
                        {"id": "C", "text": "有三条曲线组成的图形"},
                        {"id": "D", "text": "有两条线段组成的图形"}
                    ],
                    "correctOptionId": "B",
                    "explanation": "三角形是由三条线段首尾顺次连接所围成的封闭图形。"
                },
                {
                    "id": "q2",
                    "stem": "等边三角形属于什么分类？",
                    "options": [
                        {"id": "A", "text": "不等边三角形"},
                        {"id": "B", "text": "等腰三角形"},
                        {"id": "C", "text": "直角三角形"},
                        {"id": "D", "text": "钝角三角形"}
                    ],
                    "correctOptionId": "B",
                    "explanation": "等边三角形是特殊的等腰三角形，因为它有三条边相等（当然也满足两条边相等）。"
                }
            ]
        }
    ]
}


def main():
    print("=" * 50)
    print("Testing Full PPT Generator")
    print("=" * 50)
    
    # 保存测试数据
    test_json_path = Path(__file__).parent / "test_data.json"
    with open(test_json_path, "w", encoding="utf-8") as f:
        json.dump(test_deck_data, f, ensure_ascii=False, indent=2)
    print(f"✅ Test data saved to: {test_json_path}")
    
    # 导入并运行生成器
    try:
        from ppt_generator import PPTGenerator
        print("✅ PPT Generator imported successfully")
    except Exception as e:
        print(f"❌ Import failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # 生成PPT
    output_path = Path(__file__).parent / "test_output_full.pptx"
    try:
        generator = PPTGenerator(test_deck_data)
        generator.generate(str(output_path))
        print(f"\n🎉 SUCCESS! PPT created at: {output_path}")
        print(f"📊 Total slides: {len(generator.prs.slides)}")
    except Exception as e:
        print(f"❌ Generation failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
